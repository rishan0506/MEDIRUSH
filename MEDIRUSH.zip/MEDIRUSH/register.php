<?php
/**
 * MEDIRUSH — Registration (public, guests only).
 * Every field must be filled — including country and terms & conditions.
 * The chosen country drives the site language and the pharmacy
 * delivery location.
 */
$ROOT = '.';
$PAGE_TITLE = 'Create account';
$ACTIVE = '';
require_once $ROOT . '/includes/auth.php';
require_guest();

$fullName = '';
$email = '';
$phone = '';
$country = '';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $fullName        = trim((string)($_POST['full_name'] ?? ''));
    $email           = trim((string)($_POST['email'] ?? ''));
    $phone           = trim((string)($_POST['phone'] ?? ''));
    $country         = trim((string)($_POST['country'] ?? ''));
    $password        = (string)($_POST['password'] ?? '');
    $confirmPassword = (string)($_POST['confirm_password'] ?? '');
    $acceptTerms     = (string)($_POST['accept_terms'] ?? '');

    if (mb_strlen($fullName) < 3) {
        $errors[] = 'Please enter your full name (at least 3 characters).';
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address.';
    }

    if ($phone === '') {
        $errors[] = 'Please enter your phone number — it is required.';
    } elseif (!valid_phone($phone)) {
        $errors[] = 'Please enter a valid phone number (7–20 digits, may include +, spaces, dashes).';
    }

    if ($country === '' || !in_array($country, medirush_countries(), true)) {
        $errors[] = 'Please choose your country from the list.';
    }

    if (mb_strlen($password) < 8) {
        $errors[] = 'Your password must be at least 8 characters long.';
    }

    if ($password !== $confirmPassword) {
        $errors[] = 'The password and password confirmation do not match.';
    }

    if ($acceptTerms !== '1') {
        $errors[] = 'You must accept the terms and conditions to create an account.';
    }

    /* Email must not already exist (prepared COUNT) */
    if (!$errors && filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $taken = fetch_one('SELECT COUNT(*) AS c FROM users WHERE email = ?', 's', [$email]);
        if ((int)($taken['c'] ?? 0) > 0) {
            $errors[] = 'That email address is already registered. Try logging in instead.';
        }
    }

    if (!$errors) {
        try {
            $stmt = db()->prepare('INSERT INTO users (full_name, email, password_hash, phone, role) VALUES (?, ?, ?, ?, ?)');
            $role = 'user';
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt->bind_param('sssss', $fullName, $email, $hash, $phone, $role);
            $stmt->execute();
            $newUserId = (int)db()->insert_id;
            $stmt->close();

            /* Auto-create the profile row with the chosen country */
            $stmt = db()->prepare('INSERT INTO user_profiles (user_id, country) VALUES (?, ?)');
            $stmt->bind_param('is', $newUserId, $country);
            $stmt->execute();
            $stmt->close();

            /* And an empty shopping cart */
            get_or_create_cart($newUserId);

            login_current_user([
                'id'        => $newUserId,
                'role'      => $role,
                'full_name' => $fullName,
            ]);
            $_SESSION['country'] = $country;

            flash('success', 'Welcome to MEDIRUSH, ' . $fullName . '! Your account is ready.');
            redirect('dashboard.php');
        } catch (mysqli_sql_exception | Throwable $ex) {
            error_log('MEDIRUSH register error: ' . $ex->getMessage());
            $errors[] = 'We could not create your account right now. Please try again.';
        }
    }
}

require_once $ROOT . '/includes/header.php';
?>
<div class="auth-wrap">
  <div class="auth-card">
    <div class="card">
      <h1 class="auth-title">Create your account 🩺</h1>
      <p class="auth-sub">One account for healthcare, pharmacy, skincare and your personal health space.</p>

      <?php if ($errors): ?>
        <div class="alert alert-error" role="alert">
          <strong>Please fix the following:</strong>
          <ul>
            <?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?>
          </ul>
        </div>
      <?php endif; ?>

      <form action="<?= u('register.php') ?>" method="post">
        <?= csrf_field() ?>

        <div class="form-group">
          <label class="form-label" for="full_name">Full name</label>
          <input class="form-input" type="text" id="full_name" name="full_name" value="<?= e($fullName) ?>"
                 placeholder="e.g. Maria Santos" required>
        </div>

        <div class="form-group">
          <label class="form-label" for="email">Email address</label>
          <input class="form-input" type="email" id="email" name="email" value="<?= e($email) ?>"
                 placeholder="you@example.com" required>
        </div>

        <div class="form-group">
          <label class="form-label" for="phone">Phone number</label>
          <input class="form-input" type="text" id="phone" name="phone" value="<?= e($phone) ?>"
                 placeholder="e.g. +63 917 123 4567" required>
          <small class="form-help">Used for delivery and appointment updates.</small>
        </div>

        <div class="form-group">
          <label class="form-label" for="country">Country</label>
          <select class="form-select" id="country" name="country" required>
            <option value="">— Select your country —</option>
            <?php foreach (medirush_countries() as $c): ?>
              <option value="<?= e($c) ?>"<?= $country === $c ? ' selected' : '' ?>><?= e($c) ?></option>
            <?php endforeach; ?>
          </select>
          <small class="form-help">Sets your pharmacy delivery location and the site language. You can change it later in Settings.</small>
        </div>

        <div class="form-group">
          <label class="form-label" for="password">Password</label>
          <input class="form-input" type="password" id="password" name="password"
                 placeholder="At least 8 characters" required>
          <small class="form-help">Minimum 8 characters.</small>
        </div>

        <div class="form-group">
          <label class="form-label" for="confirm_password">Confirm password</label>
          <input class="form-input" type="password" id="confirm_password" name="confirm_password"
                 placeholder="Repeat your password" required>
        </div>

        <div class="form-group">
          <label>
            <input type="checkbox" id="accept_terms" name="accept_terms" value="1" required>
            I accept the <strong>terms &amp; conditions</strong> and agree that this is a demonstration platform.
          </label>
        </div>

        <button type="submit" class="btn btn-primary btn-block">Create account</button>
      </form>

      <p class="auth-foot">
        Already have an account?
        <a href="<?= u('login.php') ?>"><strong>Log in</strong></a>
      </p>
    </div>
  </div>
</div>
<?php require_once $ROOT . '/includes/footer.php'; ?>