<?php
/**
 * MEDIRUSH — account/appointments.php
 * Appointment history: cancel upcoming appointments, join demo video room.
 */
declare(strict_types=1);

$ROOT = '..';
$PAGE_TITLE = 'Appointments · MEDIRUSH';
$ACTIVE = 'account';
$SHOW_SIDEBAR = true;

require_once $ROOT . '/includes/auth.php';
require_login();

$uid = (int)$_SESSION['user_id'];
$today = date('Y-m-d');

/* --------------------------- POST: cancel_appointment ---------------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'cancel_appointment') {
    verify_csrf();

    $aptId = (int)($_POST['id'] ?? 0);

    // Ownership + status guard: only this user's scheduled appointments can be cancelled.
    $apt = fetch_one(
        'SELECT id, appointment_date, appointment_time, status, doctor_id
           FROM appointments WHERE id = ? AND user_id = ? LIMIT 1',
        'ii',
        [$aptId, $uid]
    );

    if (!$apt || $apt['status'] !== 'scheduled') {
        flash('error', 'That appointment could not be cancelled — it may already be completed or cancelled.');
    } else {
        try {
            $stmt = db()->prepare("UPDATE appointments SET status = 'cancelled' WHERE id = ? AND user_id = ? AND status = 'scheduled'");
            $stmt->bind_param('ii', $aptId, $uid);
            $stmt->execute();
            $stmt->close();

            add_notification(
                $uid,
                'appointment',
                'Appointment cancelled',
                'Your appointment on ' . date('j F Y', strtotime((string)$apt['appointment_date']))
                    . ' at ' . date('H:i', strtotime((string)$apt['appointment_time'])) . ' was cancelled.'
            );
            flash('success', 'Appointment cancelled.');
        } catch (Throwable $ex) {
            error_log('cancel_appointment failed: ' . $ex->getMessage());
            flash('error', 'We could not cancel that appointment right now — please try again.');
        }
    }
    redirect('account/appointments.php');
}

/* Appointment list joined with doctor details. */
$appointments = fetch_all(
    'SELECT a.id, a.appointment_date, a.appointment_time, a.mode, a.status, a.notes,
            d.name AS doctor_name, d.specialization, d.image AS doctor_image, d.consultation_fee
       FROM appointments a
       JOIN doctors d ON d.id = a.doctor_id
      WHERE a.user_id = ?
   ORDER BY a.appointment_date DESC, a.appointment_time DESC',
    'i',
    [$uid]
);

$modeBadge = [
    'video'     => ['🎥 Video', 'badge-info'],
    'phone'     => ['📞 Phone', ''],
    'in_person' => ['🏥 In person', 'badge-success'],
];
$statusBadge = [
    'scheduled' => ['badge-info'],
    'completed' => ['badge-success'],
    'cancelled' => ['badge-danger'],
];

require_once $ROOT . '/includes/header.php';
?>
<div class="sidebar-wrap">
  <div class="sidebar-main">

    <div class="page-head">
      <h1 class="section-title">📅 Appointment history</h1>
      <p class="section-subtitle">Your doctor consultations — past and upcoming.</p>
    </div>

    <?php if (!$appointments): ?>
      <div class="empty-state">
        <div class="empty-icon" style="font-size:3rem;">📅</div>
        <h2 class="section-title" style="font-size:1.2rem;">No appointments yet</h2>
        <p>Browse our doctors and book your first consultation.</p>
        <a class="btn btn-primary" href="<?= u('healthcare/doctor_consultation.php') ?>">🩺 Find a doctor</a>
      </div>
    <?php else: ?>
      <?php foreach ($appointments as $a): ?>
        <?php
        $aptDate  = (string)$a['appointment_date'];
        $aptTime  = substr((string)$a['appointment_time'], 0, 5);
        $isFuture = $aptDate >= $today;
        $isToday  = $aptDate === $today;
        [$mLabel, $mClass] = $modeBadge[$a['mode']] ?? [$a['mode'], ''];
        [$sClass] = $statusBadge[$a['status']] ?? [''];
        ?>
        <div class="card" style="margin-bottom:var(--gap,1rem);">
          <div class="card-body">
            <div class="list-row" style="align-items:center;">
              <span class="avatar avatar-lg" aria-hidden="true"><?= e(icon((string)$a['doctor_image'], '🩺')) ?></span>
              <div style="flex:1;">
                <strong>Dr. <?= e($a['doctor_name']) ?></strong> <span class="badge"><?= e($a['specialization']) ?></span><br>
                <small class="muted"><?= e(date('D, j F Y', strtotime($aptDate))) ?> at <?= e($aptTime) ?></small>
              </div>
              <div style="text-align:right;">
                <span class="badge <?= e($mClass) ?>"><?= e($mLabel) ?></span>
                <span class="badge <?= e($sClass) ?>"><?= e(ucfirst((string)$a['status'])) ?></span><br>
                <small class="muted">Consultation fee: <?= e(money($a['consultation_fee'])) ?></small>
              </div>
            </div>

            <?php if ($a['notes'] !== null && trim((string)$a['notes']) !== ''): ?>
              <p class="muted" style="margin:.5rem 0 0;">📝 <?= e($a['notes']) ?></p>
            <?php endif; ?>

            <?php if ($a['status'] === 'scheduled' && $isFuture): ?>
              <form method="post" action="<?= u('account/appointments.php') ?>" style="margin-top:.6rem;">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="cancel_appointment">
                <input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
                <button type="submit" class="btn btn-danger btn-sm">✖ Cancel appointment</button>
              </form>
            <?php endif; ?>

            <?php if ($a['mode'] === 'video' && $a['status'] === 'scheduled' && $isToday): ?>
              <details style="margin-top:.6rem;">
                <summary class="btn btn-primary btn-sm" style="cursor:pointer;">🎥 Join video room</summary>
                <div style="padding:.6rem 0;">
                  <?php if (defined('VIDEO_CONSULT_API_KEY') && VIDEO_CONSULT_API_KEY !== ''): ?>
                    <p class="form-help">🔑 Video key configured, but live rooms need the VIDEO_CONSULT_API_KEY integration in <code>includes/config.php</code>.</p>
                  <?php else: ?>
                    <p class="form-help">🔧 Demo video room — integrate VIDEO_CONSULT_API_KEY (includes/config.php) for live video.</p>
                  <?php endif; ?>
                </div>
              </details>
            <?php endif; ?>
          </div>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>

    <!-- Booking CTA -->
    <div class="card">
      <div class="card-body" style="display:flex; align-items:center; gap:1rem; flex-wrap:wrap;">
        <div style="flex:1; min-width:220px;">
          <h2 class="section-title" style="font-size:1.05rem; margin:0;">🩺 Need to see a doctor?</h2>
          <p class="form-help" style="margin:.25rem 0 0;">Book a video, phone or in-person consultation with our qualified practitioners.</p>
        </div>
        <a class="btn btn-primary" href="<?= u('healthcare/doctor_consultation.php') ?>">Book a consultation</a>
      </div>
    </div>

  </div>
</div>
<?php require_once $ROOT . '/includes/footer.php'; ?>
