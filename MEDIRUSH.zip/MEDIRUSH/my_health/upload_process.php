<?php
/**
 * MEDIRUSH — my_health/upload_process.php — Handles document uploads (prescriptions and records).
 * Pure backend endpoint: ALWAYS replies JSON ({ok, redirect} or {ok:false, message}); direct form posts also
 * get flash+redirect instead of stopping in JSON. Never prints HTML.
 */
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';

/** Emit a JSON body and stop. */
function json_out(array $data): void {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data);
    exit;
}

/** Detect this came from js/upload.js (multipart XHR forms post ajax=1 as well). */
function wants_json(): bool {
    return (($_POST['ajax'] ?? '') === '1')
        || (($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'XMLHttpRequest')
        || (stripos($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json') !== false);
}

/** Unified failure: JSON in XHR mode, flash+redirect for plain posts. */
function fail(string $message, string $redirectTo = 'my_health/upload.php'): void {
    if (wants_json()) {
        json_out(['ok' => false, 'message' => $message]);
    }
    flash('error', $message);
    redirect($redirectTo);
}

try {
    /* ---- Auth (JSON-aware, never emits HTML) ---- */
    if (!is_logged_in()) {
        if (wants_json()) {
            http_response_code(401);
            json_out(['ok' => false, 'message' => 'Please log in again.']);
        }
        flash('info', 'Please log in to continue.');
        redirect('login.php');
    }
    $user = current_user();
    if ($user === null) {
        http_response_code(401);
        json_out(['ok' => false, 'message' => 'Please log in again.']);
    }
    $userId = (int)$user['id'];

    /* ---- CSRF (verify_csrf() redirects home, so use a JSON-aware variant) ---- */
    $sent = (string)($_POST['csrf_token'] ?? '');
    if ($sent === '' || !hash_equals($_SESSION['csrf_token'] ?? '', $sent)) {
        fail('Security check failed — please refresh the page and try again.');
    }

    /* ---- Upload constraints (must match js/upload.js) ---- */
    if (!defined('UPLOAD_MAX_BYTES')) {
        define('UPLOAD_MAX_BYTES', 5242880); // 5 MB
    }
    $allowedExt   = ['jpg', 'jpeg', 'png', 'webp', 'pdf'];
    $allowedMimes = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'];
    $mimeExts = [ // real MIME => extensions actually valid for it
        'image/jpeg'      => ['jpg', 'jpeg'],
        'image/png'       => ['png'],
        'image/webp'      => ['webp'],
        'application/pdf' => ['pdf'],
    ];

    /* ---- Document type whitelist ---- */
    $docType = trim((string)($_POST['doc_type'] ?? ''));
    if (!in_array($docType, ['prescription', 'record'], true)) {
        fail('Choose a valid document type (prescription or medical record).');
    }

    /* ---- File present & valid ---- */
    $file = $_FILES['document_file'] ?? null;
    if (!is_array($file) || !isset($file['error'], $file['size'], $file['tmp_name'], $file['name'])) {
        fail('No file was received. Please choose a document and try again.');
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $messages = [
            UPLOAD_ERR_INI_SIZE   => 'The file exceeds the server upload limit (5 MB).',
            UPLOAD_ERR_FORM_SIZE  => 'The file exceeds the form upload limit (5 MB).',
            UPLOAD_ERR_PARTIAL    => 'The upload was interrupted — please try again.',
            UPLOAD_ERR_NO_FILE    => 'Please choose a file to upload.',
            UPLOAD_ERR_NO_TMP_DIR => 'Server misconfiguration: missing temp directory.',
            UPLOAD_ERR_CANT_WRITE => 'Server could not write the file to disk.',
            UPLOAD_ERR_EXTENSION  => 'A server extension stopped the upload.',
        ];
        fail($messages[$file['error']] ?? 'The upload failed. Please try again.');
    }
    if ((int)$file['size'] <= 0 || (int)$file['size'] > UPLOAD_MAX_BYTES) {
        fail('File is too large. Maximum size is 5 MB.');
    }
    if (!is_uploaded_file((string)$file['tmp_name'])) {
        fail('Invalid upload — no temporary file was delivered.');
    }

    /* ---- Extension whitelist ---- */
    $origName = (string)$file['name'];
    $ext = strtolower((string)pathinfo($origName, PATHINFO_EXTENSION));
    if ($ext === '' || !in_array($ext, $allowedExt, true)) {
        fail('Only JPG, JPEG, PNG, WEBP or PDF files are allowed.');
    }

    /* ---- Real MIME check via finfo ---- */
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    if ($finfo === false) {
        fail('Server file-check unavailable — please try again.');
    }
    $mime = (string)finfo_file($finfo, (string)$file['tmp_name']);
    finfo_close($finfo);

    if (!in_array($mime, $allowedMimes, true) || !in_array($ext, $mimeExts[$mime] ?? [], true)) {
        fail('This file does not look like a valid JPG, PNG, WEBP or PDF.');
    }

    /* ---- Optional text fields ---- */
    $doctorName = $docType === 'prescription'
        ? mb_substr(trim((string)($_POST['doctor_name'] ?? '')), 0, 120)
        : '';
    $title = $docType === 'record'
        ? (mb_substr(trim((string)($_POST['title'] ?? '')), 0, 120) ?: 'Medical record')
        : '';
    $recordType = 'other';
    if ($docType === 'record') {
        $candidate = trim((string)($_POST['record_type'] ?? ''));
        if (in_array($candidate, ['lab_result', 'report', 'scan', 'other'], true)) {
            $recordType = $candidate;
        }
    }

    /* ---- Safe storage name: {userId}_{type}_{random}.{ext} ---- */
    $safe = $userId . '_' . $docType . '_' . bin2hex(random_bytes(8)) . '.' . $ext;

    $baseDir = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'uploads';
    if (!is_dir($baseDir) && !@mkdir($baseDir, 0755, true) && !is_dir($baseDir)) {
        fail('Storage folder could not be created — please contact support.');
    }
    $htaccess = $baseDir . DIRECTORY_SEPARATOR . '.htaccess';
    if (!is_file($htaccess) && @file_put_contents($htaccess, "Require all denied\nDeny from all\n") === false) {
        fail('Uploads folder could not be protected — upload blocked.');
    }

    $target = $baseDir . DIRECTORY_SEPARATOR . $safe;
    if (!@move_uploaded_file((string)$file['tmp_name'], $target)) {
        fail('Could not save the file on the server. Please try again.');
    }

    /* ---- Insert the DB row (clean up the file if the write fails) ---- */
    try {
        $relativePath = 'assets/uploads/' . $safe;
        if ($docType === 'prescription') {
            $stmt = db()->prepare(
                "INSERT INTO prescriptions (user_id, doctor_name, file_path, original_filename, status)
                 VALUES (?, ?, ?, ?, 'pending')"
            );
            $stmt->bind_param('isss', $userId, $doctorName, $relativePath, $origName);
            $stmt->execute();
            $stmt->close();
        } else {
            $stmt = db()->prepare(
                'INSERT INTO medical_records (user_id, title, record_type, file_path, original_filename)
                 VALUES (?, ?, ?, ?, ?)'
            );
            $stmt->bind_param('issss', $userId, $title, $recordType, $relativePath, $origName);
            $stmt->execute();
            $stmt->close();
        }
    } catch (Throwable $dbEx) {
        error_log('[MEDIRUSH] upload_process insert failed: ' . $dbEx->getMessage());
        @unlink($target);
        fail('Could not register the document. Please try again.');
    }

    /* ---- Notifications & confirmation ---- */
    if ($docType === 'prescription') {
        add_notification($userId, 'prescription', 'Prescription uploaded',
            'Your prescription "' . $origName . '" is pending review by our pharmacist team.');
    } else {
        add_notification($userId, 'upload', 'Medical record added',
            'Your medical record "' . $title . '" was saved to your health file.');
    }
    flash('success', $docType === 'prescription'
        ? 'Prescription uploaded — it is now pending review.'
        : 'Medical record uploaded to your health file.');

    if (wants_json()) {
        json_out(['ok' => true, 'redirect' => u('my_health/upload.php')]);
    }
    /* Plain form posts: flash message was set already, so just redirect normally. */
    redirect('my_health/upload.php');
} catch (Throwable $e) {
    error_log('[MEDIRUSH] upload_process error: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
    $msg = 'Something went wrong with the upload. Please try again.';
    if (wants_json()) {
        http_response_code(500);
        json_out(['ok' => false, 'message' => $msg]);
    }
    flash('error', $msg);
    redirect('my_health/upload.php');
}
