<?php
/**
 * MEDIRUSH — Healthcare hub (public page).
 */
$ROOT = '..';
$PAGE_TITLE = 'Healthcare — MEDIRUSH';
$ACTIVE = 'healthcare';
require_once $ROOT . '/includes/header.php';
?>

<!-- ========================= Hero-lite ========================= -->
<section class="section">
  <h1 class="section-title">Your medical hub</h1>
  <p class="section-subtitle">
    Explore how your body works, book a qualified doctor, and find emergency facilities
    near you — all from one place. Then let MEDIRUSH help you keep track of it in My Health.
  </p>

  <div class="grid grid-4">
    <a class="card feature-card" href="<?= u('healthcare/anatomy.php') ?>">
      <div class="feature-icon">🧠</div>
      <h3>Interactive Anatomy</h3>
      <p>Tap a body part to learn what it does and one simple way to keep it healthy.</p>
    </a>
    <a class="card feature-card" href="<?= u('healthcare/doctor_consultation.php') ?>">
      <div class="feature-icon">🩺</div>
      <h3>Doctor Consultation</h3>
      <p>Browse verified doctors by specialisation and book in-person, video or phone visits.</p>
    </a>
    <a class="card feature-card" href="<?= u('healthcare/emergency_locator.php') ?>">
      <div class="feature-icon">🚑</div>
      <h3>Emergency Locator</h3>
      <p>Find your nearest hospitals, clinics, pharmacies and labs — 24hr facilities flagged.</p>
    </a>
    <a class="card feature-card" href="<?= u('my_health/my_health.php') ?>">
      <div class="feature-icon">📋</div>
      <h3>My Health <span class="badge badge-info">Login required</span></h3>
      <p>Log in to manage medications, reminders, uploads and your skincare routine.</p>
    </a>
  </div>
</section>

<!-- ========================= Body systems ========================= -->
<section class="section">
  <h2 class="section-title">Body systems</h2>
  <p class="section-subtitle">Six systems that keep you going — and a one-line tip for each.</p>
  <div class="grid grid-3">
    <div class="card">
      <div class="facility-icon">❤️</div>
      <h3>Heart</h3>
      <p class="product-desc">❤️ Move 30 minutes most days — it is the single best gift for your heart.</p>
    </div>
    <div class="card">
      <div class="facility-icon">🫁</div>
      <h3>Lungs</h3>
      <p class="product-desc">🫁 Avoid smoke and practise slow, deep breathing to keep lungs clear.</p>
    </div>
    <div class="card">
      <div class="facility-icon">🧠</div>
      <h3>Brain</h3>
      <p class="product-desc">🧠 Sleep 7–9 hours and learn something new to keep the brain sharp.</p>
    </div>
    <div class="card">
      <div class="facility-icon">🫄</div>
      <h3>Gut</h3>
      <p class="product-desc">🫄 Eat fibre-rich foods like oats and beans to feed healthy gut bacteria.</p>
    </div>
    <div class="card">
      <div class="facility-icon">🦴</div>
      <h3>Bones</h3>
      <p class="product-desc">🦴 Get vitamin D from sunshine and load-bearing exercise for strong bones.</p>
    </div>
    <div class="card">
      <div class="facility-icon">🛡️</div>
      <h3>Immunity</h3>
      <p class="product-desc">🛡️ Eat colourful fruit and veg, and keep vaccines up to date.</p>
    </div>
  </div>
</section>

<!-- ========================= Health tips accordion ========================= -->
<section class="section">
  <h2 class="section-title">Everyday health tips</h2>
  <p class="section-subtitle">Simple habits the pros recommend. Click a tip to open it.</p>

  <div class="accordion-item open">
    <button type="button" class="accordion-header">💧 How much water should I drink daily?</button>
    <div class="accordion-body">
      Most adults do well with about 6–8 glasses (roughly 2 litres) spread through the day.
      Drink more in hot weather or when exercising, and use your urine colour as a guide —
      pale yellow means you are well hydrated.
    </div>
  </div>

  <div class="accordion-item">
    <button type="button" class="accordion-header">🥗 What does a balanced plate look like?</button>
    <div class="accordion-body">
      Aim for half your plate colourful vegetables, a quarter lean protein (chicken, fish,
      beans), and a quarter whole-grain starch (brown rice, whole-wheat pap or bread).
      Add a little healthy fat — avocado, olive oil or nuts — and go easy on added salt and sugar.
    </div>
  </div>

  <div class="accordion-item">
    <button type="button" class="accordion-header">😴 How much sleep do I really need?</button>
    <div class="accordion-body">
      Adults need 7–9 hours a night. Keep a regular bedtime, switch screens off 30 minutes
      before bed, and keep your room dark and cool. Poor sleep raises the risk of high blood
      pressure, low mood and weight gain.
    </div>
  </div>
</section>

<!-- ========================= CTA strip ========================= -->
<section class="section">
  <div class="card flex-between">
    <div>
      <h3>Not feeling 100%?</h3>
      <p class="muted">Book a consultation with one of our doctors — in person, video or phone.</p>
    </div>
    <a class="btn btn-primary" href="<?= u('healthcare/doctor_consultation.php') ?>">🩺 Book a consultation</a>
  </div>
</section>

<?php require_once $ROOT . '/includes/footer.php'; ?>
