<?php
/**
 * MEDIRUSH — Reusable footer.
 */
declare(strict_types=1);
?>
    <footer class="footer">
      <div class="container footer-grid">
        <div>
          <a href="<?= u('index.php') ?>" class="brand"><span class="brand-icon">🩺</span> <span class="brand-name">MEDI<b>RUSH</b></span></a>
          <p class="footer-copy">Your health. Your beauty. One platform.<br>Consult a qualified professional before starting any treatment.</p>
        </div>
        <div>
          <h4>Platform</h4>
          <a href="<?= u('index.php') ?>">Home</a>
          <a href="<?= u('dashboard.php') ?>">Dashboard</a>
          <a href="<?= u('my_health/my_health.php') ?>">My Health</a>
          <a href="<?= u('account/orders.php') ?>">Orders</a>
        </div>
        <div>
          <h4>Services</h4>
          <a href="<?= u('healthcare/healthcare.php') ?>">Healthcare</a>
          <a href="<?= u('healthcare/doctor_consultation.php') ?>">Doctor Consultation</a>
          <a href="<?= u('pharmacy/pharmacy.php') ?>">Pharmacy</a>
          <a href="<?= u('beauty/beauty.php') ?>">Beauty &amp; Skincare</a>
        </div>
        <div>
          <h4>Account</h4>
          <a href="<?= u('account/profile.php') ?>">My Profile</a>
          <a href="<?= u('account/appointments.php') ?>">Appointments</a>
          <a href="<?= u('account/settings.php') ?>">Settings</a>
          <a href="<?= u('healthcare/emergency_locator.php') ?>">Emergency Facilities</a>
        </div>
      </div>
      <div class="footer-bottom">© <?= date('Y') ?> MEDIRUSH — Student demonstration project. Not a substitute for professional medical advice.</div>
    </footer>
  </main><!-- /.site-main -->
<script src="<?= u('js/script.js') ?>"></script>
<script src="<?= u('js/effects.js') ?>" defer></script>
</body>
</html>