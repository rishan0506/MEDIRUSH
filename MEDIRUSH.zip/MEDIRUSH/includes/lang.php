<?php
/**
 * MEDIRUSH — Language switching (driven by the user's registered country).
 * Included from includes/auth.php.
 *
 * Language follows the Country set during registration / Settings:
 *   Philippines → Filipino  | Thailand → Thai | Indonesia → Indonesian
 *   Malaysia → Malay        | Vietnam  → Vietnamese | (none) → English
 */
declare(strict_types=1);

if (!defined('MEDIRUSH_LANG')) {
    define('MEDIRUSH_LANG', true);

    /** Countries selectable at registration / Settings. */
    function medirush_countries(): array {
        return ['Philippines', 'Thailand', 'Indonesia', 'Malaysia', 'Vietnam'];
    }

    /** Flag emoji per country (some Windows browsers render these as letters). */
    function medirush_flags(): array {
        return [
            'Philippines' => '🇵🇭',
            'Thailand'    => '🇹🇭',
            'Indonesia'   => '🇮🇩',
            'Malaysia'    => '🇲🇾',
            'Vietnam'     => '🇻🇳',
        ];
    }

    /** Current language code, derived from $_SESSION['country']. */
    function medirush_lang(): string {
        $map = [
            'Philippines' => 'tl', 'Thailand' => 'th', 'Indonesia' => 'id',
            'Malaysia'    => 'ms', 'Vietnam'  => 'vi',
        ];
        $country = (string)($_SESSION['country'] ?? '');
        return $map[$country] ?? 'en';
    }

    /** Translate a key for the current language (English fallback). */
    function t(string $key): string {
        static $dicts = null;
        if ($dicts === null) {
            $dicts = medirush_lang_dictionaries();
        }
        $lang = medirush_lang();
        return $dicts[$lang][$key] ?? ($dicts['en'][$key] ?? $key);
    }

    function medirush_lang_dictionaries(): array {
        return [
            'en' => [
                'nav_home'       => 'Home',
                'nav_healthcare' => 'Healthcare',
                'nav_pharmacy'   => 'Pharmacy',
                'nav_beauty'     => 'Beauty',
                'nav_my_health'  => 'My Health',
                'nav_dashboard'  => 'Dashboard',
                'hero_title'     => 'Your health. Your beauty.',
                'hero_badge'     => 'One platform.',
                'hero_sub'       => 'MEDIRUSH brings your medical hub, online pharmacy, skincare & beauty store and personal health tools together — so everything about your wellbeing lives in one place.',
                'cta_pharmacy'   => '🛒 Visit the pharmacy',
                'cta_register'   => 'Create your free account',
                'loc_delivering' => 'Delivering to',
                'loc_change'     => 'change',
                'loc_none'       => 'Set your delivery country in Settings',
            ],
            'tl' => [ // Filipino
                'nav_home'       => 'Home',
                'nav_healthcare' => 'Kalusugan',
                'nav_pharmacy'   => 'Botika',
                'nav_beauty'     => 'Kagandahan',
                'nav_my_health'  => 'Kalusugan Ko',
                'nav_dashboard'  => 'Dashboard',
                'hero_title'     => 'Kalusugan mo. Kagandahan mo.',
                'hero_badge'     => 'Isang platform.',
                'hero_sub'       => 'Pinagsasama ng MEDIRUSH ang iyong medical hub, online na botika, skincare & beauty store, at mga personal na health tool — nasa iisang lugar ang lahat para sa iyong wellbeing.',
                'cta_pharmacy'   => '🛒 Puntahan ang botika',
                'cta_register'   => 'Gumawa ng libreng account',
                'loc_delivering' => 'Padala sa',
                'loc_change'     => 'palitan',
                'loc_none'       => 'Itakda ang iyong bansa sa Settings',
            ],
            'th' => [ // Thai
                'nav_home'       => 'หน้าแรก',
                'nav_healthcare' => 'สุขภาพ',
                'nav_pharmacy'   => 'ร้านยา',
                'nav_beauty'     => 'ความงาม',
                'nav_my_health'  => 'สุขภาพของฉัน',
                'nav_dashboard'  => 'แดชบอร์ด',
                'hero_title'     => 'สุขภาพของคุณ ความงามของคุณ',
                'hero_badge'     => 'แพลตฟอร์มเดียว',
                'hero_sub'       => 'MEDIRUSH รวมศูนย์การแพทย์ ร้านยาออนไลน์ ร้านสกินแคร์และความงาม และเครื่องมือดูแลสุขภาพส่วนบุคคล ไว้ในที่เดียว',
                'cta_pharmacy'   => '🛒 เข้าชมร้านยา',
                'cta_register'   => 'สร้างบัญชีฟรี',
                'loc_delivering' => 'จัดส่งไปที่',
                'loc_change'     => 'เปลี่ยน',
                'loc_none'       => 'ตั้งค่าประเทศของคุณในหน้าการตั้งค่า',
            ],
            'id' => [ // Indonesian
                'nav_home'       => 'Beranda',
                'nav_healthcare' => 'Kesehatan',
                'nav_pharmacy'   => 'Apotek',
                'nav_beauty'     => 'Kecantikan',
                'nav_my_health'  => 'Kesehatanku',
                'nav_dashboard'  => 'Dasbor',
                'hero_title'     => 'Kesehatanmu. Kecantikanmu.',
                'hero_badge'     => 'Satu platform.',
                'hero_sub'       => 'MEDIRUSH menyatukan pusat medis, apotek daring, toko skincare & kecantikan, dan alat kesehatan pribadi Anda — semuanya dalam satu tempat.',
                'cta_pharmacy'   => '🛒 Kunjungi apotek',
                'cta_register'   => 'Buat akun gratis',
                'loc_delivering' => 'Dikirim ke',
                'loc_change'     => 'ubah',
                'loc_none'       => 'Atur negara Anda di Pengaturan',
            ],
            'ms' => [ // Malay
                'nav_home'       => 'Utama',
                'nav_healthcare' => 'Kesihatan',
                'nav_pharmacy'   => 'Farmasi',
                'nav_beauty'     => 'Kecantikan',
                'nav_my_health'  => 'Kesihatan Saya',
                'nav_dashboard'  => 'Papan Pemuka',
                'hero_title'     => 'Kesihatan anda. Kecantikan anda.',
                'hero_badge'     => 'Satu platform.',
                'hero_sub'       => 'MEDIRUSH menyatukan hab perubatan anda, farmasi dalam talian, kedai penjagaan kulit & kecantikan serta alat kesihatan peribadi — semuanya di satu tempat.',
                'cta_pharmacy'   => '🛒 Lawati farmasi',
                'cta_register'   => 'Cipta akaun percuma',
                'loc_delivering' => 'Dihantar ke',
                'loc_change'     => 'tukar',
                'loc_none'       => 'Tetapkan negara anda dalam Tetapan',
            ],
            'vi' => [ // Vietnamese
                'nav_home'       => 'Trang chủ',
                'nav_healthcare' => 'Sức khỏe',
                'nav_pharmacy'   => 'Nhà thuốc',
                'nav_beauty'     => 'Làm đẹp',
                'nav_my_health'  => 'Sức khỏe của tôi',
                'nav_dashboard'  => 'Bảng điều khiển',
                'hero_title'     => 'Sức khỏe của bạn. Vẻ đẹp của bạn.',
                'hero_badge'     => 'Một nền tảng.',
                'hero_sub'       => 'MEDIRUSH kết nối trung tâm y tế, nhà thuốc trực tuyến, cửa hàng mỹ phẩm và công cụ chăm sóc sức khỏe cá nhân — tất cả trong một nơi.',
                'cta_pharmacy'   => '🛒 Ghé nhà thuốc',
                'cta_register'   => 'Tạo tài khoản miễn phí',
                'loc_delivering' => 'Giao đến',
                'loc_change'     => 'thay đổi',
                'loc_none'       => 'Chọn quốc gia của bạn trong Cài đặt',
            ],
        ];
    }
}