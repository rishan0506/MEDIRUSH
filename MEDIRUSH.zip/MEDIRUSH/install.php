<?php
/**
 * MEDIRUSH — install.php — one-click database installer + verbose diagnostics.
 *
 * Runs database.sql (schema + demo data) the same way phpMyAdmin's Import
 * would. If automatic import fails, it replays the file statement-by-statement
 * and shows the EXACT MySQL error for the offending statement.
 *
 * Safe to re-run — every statement is IF NOT EXISTS / idempotent.
 */
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php'; // (db() already attempted auto-install)

/** Split SQL into statements while respecting quotes and comments. */
function split_sql_statements(string $sql): array {
    $stmts = [];
    $cur = '';
    $n = strlen($sql);
    $i = 0;
    $inS = false; $inD = false; $inLine = false; $inBlock = false;
    while ($i < $n) {
        $c = $sql[$i];
        $next = $sql[$i + 1] ?? '';
        if ($inLine) { if ($c === "\n") { $inLine = false; $cur .= $c; } $i++; continue; }
        if ($inBlock) {
            if ($c === '*' && $next === '/') { $inBlock = false; $i += 2; continue; }
            $i++; continue;
        }
        if (!$inS && !$inD) {
            if ($c === '-' && $next === '-') { $inLine = true; $i += 2; continue; }
            if ($c === '#') { $inLine = true; $i++; continue; }
            if ($c === '/' && $next === '*') { $inBlock = true; $i += 2; continue; }
            if ($c === ';') {
                if (trim($cur) !== '') $stmts[] = trim($cur);
                $cur = ''; $i++; continue;
            }
        }
        $cur .= $c;
        if ($c === '\\') { $cur .= $next; $i += 2; continue; }   // escaped char
        if (!$inS && $c === "'") $inS = true;
        elseif (!$inD && $c === '"') $inD = true;
        elseif ($inS && $c === "'") {
            if ($next === "'") { $cur .= "'"; $i++; continue; }
            $inS = false;
        }
        elseif ($inD && $c === '"') $inD = false;
        $i++;
    }
    if (trim($cur) !== '') $stmts[] = trim($cur);
    return $stmts;
}

/** Execute statements one-by-one and collect results. */
function run_statements(mysqli $conn, array $stmts): array {
    $results = [];
    $idx = 0;
    foreach ($stmts as $s) {
        $idx++;
        try {
            $r = $conn->query($s);
            $results[] = [
                'no' => $idx,
                'sql' => mb_substr(preg_replace('/\s+/', ' ', $s), 0, 90),
                'ok' => (bool)$r,
                'err' => null,
            ];
        } catch (mysqli_sql_exception $e) {
            $results[] = [
                'no' => $idx,
                'sql' => mb_substr(preg_replace('/\s+/', ' ', $s), 0, 90),
                'ok' => false,
                'err' => $e->getMessage(),
            ];
        }
    }
    return $results;
}

$conn = db();
$present = medirush_tables_present($conn);

$results = [];
if (!$present) {
    // The auto-install already ran (via db()) and failed. Replay manually,
    // statement by statement, so the user sees the exact error.
    $verbose = true;
    $sqlFile = __DIR__ . '/database.sql';
    if (!is_file($sqlFile)) {
        $results = [[
            'no' => 0,
            'sql' => '– opening database.sql –',
            'ok' => false,
            'err' => 'File not found at C:\\xampp\\htdocs\\MEDIRUSH\\database.sql — make sure database.sql is inside the MEDIRUSH folder.',
        ]];
    } else {
        $sql = file_get_contents($sqlFile);
        $results = run_statements($conn, split_sql_statements($sql));
        $present = medirush_tables_present($conn); // re-check after replay
    }
}

$tables = [];
try {
    $tables = fetch_all(
        'SELECT table_name, table_rows FROM information_schema.tables '
        . 'WHERE table_schema = ? ORDER BY table_name', 's', [DB_NAME]
    );
} catch (Throwable $e) {
    $tables = [];
}
$autoErr = $GLOBALS['MEDIRUSH_INSTALL_ERR'] ?? null;
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><title>MEDIRUSH — Installer</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{font-family:"Segoe UI",system-ui,sans-serif;background:#f6f8fb;color:#1c2434;margin:0;padding:30px 16px}
.box{max-width:760px;margin:0 auto;background:#fff;padding:30px;border-radius:14px;box-shadow:0 8px 30px rgba(0,0,0,.08);line-height:1.6}
h1{font-size:1.35rem;margin:0 0 8px}code{background:#eef2f7;padding:1px 6px;border-radius:4px}
table{width:100%;border-collapse:collapse;margin-top:14px}
td,th{padding:7px 10px;border-bottom:1px solid #e2e8f0;text-align:left;font-size:.86rem;vertical-align:top}
th{background:#f1f5f9;font-size:.72rem;text-transform:uppercase;letter-spacing:.04em;color:#64748b}
.errrow{background:rgba(239,68,68,.06)}
.okbox{background:rgba(34,197,94,.12);border:1px solid rgba(34,197,94,.4);color:#15803d;padding:12px;border-radius:9px;margin-top:12px}
.errbox{background:rgba(239,68,68,.08);border:1px solid rgba(239,68,68,.4);color:#b91c1c;padding:12px;border-radius:9px;margin-top:12px}
a.btn{display:inline-block;background:#14b8a6;color:#fff;padding:10px 20px;border-radius:9px;text-decoration:none;font-weight:700;margin-top:16px}
small,.muted{color:#64748b}
</style>
</head>
<body>
<div class="box">
  <h1>⚡ MEDIRUSH — Database installer</h1>

  <?php if ($present): ?>
    <div class="okbox">✅ Success! The <code>medirush</code> database is installed and ready.</div>
    <?php if ($tables): ?>
      <table>
        <thead><tr><th>Table</th><th>Rows</th></tr></thead>
        <tbody>
        <?php foreach ($tables as $r): ?>
          <tr><td><code><?= e((string)$r['table_name']) ?></code></td><td><?= (int)$r['table_rows'] ?></td></tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
    <p style="margin-top:10px"><strong>Demo logins</strong> (password: <code>password</code>):<br>
      Admin: <code>admin@medirush.local</code> &nbsp;·&nbsp; User: <code>demo@medirush.local</code></p>
    <a class="btn" href="index.php">🏠 Go to the website</a>

  <?php else: ?>
    <?php if ($autoErr): ?>
      <div class="errbox"><strong>Automatic import failed:</strong> <?= e($autoErr) ?></div>
    <?php endif; ?>
    <p>The automatic import did not succeed. Below is a statement-by-statement replay of
       <code>database.sql</code> with the exact MySQL error(s):</p>
    <table>
      <thead><tr><th>#</th><th>Statement</th><th>Result</th></tr></thead>
      <tbody>
      <?php foreach ($results as $r): ?>
        <tr class="<?= $r['ok'] ? '' : 'errrow' ?>">
          <td><?= (int)$r['no'] ?></td>
          <td><code><?= e($r['sql']) ?></code></td>
          <td><?= $r['ok'] ? '✅' : '❌ ' . e($r['err'] ?? '') ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <p class="muted" style="margin-top:12px">If the table above is EMPTY and shows “File not found”, copy
      <code>database.sql</code> from the downloaded project into <code>C:\xampp\htdocs\MEDIRUSH\</code> and reload this page.
      Otherwise, paste the red ❌ row(s) to the assistant for a fix.</p>
    <a class="btn" href="install.php">🔄 Retry installer</a>
  <?php endif; ?>

  <p style="margin-top:16px"><small>This page runs <code>CREATE TABLE IF NOT EXISTS</code> statements, so re-running never duplicates data.</small></p>
</div>
</body>
</html>