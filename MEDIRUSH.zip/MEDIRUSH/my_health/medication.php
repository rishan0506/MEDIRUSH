<?php
/**
 * MEDIRUSH — my_health/medication.php — Medication manager: active/past meds + reminders.
 */
declare(strict_types=1);
$ROOT = '..';
$PAGE_TITLE = 'My Medications — MEDIRUSH';
$ACTIVE = 'my_health';
$SHOW_SIDEBAR = true;
require_once $ROOT . '/includes/auth.php';
require_login();

$user = current_user();
$userId = (int)$user['id'];

/* ------------------------------ POST handlers ------------------------------ */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    /* Add a medication (+ optional reminder) */
    if (isset($_POST['add_med'])) {
        $medName     = trim((string)($_POST['medicine_name'] ?? ''));
        $dosage      = mb_substr(trim((string)($_POST['dosage'] ?? '')), 0, 60);
        $frequency   = mb_substr(trim((string)($_POST['frequency'] ?? '')), 0, 60);
        $startDate   = trim((string)($_POST['start_date'] ?? ''));
        $endDateRaw  = trim((string)($_POST['end_date'] ?? ''));
        $endDate     = $endDateRaw !== '' ? $endDateRaw : null;
        $instructions= mb_substr(trim((string)($_POST['instructions'] ?? '')), 0, 500);
        $reminderRaw = trim((string)($_POST['reminder_time'] ?? ''));

        if (mb_strlen($medName) < 2) {
            flash('error', 'Medicine name must be at least 2 characters long.');
            redirect('my_health/medication.php');
        }
        $dStart = DateTime::createFromFormat('Y-m-d', $startDate);
        $tooEarly = (new DateTime('yesterday'))->format('Y-m-d');
        if ($startDate === '' || !$dStart || $dStart->format('Y-m-d') !== $startDate || $startDate < $tooEarly) {
            flash('error', 'Please provide a valid start date (no earlier than yesterday).');
            redirect('my_health/medication.php');
        }
        $dEnd = null;
        if ($endDate !== null) {
            $dEnd = DateTime::createFromFormat('Y-m-d', $endDate);
            if (!$dEnd || $dEnd->format('Y-m-d') !== $endDate || $endDate < $dStart->format('Y-m-d')) {
                flash('error', 'End date must be a valid date on or after the start date.');
                redirect('my_health/medication.php');
            }
        }
        $reminderTime = null;
        if ($reminderRaw !== '') {
            if (!preg_match('/^([01]\d|2[0-3]):([0-5]\d)$/', $reminderRaw)) {
                flash('error', 'Reminder time must be in HH:MM format (e.g. 08:30).');
                redirect('my_health/medication.php');
            }
            $reminderTime = $reminderRaw . ':00';
        }

        try {
            $stmt = db()->prepare(
                'INSERT INTO medications (user_id, medicine_name, dosage, frequency, start_date, end_date, instructions)
                 VALUES (?, ?, ?, ?, ?, ?, ?)'
            );
            $stmt->bind_param('issssss', $userId, $medName, $dosage, $frequency, $startDate, $endDate, $instructions);
            $stmt->execute();
            $medId = (int)db()->insert_id;
            $stmt->close();

            if ($reminderTime !== null) {
                $stmt = db()->prepare('INSERT INTO medication_reminders (medication_id, user_id, reminder_time, is_active) VALUES (?, ?, ?, 1)');
                $stmt->bind_param('iis', $medId, $userId, $reminderTime);
                $stmt->execute();
                $stmt->close();
            }
        } catch (Throwable $ex) {
            error_log('[MEDIRUSH] add_med failed: ' . $ex->getMessage());
            flash('error', 'Could not save the medication. Please try again.');
            redirect('my_health/medication.php');
        }

        add_notification($userId, 'medication', 'Medication added',
            'You started tracking "' . $medName . '"' . ($reminderTime !== null ? ' with a daily reminder at ' . $reminderRaw : '') . '.');
        flash('success', 'Medication "' . $medName . '" added.');
        redirect('my_health/medication.php');
    }

    /* Quick add reminder for an existing active med */
    if (isset($_POST['add_reminder'])) {
        $medId = (int)($_POST['medication_id'] ?? 0);
        $time  = trim((string)($_POST['reminder_time'] ?? ''));
        $med = fetch_one('SELECT id FROM medications WHERE id = ? AND user_id = ? AND is_active = 1 LIMIT 1', 'ii', [$medId, $userId]);
        if (!$med) {
            flash('error', 'Select one of your active medications first.');
            redirect('my_health/medication.php');
        }
        if (!preg_match('/^([01]\d|2[0-3]):([0-5]\d)$/', $time)) {
            flash('error', 'Reminder time must be in HH:MM format (e.g. 20:00).');
            redirect('my_health/medication.php');
        }
        $stmt = db()->prepare('INSERT INTO medication_reminders (medication_id, user_id, reminder_time, is_active) VALUES (?, ?, ?, 1)');
        $stmt->bind_param('iis', $medId, $userId, $time);
        $stmt->execute();
        $stmt->close();
        add_notification($userId, 'medication', 'Reminder added', 'A new medication reminder was set for ' . $time . '.');
        flash('success', 'Reminder added.');
        redirect('my_health/medication.php');
    }

    /* Pause / reactivate a medication */
    if (isset($_POST['toggle_med'])) {
        $id = (int)$_POST['toggle_med'];
        $row = fetch_one('SELECT is_active FROM medications WHERE id = ? AND user_id = ? LIMIT 1', 'ii', [$id, $userId]);
        if (!$row) {
            flash('error', 'Medication not found.');
            redirect('my_health/medication.php');
        }
        $newState = ( (int)$row['is_active'] === 1 ) ? 0 : 1;
        $stmt = db()->prepare('UPDATE medications SET is_active = ? WHERE id = ? AND user_id = ?');
        $stmt->bind_param('iii', $newState, $id, $userId);
        $stmt->execute();
        $stmt->close();
        flash('success', $newState === 1 ? 'Medication reactivated and back in your active list.' : 'Medication paused.');
        redirect('my_health/medication.php');
    }

    /* Delete a medication (and its reminders) */
    if (isset($_POST['delete_med'])) {
        $id = (int)$_POST['delete_med'];
        $row = fetch_one('SELECT id FROM medications WHERE id = ? AND user_id = ? LIMIT 1', 'ii', [$id, $userId]);
        if (!$row) {
            flash('error', 'Medication not found.');
            redirect('my_health/medication.php');
        }
        $stmt = db()->prepare('DELETE FROM medication_reminders WHERE medication_id = ? AND user_id = ?');
        $stmt->bind_param('ii', $id, $userId);
        $stmt->execute();
        $stmt->close();
        $stmt = db()->prepare('DELETE FROM medications WHERE id = ? AND user_id = ?');
        $stmt->bind_param('ii', $id, $userId);
        $stmt->execute();
        $stmt->close();
        flash('success', 'Medication and its reminders deleted.');
        redirect('my_health/medication.php');
    }

    /* Pause / resume a reminder */
    if (isset($_POST['toggle_reminder'])) {
        $id = (int)$_POST['toggle_reminder'];
        $row = fetch_one('SELECT is_active FROM medication_reminders WHERE id = ? AND user_id = ? LIMIT 1', 'ii', [$id, $userId]);
        if (!$row) {
            flash('error', 'Reminder not found.');
            redirect('my_health/medication.php');
        }
        $newState = ( (int)$row['is_active'] === 1 ) ? 0 : 1;
        $stmt = db()->prepare('UPDATE medication_reminders SET is_active = ? WHERE id = ? AND user_id = ?');
        $stmt->bind_param('iii', $newState, $id, $userId);
        $stmt->execute();
        $stmt->close();
        flash('success', $newState === 1 ? 'Reminder resumed.' : 'Reminder paused.');
        redirect('my_health/medication.php');
    }

    /* Delete a reminder */
    if (isset($_POST['delete_reminder'])) {
        $id = (int)$_POST['delete_reminder'];
        $stmt = db()->prepare('DELETE FROM medication_reminders WHERE id = ? AND user_id = ?');
        $stmt->bind_param('ii', $id, $userId);
        $stmt->execute();
        $stmt->close();
        flash('success', 'Reminder deleted.');
        redirect('my_health/medication.php');
    }

    flash('error', 'Unknown action.');
    redirect('my_health/medication.php');
}

require_once $ROOT . '/includes/header.php';

/* ------------------------------ Fetch data ------------------------------ */
$activeMeds = fetch_all(
    'SELECT * FROM medications WHERE user_id = ? AND is_active = 1 ORDER BY start_date DESC, id DESC',
    'i', [$userId]
);
$pastMeds = fetch_all(
    'SELECT * FROM medications WHERE user_id = ? AND is_active = 0 ORDER BY start_date DESC, id DESC',
    'i', [$userId]
);
$reminders = fetch_all(
    'SELECT r.id, r.medication_id, r.reminder_time, r.is_active, m.medicine_name, m.dosage
       FROM medication_reminders r
       INNER JOIN medications m ON m.id = r.medication_id
      WHERE r.user_id = ? AND m.user_id = ?
      ORDER BY r.reminder_time ASC',
    'ii', [$userId, $userId]
);

/* Reminder counts per medication */
$reminderCounts = [];
foreach (fetch_all('SELECT medication_id, COUNT(*) AS c FROM medication_reminders WHERE user_id = ? GROUP BY medication_id', 'i', [$userId]) as $rc) {
    $reminderCounts[(int)$rc['medication_id']] = (int)$rc['c'];
}

$hasReminders = [];
foreach ($reminders as $r) {
    $hasReminders[(int)$r['medication_id']][] = $r;
}
?>
<div class="sidebar-wrap">
  <div class="sidebar-main">
    <div class="container">

      <div style="margin: 28px 0 18px;">
        <h1 class="section-title" style="margin-bottom: 2px;">💊 Medications</h1>
        <p class="muted">Track what you take, pause what you've stopped and never miss a dose.</p>
      </div>

      <!-- Tabs: Active / Past / Reminders (wired by js/script.js) -->
      <div class="tabs" role="tablist">
        <button type="button" class="tab-btn active" data-tab="tabActive">Active (<?= count($activeMeds) ?>)</button>
        <button type="button" class="tab-btn" data-tab="tabPast">Past (<?= count($pastMeds) ?>)</button>
        <button type="button" class="tab-btn" data-tab="tabReminders">Reminders (<?= count($reminders) ?>)</button>
      </div>

      <!-- Tab: Active -->
      <div class="tab-panel" id="tabActive">
        <!-- Add medication form -->
        <div class="card">
          <div class="card-body">
            <h2 style="font-size: 1.1rem;">➕ Add a medication</h2>
            <form method="post" action="<?= e(u('my_health/medication.php')) ?>">
              <?= csrf_field() ?>
              <input type="hidden" name="add_med" value="1">
              <div class="grid grid-2">
                <div class="form-group">
                  <label class="form-label" for="medicine_name">Medicine name *</label>
                  <input class="form-input" type="text" id="medicine_name" name="medicine_name" minlength="2" maxlength="120" placeholder="e.g. Ibruprofen" required>
                </div>
                <div class="form-group">
                  <label class="form-label" for="dosage">Dosage <span class="muted">(≤ 60)</span></label>
                  <input class="form-input" type="text" id="dosage" name="dosage" maxlength="60" placeholder="e.g. 400 mg">
                </div>
                <div class="form-group">
                  <label class="form-label" for="frequency">Frequency <span class="muted">e.g. Twice daily</span></label>
                  <input class="form-input" type="text" id="frequency" name="frequency" maxlength="60" placeholder="e.g. Twice daily">
                </div>
                <div class="form-group">
                  <label class="form-label" for="start_date">Start date *</label>
                  <input class="form-input" type="date" id="start_date" name="start_date" required>
                </div>
                <div class="form-group">
                  <label class="form-label" for="end_date">End date <span class="muted">(optional)</span></label>
                  <input class="form-input" type="date" id="end_date" name="end_date">
                  <p class="form-help">Must be on or after the start date.</p>
                </div>
                <div class="form-group">
                  <label class="form-label" for="reminder_time">Daily reminder at</label>
                  <input class="form-input" type="time" id="reminder_time" name="reminder_time" placeholder="08:30">
                  <p class="form-help">Optional — creates a reminder for this medicine.</p>
                </div>
              </div>
              <div class="form-group">
                <label class="form-label" for="instructions">Instructions <span class="muted">(≤ 500)</span></label>
                <textarea class="form-textarea" id="instructions" name="instructions" maxlength="500" placeholder="e.g. Take after food with a full glass of water…"></textarea>
              </div>
              <button type="submit" class="btn btn-primary">💾 Save medication</button>
            </form>
          </div>
        </div>

        <!-- Active meds list -->
        <div style="margin-top: 20px;">
          <?php if (!$activeMeds): ?>
            <div class="empty-state card">
              <p style="font-size: 2.4rem; margin-bottom: 6px;">💊</p>
              <h3>No active medications</h3>
              <p>Add your first medication above to start tracking doses and reminders.</p>
            </div>
          <?php else: ?>
            <div class="card">
              <?php foreach ($activeMeds as $med): ?>
                <?php $endLabel = $med['end_date'] ? date('d M Y', strtotime((string)$med['end_date'])) : 'ongoing'; ?>
                <div class="list-row">
                  <div style="flex: 1 1 auto; min-width: 0;">
                    <strong>💊 <?= e($med['medicine_name']) ?></strong>
                    <p class="muted" style="margin: 2px 0;"><?= e($med['dosage']) ?><?= $med['dosage'] && $med['frequency'] ? ' · ' : '' ?><?= e($med['frequency']) ?></p>
                    <p class="muted" style="margin: 0; font-size: .85rem;">🗓 <?= e(date('d M Y', strtotime((string)$med['start_date']))) ?> → <?= e($endLabel) ?></p>
                    <?php if (trim((string)($med['instructions'] ?? '')) !== ''): ?>
                      <p class="form-help" style="margin-top: 4px;">📝 <?= e($med['instructions']) ?></p>
                    <?php endif; ?>
                  </div>
                  <div style="display: flex; gap: 6px; align-items: center; flex-wrap: wrap;">
                    <?php $count = $reminderCounts[(int)$med['id']] ?? 0; ?>
                    <span class="badge <?= $count > 0 ? 'badge-info' : '' ?>" title="Reminders for this medicine">⏰ <?= (int)$count ?></span>
                    <form method="post" action="<?= e(u('my_health/medication.php')) ?>">
                      <?= csrf_field() ?>
                      <input type="hidden" name="toggle_med" value="<?= (int)$med['id'] ?>">
                      <button type="submit" class="btn btn-outline btn-sm">⏸ Pause</button>
                    </form>
                    <form method="post" action="<?= e(u('my_health/medication.php')) ?>" onsubmit="return confirm('Delete this medication and its reminders?');">
                      <?= csrf_field() ?>
                      <input type="hidden" name="delete_med" value="<?= (int)$med['id'] ?>">
                      <button type="submit" class="btn btn-danger btn-sm">🗑 Delete</button>
                    </form>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>
      </div>

      <!-- Tab: Past -->
      <div class="tab-panel" id="tabPast" hidden>
        <?php if (!$pastMeds): ?>
          <div class="empty-state card">
            <p style="font-size: 2.4rem; margin-bottom: 6px;">🗄️</p>
            <h3>No past medications</h3>
            <p>Medications you pause or complete will appear here so your history stays tidy.</p>
          </div>
        <?php else: ?>
          <div class="card">
            <?php foreach ($pastMeds as $med): ?>
              <div class="list-row">
                <div style="flex: 1 1 auto; min-width: 0;">
                  <strong>💊 <?= e($med['medicine_name']) ?></strong>
                  <p class="muted" style="margin: 2px 0;"><?= e($med['dosage']) ?><?= $med['dosage'] && $med['frequency'] ? ' · ' : '' ?><?= e($med['frequency']) ?></p>
                  <p class="muted" style="margin: 0; font-size: .85rem;">
                    🗓 <?= e(date('d M Y', strtotime((string)$med['start_date']))) ?>
                    → <?= e($med['end_date'] ? date('d M Y', strtotime((string)$med['end_date'])) : 'on hold') ?>
                  </p>
                </div>
                <form method="post" action="<?= e(u('my_health/medication.php')) ?>">
                  <?= csrf_field() ?>
                  <input type="hidden" name="toggle_med" value="<?= (int)$med['id'] ?>">
                  <button type="submit" class="btn btn-outline btn-sm">↻ Reactivate</button>
                </form>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>

      <!-- Tab: Reminders -->
      <div class="tab-panel" id="tabReminders" hidden>
        <!-- Quick add reminder -->
        <div class="card">
          <div class="card-body">
            <h2 style="font-size: 1.1rem;">⏰ Add a reminder</h2>
            <?php if ($activeMeds): ?>
              <form method="post" action="<?= e(u('my_health/medication.php')) ?>" style="display: flex; gap: 10px; flex-wrap: wrap; align-items: flex-end;">
                <?= csrf_field() ?>
                <input type="hidden" name="add_reminder" value="1">
                <div class="form-group" style="flex: 1 1 240px; margin-bottom: 0;">
                  <label class="form-label" for="reminder_med">Medication</label>
                  <select class="form-select" id="reminder_med" name="medication_id" required>
                    <?php foreach ($activeMeds as $med): ?>
                      <option value="<?= (int)$med['id'] ?>"><?= e($med['medicine_name']) ?><?= $med['dosage'] ? ' (' . e($med['dosage']) . ')' : '' ?></option>
                    <?php endforeach; ?>
                  </select>
                </div>
                <div class="form-group" style="flex: 0 1 160px; margin-bottom: 0;">
                  <label class="form-label" for="extra_time">Time</label>
                  <input class="form-input" type="time" id="extra_time" name="reminder_time" required>
                </div>
                <button type="submit" class="btn btn-primary">🔔 Add reminder</button>
              </form>
            <?php else: ?>
              <p class="muted" style="margin: 0;">Add an <strong>active</strong> medication first — reminders attach to active medicines.</p>
            <?php endif; ?>
          </div>
        </div>

        <div style="margin-top: 20px;">
          <?php if (!$reminders): ?>
            <div class="empty-state card">
              <p style="font-size: 2.4rem; margin-bottom: 6px;">🔔</p>
              <h3>No reminders yet</h3>
              <p>Set daily times for your active medicines so you never miss a dose.</p>
            </div>
          <?php else: ?>
            <div class="card">
              <?php foreach ($reminders as $rem): ?>
                <?php $t = substr((string)$rem['reminder_time'], 0, 5); // "07:30:00" → "07:30" ?>
                <div class="list-row">
                  <div style="flex: 1 1 auto; min-width: 0;">
                    <strong>⏰ <?= e($t) ?></strong> — <?= e($rem['medicine_name']) ?>
                    <?php if ($rem['dosage']): ?><span class="muted">· <?= e($rem['dosage']) ?></span><?php endif; ?>
                    <span class="badge <?= (int)$rem['is_active'] === 1 ? 'badge-success' : 'badge-warning' ?>"><?= (int)$rem['is_active'] === 1 ? 'Active' : 'Paused' ?></span>
                  </div>
                  <div style="display: flex; gap: 6px; align-items: center; flex-wrap: wrap;">
                    <form method="post" action="<?= e(u('my_health/medication.php')) ?>">
                      <?= csrf_field() ?>
                      <input type="hidden" name="toggle_reminder" value="<?= (int)$rem['id'] ?>">
                      <button type="submit" class="btn btn-outline btn-sm"><?= (int)$rem['is_active'] === 1 ? '⏸ Pause' : '▶ Resume' ?></button>
                    </form>
                    <form method="post" action="<?= e(u('my_health/medication.php')) ?>">
                      <?= csrf_field() ?>
                      <input type="hidden" name="delete_reminder" value="<?= (int)$rem['id'] ?>">
                      <button type="submit" class="btn btn-danger btn-sm">🗑</button>
                    </form>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>
      </div>

      <p class="form-help" style="margin: 24px 0 10px;">⚠️ This tracker is a planning aid only — always follow the directions on your prescription and consult a pharmacist for dosing questions.</p>

    </div>
  </div>
</div>
<?php require_once $ROOT . '/includes/footer.php'; ?>
