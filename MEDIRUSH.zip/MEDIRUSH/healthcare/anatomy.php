<?php
/**
 * MEDIRUSH — Interactive anatomy explorer (public page).
 * Realistic medical body map with an interactive SVG anatomical figure.
 */
$ROOT = '..';
$PAGE_TITLE = 'Interactive Anatomy — MEDIRUSH';
$ACTIVE = 'healthcare';
require_once $ROOT . '/includes/header.php';

/* Organ & System data */
$organs = [
    ['id' => 'brain', 'name' => 'Brain & Nervous System', 'pos' => ['top' => '8%', 'left' => '50%'],
     'desc' => 'The control centre of the body, running your thoughts, memory, movement and hormones through about 86 billion nerve cells. It uses up to 20% of your daily energy.',
     'tips' => '💡 Tip: Sleep 7–9 hours a night and challenge your mind with puzzles or a new skill.'],
    ['id' => 'eyes', 'name' => 'Vision & Eyes', 'pos' => ['top' => '13%', 'left' => '50%'],
     'desc' => 'The eyes turn light into electrical signals for the brain, delivering about 80% of everything you perceive. They can distinguish around 10 million different colours.',
     'tips' => '💡 Tip: Follow the 20-20-20 rule — every 20 minutes look 6 m away for 20 seconds, and book an eye test every 1–2 years.'],
    ['id' => 'heart', 'name' => 'Heart & Cardiovascular', 'pos' => ['top' => '32%', 'left' => '54%'],
     'desc' => 'A muscle about the size of your fist that pumps oxygen-rich blood to every organ in the body. It beats roughly 100,000 times a day without ever taking a rest.',
     'tips' => '💡 Tip: Aim for at least 150 minutes of moderate exercise a week and keep added salt under 5 g a day.'],
    ['id' => 'lungs', 'name' => 'Lungs & Respiratory', 'pos' => ['top' => '30%', 'left' => '44%'],
     'desc' => 'Two sponge-like organs that take in oxygen and release carbon dioxide with every one of your ~20,000 daily breaths. Tiny air sacs called alveoli do the actual gas exchange.',
     'tips' => '💡 Tip: Stay smoke-free and practise slow belly breathing for 5 minutes a day.'],
    ['id' => 'stomach', 'name' => 'Stomach & Digestion', 'pos' => ['top' => '42%', 'left' => '53%'],
     'desc' => 'A stretchy muscular bag that mixes food with strong acid and enzymes to start digestion. It holds about a litre when comfortably full and empties into the small intestine.',
     'tips' => '💡 Tip: Eat slowly, choose smaller regular meals, and limit very spicy or acidic late-night meals.'],
    ['id' => 'liver', 'name' => 'Liver & Metabolism', 'pos' => ['top' => '40%', 'left' => '43%'],
     'desc' => 'Your largest internal organ and chemical factory: it processes nutrients, stores vitamins and iron, breaks down medicines and alcohol, and makes bile for fat digestion. It can even regrow itself.',
     'tips' => '💡 Tip: Moderate or avoid alcohol, keep to a healthy weight, and never mix medicine with heavy drinking.'],
    ['id' => 'kidneys', 'name' => 'Kidneys & Renal', 'pos' => ['top' => '48%', 'left' => '47%'],
     'desc' => 'Two bean-shaped filters that clean your blood around 40 times a day, removing waste and extra water as urine. They also balance salts and help control blood pressure.',
     'tips' => '💡 Tip: Drink water regularly and keep blood pressure and sugar in the healthy range.'],
    ['id' => 'bones', 'name' => 'Skeletal & Bones', 'pos' => ['top' => '65%', 'left' => '50%'],
     'desc' => 'A living skeleton of 206 bones that supports your body, protects organs and stores minerals while making new blood cells in the marrow. Bones rebuild themselves constantly.',
     'tips' => '💡 Tip: Get calcium (dairy, greens, pilchards), some daily sunshine for vitamin D, and do weight-bearing exercise.'],
];
?>

<section class="section">
  <h1 class="section-title">🧭 Human Anatomy &amp; Systems</h1>
  <p class="section-subtitle">
    Select an anatomical region from the directory or click its interactive marker directly on the medical body model.
  </p>

  <div class="anatomy-layout">
    <!-- LEFT: Professional Medical Directory -->
    <div class="organ-list">
      <?php foreach ($organs as $organ): ?>
        <button type="button" class="organ-btn"
                data-target="<?= e($organ['id']) ?>"
                data-name="<?= e($organ['name']) ?>"
                data-desc="<?= e($organ['desc']) ?>"
                data-tips="<?= e($organ['tips']) ?>">
          <span class="organ-indicator"></span>
          <span class="organ-btn-text"><?= e($organ['name']) ?></span>
        </button>
      <?php endforeach; ?>
      <p class="form-help mt-3">🔬 Interactive model highlights clinical regions instantly.</p>
    </div>

    <!-- RIGHT: Realistic Medical Body Diagram & Panel -->
    <div class="anatomy-visual-wrap">
      <div class="card anatomy-body-card">
        <div class="anatomy-body-header">
          <h3>3D Anatomical Body Map</h3>
          <span class="badge badge-info">Clinical Ecorché Model</span>
        </div>
        
        <!-- Realistic Vector Anatomical Silhouette Container -->
        <div class="body-silhouette-container">
          <div class="realistic-body-silhouette">
            <!-- Professional SVG Human Outline Overlay -->
            <svg class="body-svg-outline" viewBox="0 0 200 450" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M100 15 C85 15 75 25 75 40 C75 55 85 65 100 65 C115 65 125 55 125 40 C125 25 115 15 100 15 Z" fill="currentColor" opacity="0.15"/>
              <path d="M85 70 C70 72 55 80 50 100 L40 180 C38 200 45 210 55 210 C65 210 70 190 75 160 L85 110 L115 110 L125 160 C130 190 135 210 145 210 C155 210 162 200 160 180 L150 100 C145 80 130 72 115 70 Z" fill="currentColor" opacity="0.1"/>
              <path d="M75 110 L65 240 C62 270 58 350 55 420 C54 435 65 440 72 430 L85 340 L100 240 L115 340 L128 430 C135 440 146 435 145 420 C142 350 138 270 135 240 L125 110 Z" fill="currentColor" opacity="0.1"/>
            </svg>

            <!-- Interactive Pulse Pins Positioned Precisely Over Body Anatomy -->
            <?php foreach ($organs as $organ): ?>
              <button type="button" class="anatomical-pin" 
                      data-target="<?= e($organ['id']) ?>" 
                      style="top: <?= e($organ['pos']['top']) ?>; left: <?= e($organ['pos']['left']) ?>;"
                      title="<?= e($organ['name']) ?>">
                <span class="pin-dot"></span>
                <span class="pin-pulse"></span>
                <span class="pin-label"><?= e(explode(' ', $organ['name'])[0]) ?></span>
              </button>
            <?php endforeach; ?>
          </div>
        </div>
      </div>

      <!-- Detail Panel -->
      <div id="organPanel" class="card organ-panel">
        <div class="organ-name">Select an anatomical system</div>
        <p class="organ-desc muted">Click any system on the left or select a pulsing marker on the medical body map above to inspect its function and clinical guidance.</p>
        <div class="organ-tips">💡 Patient recommendations will appear here.</div>
      </div>
    </div>
  </div>
</section>

<style>
.anatomy-layout {
  display: grid;
  grid-template-columns: 280px 1fr;
  gap: 24px;
  align-items: start;
}
.organ-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.organ-btn {
  display: flex;
  align-items: center;
  gap: 12px;
  width: 100%;
  background: var(--card-bg);
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  padding: 12px 16px;
  cursor: pointer;
  font: inherit;
  color: var(--text);
  font-weight: 600;
  transition: all 0.2s ease;
  text-align: left;
}
.organ-btn:hover {
  border-color: var(--primary);
  background: var(--primary-soft);
}
.organ-btn.active {
  background: var(--primary-soft);
  border-color: var(--primary);
  color: var(--primary-dark);
  box-shadow: 0 4px 12px rgba(20,184,166,0.15);
}
.organ-indicator {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--border);
  transition: all 0.2s;
}
.organ-btn.active .organ-indicator {
  background: var(--primary);
  box-shadow: 0 0 8px var(--primary);
}

/* Realistic Medical Model Styling */
.anatomy-body-card {
  background: linear-gradient(180deg, var(--card-bg) 0%, rgba(20,184,166,0.03) 100%);
  padding: 24px;
}
.anatomy-body-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}
.body-silhouette-container {
  display: flex;
  justify-content: center;
  padding: 10px 0;
}
.realistic-body-silhouette {
  width: 220px;
  height: 440px;
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  background: rgba(15, 23, 42, 0.03);
  border-radius: 30px;
  border: 1px solid var(--border);
}
[data-theme="dark"] .realistic-body-silhouette {
  background: rgba(255, 255, 255, 0.02);
}
.body-svg-outline {
  width: 100%;
  height: 100%;
  color: var(--primary);
}

/* Pulsing Anatomical Pins */
.anatomical-pin {
  position: absolute;
  transform: translate(-50%, -50%);
  background: none;
  border: none;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 4px;
  z-index: 5;
}
.pin-dot {
  width: 12px;
  height: 12px;
  background: var(--primary);
  border: 2px solid #fff;
  border-radius: 50%;
  box-shadow: 0 0 8px rgba(0,0,0,0.3);
  position: relative;
  z-index: 2;
  transition: transform 0.2s;
}
.pin-pulse {
  position: absolute;
  top: 4px;
  left: 4px;
  width: 20px;
  height: 20px;
  background: var(--primary);
  border-radius: 50%;
  opacity: 0.6;
  animation: pulsePin 2s infinite;
  z-index: 1;
}
.pin-label {
  background: var(--card-bg);
  border: 1px solid var(--border);
  color: var(--text);
  font-size: 0.72rem;
  font-weight: 700;
  padding: 2px 6px;
  border-radius: 4px;
  box-shadow: 0 2px 6px rgba(0,0,0,0.08);
  white-space: nowrap;
  pointer-events: none;
}
@keyframes pulsePin {
  0% { transform: scale(0.8); opacity: 0.8; }
  70% { transform: scale(2.2); opacity: 0; }
  100% { transform: scale(0.8); opacity: 0; }
}

.anatomical-pin:hover .pin-dot,
.anatomical-pin.active-pin .pin-dot {
  transform: scale(1.4);
  background: var(--accent);
}
.anatomical-pin.active-pin .pin-label {
  background: var(--primary);
  color: #fff;
  border-color: var(--primary);
}

.organ-panel {
  margin-top: 16px;
  border-left: 4px solid var(--primary);
}
.organ-name {
  font-size: 1.3rem;
  font-weight: 800;
  margin-bottom: 6px;
  color: var(--text);
}
.organ-desc {
  color: var(--muted);
  line-height: 1.6;
}
.organ-tips {
  margin-top: 14px;
  padding: 12px 14px;
  border-radius: var(--radius-sm);
  background: var(--primary-soft);
  font-size: 0.9rem;
  color: var(--text);
  font-weight: 500;
}

@media (max-width: 768px) {
  .anatomy-layout {
    grid-template-columns: 1fr;
  }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const buttons = document.querySelectorAll('.organ-btn, .anatomical-pin');
  const panel = document.getElementById('organPanel');

  buttons.forEach(btn => {
    btn.addEventListener('click', function() {
      const targetId = this.getAttribute('data-target');
      const matchingBtn = document.querySelector(`.organ-btn[data-target="${targetId}"]`);
      if (!matchingBtn) return;

      const name = matchingBtn.getAttribute('data-name');
      const desc = matchingBtn.getAttribute('data-desc');
      const tips = matchingBtn.getAttribute('data-tips');

      document.querySelectorAll('.organ-btn').forEach(b => b.classList.remove('active'));
      matchingBtn.classList.add('active');

      document.querySelectorAll('.anatomical-pin').forEach(p => p.classList.remove('active-pin'));
      const activePin = document.querySelector(`.anatomical-pin[data-target="${targetId}"]`);
      if (activePin) activePin.classList.add('active-pin');

      if (panel) {
        panel.querySelector('.organ-name').textContent = name;
        panel.querySelector('.organ-desc').textContent = desc;
        panel.querySelector('.organ-tips').innerHTML = tips;
      }
    });
  });

  const firstBtn = document.querySelector('.organ-btn');
  if (firstBtn) firstBtn.click();
});
</script>

<?php require_once $ROOT . '/includes/footer.php'; ?>