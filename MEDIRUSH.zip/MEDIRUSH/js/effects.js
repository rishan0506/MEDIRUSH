/* ============================================================
   MEDIRUSH — js/effects.js  (v2)
   One job: wire the hero video ONLY when assets/videos/hero.mp4
   actually exists (HEAD probe — never any 404 requests). If it
   doesn't, the static poster + gradient stays, nothing moves.
   The interaction ripple code was removed for a clean,
   professional feel.
   ============================================================ */
(function () {
  'use strict';

  var REDUCED =
    window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (REDUCED) document.documentElement.classList.add('reduced-motion');

  function initHeroVideo() {
    var video = document.querySelector('.hero-video');
    if (!video || REDUCED) return;                     // static fallback stays
    var src = video.getAttribute('data-src');
    if (!src) return;

    // Availability probe first: no 404s when the demo video isn't installed.
    fetch(src, { method: 'HEAD' })
      .then(function (res) {
        var type = res.headers ? res.headers.get('content-type') || '' : '';
        if (!res.ok || !(type === '' || type.indexOf('video') === 0)) {
          throw new Error('no video');
        }
        video.src = src;
        video.load();
        var go = function () {
          video.classList.add('is-ready');             // fade in over poster
          var p = video.play();
          if (p && p.catch) p.catch(function () { /* autoplay block: poster stays */ });
        };
        if (video.readyState >= 2) go();
        else video.addEventListener('canplay', go, { once: true });
      })
      .catch(function () {
        /* No video file → static poster + premium gradient only. Done. */
      });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initHeroVideo);
  } else {
    initHeroVideo();
  }
})();