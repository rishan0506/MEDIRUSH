<?php
/**
 * MEDIRUSH — my_health/upload.php — Document uploads (prescriptions & medical records).
 * Interactions handled by js/upload.js; processing by upload_process.php.
 */
declare(strict_types=1);
$ROOT = '..';
$PAGE_TITLE = 'Upload Documents — MEDIRUSH';
$ACTIVE = 'my_health';
$SHOW_SIDEBAR = true;
require_once $ROOT . '/includes/auth.php';
require_login();

$user = current_user();
$userId = (int)$user['id'];

/* ------------------------------ POST handlers ------------------------------ */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $uploadBaseFs = realpath(__DIR__ . '/../assets/uploads');

    /** Safely remove the stored file: basename containment inside assets/uploads. */
    $safe_unlink = static function (string $filePath) use ($uploadBaseFs): void {
        if ($filePath === '' || $uploadBaseFs === false) return;
        $base = basename($filePath);
        if ($base === '' || $base === '.' || $base === '..') return;
        $fs = realpath(__DIR__ . '/../' . ltrim($filePath, '/\\'));
        if ($fs !== false && dirname($fs) === $uploadBaseFs && basename($fs) === $base) {
            @unlink($fs);
        }
    };

    if (isset($_POST['delete_prescription']) || isset($_POST['delete_record'])) {
        $isRx  = isset($_POST['delete_prescription']);
        $rawId = (string)($isRx ? $_POST['delete_prescription'] : $_POST['delete_record']);
        $id    = filter_var($rawId, FILTER_VALIDATE_INT);
        if ($id === false || $id <= 0) {
            flash('error', 'Invalid document selected.');
            redirect('my_health/upload.php');
        }
        if ($isRx) {
            $row = fetch_one('SELECT file_path FROM prescriptions WHERE id = ? AND user_id = ? LIMIT 1', 'ii', [$id, $userId]);
            if (!$row) {
                flash('error', 'That prescription could not be found.');
                redirect('my_health/upload.php');
            }
            $stmt = db()->prepare('DELETE FROM prescriptions WHERE id = ? AND user_id = ?');
            $stmt->bind_param('ii', $id, $userId);
            $stmt->execute();
            $stmt->close();
            flash('success', 'Prescription deleted.');
        } else {
            $row = fetch_one('SELECT file_path FROM medical_records WHERE id = ? AND user_id = ? LIMIT 1', 'ii', [$id, $userId]);
            if (!$row) {
                flash('error', 'That record could not be found.');
                redirect('my_health/upload.php');
            }
            $stmt = db()->prepare('DELETE FROM medical_records WHERE id = ? AND user_id = ?');
            $stmt->bind_param('ii', $id, $userId);
            $stmt->execute();
            $stmt->close();
            flash('success', 'Medical record deleted.');
        }
        $safe_unlink((string)$row['file_path']);
        redirect('my_health/upload.php');
    }

    flash('error', 'Unknown action.');
    redirect('my_health/upload.php');
}

require_once $ROOT . '/includes/header.php';

/* Lists */
$prescriptions = fetch_all(
    'SELECT id, doctor_name, file_path, original_filename, status, admin_note, uploaded_at
       FROM prescriptions WHERE user_id = ? ORDER BY uploaded_at DESC',
    'i', [$userId]
);
$records = fetch_all(
    'SELECT id, title, record_type, file_path, original_filename, uploaded_at
       FROM medical_records WHERE user_id = ? ORDER BY uploaded_at DESC',
    'i', [$userId]
);

$recordTypeLabels = ['lab_result' => 'Lab result', 'report' => 'Report', 'scan' => 'Scan', 'other' => 'Other'];
$rxBadges  = ['pending' => 'badge badge-warning', 'approved' => 'badge badge-success', 'rejected' => 'badge badge-danger'];
$rxLabels  = ['pending' => '⏳ Pending', 'approved' => '✅ Approved', 'rejected' => '❌ Rejected'];
?>
<div class="sidebar-wrap">
  <div class="sidebar-main">
    <div class="container">

      <div style="margin: 28px 0 18px;">
        <h1 class="section-title" style="margin-bottom: 2px;">📤 Upload documents</h1>
        <p class="muted">Upload prescriptions for pharmacist review, or keep lab results, scans and reports in your private health file.</p>
      </div>

      <!-- (A) Upload form — wired to js/upload.js by exact element IDs -->
      <div class="card">
        <div class="card-body">
          <form id="uploadForm" method="post" enctype="multipart/form-data" action="<?= e(u('my_health/upload_process.php')) ?>" novalidate>
            <?= csrf_field() /* hidden csrf_token */ ?>
            <input type="hidden" name="ajax" value="1">

            <div class="form-group">
              <label class="form-label" for="docType">Document type</label>
              <select class="form-select" id="docType" name="doc_type" required>
                <option value="prescription">Prescription (pharmacist review)</option>
                <option value="record">Medical record (private file)</option>
              </select>
            </div>

            <div class="form-group" id="recordTypeWrap" hidden>
              <label class="form-label" for="recordType">Record type</label>
              <select class="form-select" id="recordType" name="record_type">
                <option value="lab_result">Lab result</option>
                <option value="report">Report</option>
                <option value="scan">Scan</option>
                <option value="other">Other</option>
              </select>
              <p class="form-help">Helps you find the right document later.</p>
            </div>

            <div class="form-group" id="doctorNameWrap">
              <label class="form-label" for="doctorName">Prescribing doctor <span class="muted">(optional)</span></label>
              <input class="form-input" type="text" id="doctorName" name="doctor_name" maxlength="120" placeholder="e.g. Dr T. Myers">
            </div>

            <div class="form-group" id="recordTitleWrap" hidden>
              <label class="form-label" for="recordTitle">Record title <span class="muted">(optional)</span></label>
              <input class="form-input" type="text" id="recordTitle" name="title" maxlength="120" placeholder="e.g. Full blood count, Jan 2026">
            </div>

            <div class="form-group">
              <label class="form-label" for="docNotes">Notes <span class="muted">(optional)</span></label>
              <textarea class="form-textarea" id="docNotes" name="notes" maxlength="500" placeholder="Anything you want to remember about this document…"></textarea>
            </div>

            <div class="form-group">
              <label class="form-label" for="uploadFile">Document</label>
              <div class="dropzone" id="uploadDropzone" role="button" tabindex="0" aria-label="Choose or drop a file">
                <p class="dropzone-icon">📎</p>
                <p><strong>Drag &amp; drop a file here</strong><br><span class="muted">or click to browse</span></p>
                <input type="file" id="uploadFile" name="document_file" accept=".jpg,.jpeg,.png,.webp,.pdf" style="margin-top: 12px;">
              </div>
              <p class="form-help">
                Allowed formats: JPG, PNG, WEBP and PDF · Maximum size 5&nbsp;MB · Files are stored privately and only you can open them.
              </p>
              <ul class="form-help" style="margin-left: 18px;">
                <li>Step 1 — choose the document type above</li>
                <li>Step 2 — drop or select your file</li>
                <li>Step 3 — check the preview, then press Upload</li>
              </ul>
            </div>

            <ul id="uploadList" hidden></ul>

            <div id="uploadPreview" hidden>
              <div class="upload-preview">
                <div class="preview-frame">
                  <span id="previewIcon">📄</span>
                  <img id="previewImage" src="" alt="File preview" hidden>
                </div>
                <p><strong id="previewFileName"></strong><br><span id="previewFileSize" class="muted" style="font-size: .85rem;"></span></p>
              </div>
            </div>

            <div id="uploadProgress" hidden>
              <div class="progress" role="progressbar" aria-label="Upload progress">
                <div class="progress-bar" id="uploadProgressBar"></div>
              </div>
              <small class="muted" id="uploadProgressLabel" style="margin-top: 6px; display: block;">Uploading… 0%</small>
            </div>

            <div class="alert alert-error" id="uploadError" hidden role="alert"></div>

            <div style="display: flex; gap: 10px; margin-top: 16px; flex-wrap: wrap;">
              <button type="submit" class="btn btn-primary" id="uploadSubmit" disabled>⬆️ Upload document</button>
              <button type="button" class="btn btn-outline" id="uploadClear">✖ Clear selection</button>
            </div>
          </form>

          <script>
          /* Show/hide doc-type-dependent fields (record_type only — required by spec). */
          (function () {
            var sel = document.getElementById('docType');
            if (!sel) return;
            function sync() {
              var isRx = sel.value === 'prescription';
              var w = document.getElementById('recordTypeWrap');
              var d = document.getElementById('doctorNameWrap');
              var t = document.getElementById('recordTitleWrap');
              if (w) w.hidden = isRx;
              if (d) d.hidden = !isRx;
              if (t) t.hidden = isRx;
            }
            sel.addEventListener('change', sync);
            sync();
          })();
          </script>
        </div>
      </div>

      <!-- (B) My prescriptions -->
      <div style="margin-top: 28px;">
        <h2 class="section-title" style="font-size: 1.25rem;">💊 My prescriptions</h2>
        <p class="muted" style="margin-bottom: 12px;">Prescriptions are reviewed by the MEDIRUSH pharmacy team before they can be dispensed.</p>
        <?php if (!$prescriptions): ?>
          <div class="empty-state card">
            <p style="font-size: 2.4rem; margin-bottom: 6px;">💊</p>
            <h3>No prescriptions yet</h3>
            <p>Upload a prescription above and our pharmacy team will review it shortly.</p>
          </div>
        <?php else: ?>
          <div class="table-wrap">
            <table class="table">
              <thead>
                <tr><th>File</th><th>Doctor</th><th>Status</th><th>Uploaded</th><th></th></tr>
              </thead>
              <tbody>
                <?php foreach ($prescriptions as $rx): ?>
                  <?php $st = $rx['status'] ?? 'pending'; ?>
                  <?php $viewUrl = u('download.php') . '?file=' . rawurlencode(basename((string)$rx['file_path'])); ?>
                  <tr>
                    <td><strong>💊 <?= e($rx['original_filename']) ?></strong></td>
                    <td><?= $rx['doctor_name'] ? e($rx['doctor_name']) : '<span class="muted">—</span>' ?></td>
                    <td>
                      <span class="<?= $rxBadges[$st] ?? 'badge badge-info' ?>"><?= e($rxLabels[$st] ?? ucfirst((string) $st)) ?></span>
                      <?php if ($st === 'rejected' && trim((string)($rx['admin_note'] ?? '')) !== ''): ?>
                        <p class="muted" style="font-size: .82rem; margin: 4px 0 0;">⚠️ <?= e($rx['admin_note']) ?></p>
                      <?php endif; ?>
                    </td>
                    <td><span class="muted"><?= e(date('d M Y, H:i', strtotime((string)$rx['uploaded_at']))) ?></span></td>
                    <td style="text-align: right;">
                      <div style="display: inline-flex; gap: 6px; align-items: center; flex-wrap: wrap;">
                        <a class="btn btn-outline btn-sm" href="<?= e($viewUrl) ?>">👁 View</a>
                        <form method="post" action="<?= e(u('my_health/upload.php')) ?>" onsubmit="return confirm('Delete this prescription and its file?');">
                          <?= csrf_field() ?>
                          <input type="hidden" name="delete_prescription" value="<?= (int)$rx['id'] ?>">
                          <button type="submit" class="btn btn-danger btn-sm" title="Delete prescription">🗑</button>
                        </form>
                      </div>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </div>

      <!-- (C) My medical records -->
      <div style="margin: 28px 0 10px;">
        <h2 class="section-title" style="font-size: 1.25rem;">📁 My medical records</h2>
        <p class="muted" style="margin-bottom: 12px;">Lab results, scans and reports belong to your private health file — only you can open them.</p>
        <?php if (!$records): ?>
          <div class="empty-state card">
            <p style="font-size: 2.4rem; margin-bottom: 6px;">📁</p>
            <h3>No medical records yet</h3>
            <p>Add lab results, scans or reports via the upload form to build a complete health history.</p>
          </div>
        <?php else: ?>
          <div class="table-wrap">
            <table class="table">
              <thead>
                <tr><th>File</th><th>Type</th><th>Uploaded</th><th></th></tr>
              </thead>
              <tbody>
                <?php foreach ($records as $rec): ?>
                  <?php $viewUrl = u('download.php') . '?file=' . rawurlencode(basename((string)$rec['file_path'])); ?>
                  <tr>
                    <td><strong>📄 <?= e($rec['original_filename']) ?></strong>
                      <?php if (trim((string)($rec['title'] ?? '')) !== ''): ?>
                        <span class="muted">· <?= e($rec['title']) ?></span>
                      <?php endif; ?>
                    </td>
                    <td><span class="badge badge-info"><?= e($recordTypeLabels[$rec['record_type']] ?? 'Other') ?></span></td>
                    <td><span class="muted"><?= e(date('d M Y, H:i', strtotime((string)$rec['uploaded_at']))) ?></span></td>
                    <td style="text-align: right;">
                      <div style="display: inline-flex; gap: 6px; align-items: center; flex-wrap: wrap;">
                        <a class="btn btn-outline btn-sm" href="<?= e($viewUrl) ?>">👁 View</a>
                        <a class="btn btn-sm" href="<?= e($viewUrl) . '&download=1' ?>">⬇ Download</a>
                        <form method="post" action="<?= e(u('my_health/upload.php')) ?>" onsubmit="return confirm('Delete this record and its file?');">
                          <?= csrf_field() ?>
                          <input type="hidden" name="delete_record" value="<?= (int)$rec['id'] ?>">
                          <button type="submit" class="btn btn-danger btn-sm" title="Delete record">🗑</button>
                        </form>
                      </div>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </div>

    </div>
  </div>
</div>
<script src="<?= e(u('js/upload.js')) ?>"></script>
<?php require_once $ROOT . '/includes/footer.php'; ?>
