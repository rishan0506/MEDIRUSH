<?php
/**
 * MEDIRUSH — Reusable functions: helpers, CSRF, output escaping, flash messages.
 */
declare(strict_types=1);

/** Escape for HTML output. */
function e($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

/** URL relative to the current page's folder: u('css/style.css'), u('pharmacy/pharmacy.php'). */
function u(string $path): string {
    global $ROOT;
    $root = isset($ROOT) && $ROOT !== '' ? rtrim($ROOT, '/\\') : '.';
    return $root . '/' . ltrim($path, '/\\');
}

/** Redirect to an internal path and stop. */
function redirect(string $path): void {
    header('Location: ' . u($path));
    exit;
}

/** Money formatting (ZAR). */
function money($amount): string {
    return 'R ' . number_format((float)$amount, 2);
}

/* ----------------------------- CSRF protection ---------------------------- */

function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string {
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

function verify_csrf(): void {
    $sent = (string)($_POST['csrf_token'] ?? '');
    if ($sent === '' || !hash_equals($_SESSION['csrf_token'] ?? '', $sent)) {
        http_response_code(403);
        flash('error', 'Security check failed — please refresh the page and try again.');
        redirect('index.php');
    }
}

/* ------------------------------- Flash messages --------------------------- */

function flash(string $type, string $message): void {
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

function display_flash(): void {
    if (empty($_SESSION['flash'])) return;
    foreach ($_SESSION['flash'] as $f) {
        $cls = match ($f['type']) { 'success' => 'alert-success', 'error' => 'alert-error', default => 'alert-info' };
        $icon = match ($f['type']) { 'success' => '✅', 'error' => '⚠️', default => 'ℹ️' };
        echo '<div class="alert ' . $cls . '">' . $icon . ' ' . e($f['message']) . '</div>';
    }
    unset($_SESSION['flash']);
}

/* ----------------------------- DB convenience ----------------------------- */

/** Fetch all rows of a prepared query. */
function fetch_all(string $sql, string $types = '', array $params = []): array {
    $stmt = db()->prepare($sql);
    if ($types !== '') $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return $rows;
}

/** Fetch one row (or null). */
function fetch_one(string $sql, string $types = '', array $params = []): ?array {
    $stmt = db()->prepare($sql);
    if ($types !== '') $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $row ?: null;
}

/** Create (once) and return the user's cart id. */
function get_or_create_cart(int $userId): int {
    $cart = fetch_one('SELECT id FROM carts WHERE user_id = ? LIMIT 1', 'i', [$userId]);
    if ($cart) return (int)$cart['id'];
    $stmt = db()->prepare('INSERT INTO carts (user_id) VALUES (?)');
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $id = (int)db()->insert_id;
    $stmt->close();
    return $id;
}

/* ------------------------------ Notifications ----------------------------- */

function add_notification(int $userId, string $type, string $title, string $message): void {
    $stmt = db()->prepare('INSERT INTO notifications (user_id, type, title, message) VALUES (?, ?, ?, ?)');
    $stmt->bind_param('isss', $userId, $type, $title, $message);
    $stmt->execute();
    $stmt->close();
}

function notifications_count(int $userId): int {
    $row = fetch_one('SELECT COUNT(*) AS c FROM notifications WHERE user_id = ? AND is_read = 0', 'i', [$userId]);
    return (int)($row['c'] ?? 0);
}

/* --------------------------------- Misc ----------------------------------- */

/** Correct details page for a cart/order product type. */
function details_url(string $productType): string {
    return $productType === 'skincare' ? u('beauty/beauty_details.php') : u('pharmacy/medicine_details.php');
}

/** Emojis used as product/facility icons (no binary assets needed). */
function icon(string $emoji, string $fallback = '📦'): string {
    $emoji = trim($emoji);
    return $emoji !== '' ? $emoji : $fallback;
}

function star_rating($rating): string {
    $rating = max(0, min(5, (float)$rating));
    $full = floor($rating); $half = ($rating - $full) >= 0.5;
    return str_repeat('⭐', (int)$full) . ($half ? '✩' : '');
}

/** Validate a South African phone-ish string (digits, spaces, +). */
function valid_phone(string $phone): bool {
    return (bool)preg_match('/^[0-9+ ()-]{7,20}$/', $phone);
}
