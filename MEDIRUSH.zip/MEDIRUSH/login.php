<?php
/**
 * MEDIRUSH — Login (public, guests only).
 * Automatically seeds the default Admin account if missing from the database.
 */
$ROOT = '.';
$PAGE_TITLE = 'Login';
$ACTIVE = '';
require_once $ROOT . '/includes/auth.php';
require_guest();

/* Ensure Demo Admin account always exists in DB for convenience */
try {
    $adminCheck = fetch_one('SELECT id FROM users WHERE email = ? LIMIT 1', 's', ['admin@medirush.local']);
    if (!$adminCheck) {
        $stmt = db()->prepare('INSERT INTO users (full_name, email, password_hash, phone, role) VALUES (?, ?, ?, ?, ?)');
        $name = 'MEDIRUSH Admin';
        $email_adm = 'admin@medirush.local';
        $hash = password_hash('password', PASSWORD_DEFAULT);
        $phone = '0115550001';
        $role = 'admin';
        $stmt->bind_param('sssss', $name, $email_adm, $hash, $phone, $role);
        $stmt->execute();
        $stmt->close();
    }
} catch (Throwable $e) {
    // Ignore if tables are not set up yet
}

/* Whitelisted return target from ?next=... */
$nextParam = (string)($_GET['next'] ?? '');
if (!preg_match('/^[a-zA-Z0-9_\/.-]+\.php$/', $nextParam) || str_contains($nextParam, '://')) {
    $nextParam = '';
}

$email = '';
$rememberedNext = $nextParam;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $email = trim((string)($_POST['email'] ?? ''));
    $password = (string)($_POST['password'] ?? '');

    $postedNext = (string)($_POST['posted_next'] ?? $_POST['next'] ?? '');
    if (!preg_match('/^[a-zA-Z0-9_\/.-]+\.php$/', $postedNext) || str_contains($postedNext, '://')) {
        $postedNext = '';
    }

    $user = null;
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $user = fetch_one('SELECT * FROM users WHERE email = ? LIMIT 1', 's', [$email]);
    }

    if ($user && password_verify($password, $user['password_hash'])) {
        login_current_user($user);
        flash('success', 'Welcome back, ' . $user['full_name'] . '!');
        
        // If an admin logs in, redirect them directly to admin.php by default
        if ($user['role'] === 'admin' && $postedNext === '') {
            redirect('admin.php');
        }
        redirect($postedNext !== '' ? $postedNext : 'dashboard.php');
    }

    flash('error', 'Invalid email or password.');
    $rememberedNext = $postedNext;
}

require_once $ROOT . '/includes/header.php';
?>
<div class="auth-wrap">
  <div class="auth-card">
    <div class="card">
      <h1 class="auth-title">Welcome back 👋</h1>
      <p class="auth-sub">Log in to reach your dashboard, records and orders.</p>

      <form action="<?= u('login.php') ?>" method="post" novalidate>
        <?= csrf_field() ?>
        <?php if ($rememberedNext !== ''): ?>
          <input type="hidden" name="next" value="<?= e($rememberedNext) ?>">
        <?php endif; ?>

        <div class="form-group">
          <label class="form-label" for="email">Email address</label>
          <input class="form-input" type="email" id="email" name="email" value="<?= e($email) ?>"
                 placeholder="you@example.com" required>
        </div>

        <div class="form-group">
          <label class="form-label" for="password">Password</label>
          <input class="form-input" type="password" id="password" name="password"
                 placeholder="Your password" required>
        </div>

        <button type="submit" class="btn btn-primary btn-block">Log in</button>
      </form>

      <p class="auth-foot">
        New to MEDIRUSH?
        <a href="<?= u('register.php') ?>"><strong>Create an account</strong></a>
      </p>

      <div class="demo-hint" style="margin-top: 15px; font-size: 0.85rem; line-height: 1.5;">
        <strong>🔑 Demo Accounts</strong><br>
        <strong>Admin Login:</strong> <code>admin@medirush.local</code> / <code>password</code><br>
        <strong>User Login:</strong> <code>demo@medirush.local</code> / <code>password</code>
      </div>
    </div>
  </div>
</div>
<?php require_once $ROOT . '/includes/footer.php'; ?>