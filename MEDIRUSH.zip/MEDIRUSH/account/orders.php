<?php
/**
 * MEDIRUSH — account/orders.php
 * Order history + single-order detail (owner-scoped).
 */
declare(strict_types=1);

$ROOT = '..';
$PAGE_TITLE = 'My Orders · MEDIRUSH';
$ACTIVE = 'account';
$SHOW_SIDEBAR = true;

require_once $ROOT . '/includes/auth.php';
require_login();

$uid = (int)$_SESSION['user_id'];

$statusClass = [
    'pending'    => 'badge-warning',
    'processing' => 'badge-info',
    'shipped'    => 'badge-info',
    'delivered'  => 'badge-success',
    'cancelled'  => 'badge-danger',
];
$paymentLabel = [
    'demo_card'         => '💳 Demo card',
    'demo_ewallet'      => '👛 Demo e-wallet',
    'cash_on_delivery'  => '💵 Cash on delivery',
];

/* All orders for this user, newest first, with an item count. */
$orders = fetch_all(
    'SELECT o.id, o.order_number, o.total, o.status, o.payment_method, o.created_at,
            COALESCE(cnt.items, 0) AS item_count
       FROM orders o
  LEFT JOIN (
            SELECT oi.order_id, COUNT(*) AS items
              FROM order_items oi
          GROUP BY oi.order_id
        ) cnt ON cnt.order_id = o.id
      WHERE o.user_id = ?
   ORDER BY o.created_at DESC',
    'i',
    [$uid]
);

/* Requested order detail — only if it belongs to this user. */
$detail = null;
$detailItems = [];
$requestedId = (int)($_GET['order'] ?? 0);
if ($requestedId > 0) {
    $detail = fetch_one(
        'SELECT id, order_number, total, status, payment_method, delivery_address, created_at
           FROM orders WHERE id = ? AND user_id = ? LIMIT 1',
        'ii',
        [$requestedId, $uid]
    );
    if ($detail) {
        $detailItems = fetch_all(
            'SELECT product_type, product_id, product_name, quantity, unit_price
               FROM order_items WHERE order_id = ?
           ORDER BY id ASC',
            'i',
            [(int)$detail['id']]
        );
    }
}

require_once $ROOT . '/includes/header.php';
?>
<div class="sidebar-wrap">
  <div class="sidebar-main">

    <div class="page-head">
      <h1 class="section-title">🧾 Order history</h1>
      <p class="section-subtitle">Everything you've ordered from the pharmacy and beauty store.</p>
    </div>

    <?php if (!$orders): ?>
      <div class="empty-state">
        <div class="empty-icon" style="font-size:3rem;">🧾</div>
        <h2 class="section-title" style="font-size:1.2rem;">No orders yet</h2>
        <p>When you check out, your order history will appear here.</p>
        <div style="display:flex; gap:.5rem; justify-content:center; flex-wrap:wrap;">
          <a class="btn btn-primary" href="<?= u('pharmacy/pharmacy.php') ?>">💊 Shop pharmacy</a>
          <a class="btn btn-outline" href="<?= u('beauty/beauty.php') ?>">🧴 Shop beauty</a>
        </div>
      </div>
    <?php else: ?>
      <div class="table-wrap">
        <table class="table">
          <thead>
            <tr>
              <th>Order</th>
              <th>Date</th>
              <th>Items</th>
              <th>Total</th>
              <th>Payment</th>
              <th>Status</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($orders as $o): ?>
              <tr>
                <td><code class="mono"><?= e($o['order_number']) ?></code></td>
                <td><?= e(date('j M Y', strtotime((string)$o['created_at']))) ?></td>
                <td><?= (int)$o['item_count'] ?></td>
                <td><strong><?= e(money($o['total'])) ?></strong></td>
                <td><span class="badge"><?= e($paymentLabel[$o['payment_method']] ?? (string)$o['payment_method']) ?></span></td>
                <td><span class="badge <?= e($statusClass[$o['status']] ?? '') ?>"><?= e(ucfirst((string)$o['status'])) ?></span></td>
                <td class="cell-actions">
                  <?php if ($requestedId === (int)$o['id']): ?>
                    <a class="btn btn-outline btn-sm" href="<?= u('account/orders.php') ?>">▲ Hide</a>
                  <?php else: ?>
                    <a class="btn btn-outline btn-sm" href="<?= u('account/orders.php?order=' . (int)$o['id']) ?>">Details</a>
                  <?php endif; ?>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>

    <?php if ($requestedId > 0 && !$detail): ?>
      <!-- Requested an order that is not this user's (or does not exist): 404-style, no existence leak -->
      <div class="empty-state">
        <div class="empty-icon" style="font-size:3rem;">🔒</div>
        <h2 class="section-title" style="font-size:1.2rem;">Order not found</h2>
        <p>We couldn't find that order. Back to the orders list → <a href="<?= u('account/orders.php') ?>">Orders</a></p>
      </div>
    <?php elseif ($detail): ?>
      <div class="card" style="margin-top:var(--gap,1rem);">
        <div class="card-body">
          <div class="list-row" style="align-items:center;">
            <h2 class="section-title" style="font-size:1.05rem; margin:0;">📦 Order <code class="mono"><?= e($detail['order_number']) ?></code></h2>
            <span class="badge <?= e($statusClass[$detail['status']] ?? '') ?>"><?= e(ucfirst((string)$detail['status'])) ?></span>
          </div>

          <!-- Status timeline (hidden for cancelled orders) -->
          <?php if ($detail['status'] !== 'cancelled'): ?>
            <?php
            $stages = ['pending', 'processing', 'shipped', 'delivered'];
            $currentIndex = array_search((string)$detail['status'], $stages, true);
            if ($currentIndex === false) { $currentIndex = 0; }
            ?>
            <div class="list-row" style="flex-wrap:wrap; gap:.4rem;">
              <?php foreach ($stages as $i => $stage): ?>
                <?php if ($i <= $currentIndex): ?>
                  <span class="badge <?= e($statusClass[$stage]) ?>"><?= e(ucfirst($stage)) ?><?= $i === $currentIndex ? ' ✓' : '' ?></span>
                <?php else: ?>
                  <span class="badge muted"><?= e(ucfirst($stage)) ?></span>
                <?php endif; ?>
              <?php endforeach; ?>
            </div>
          <?php else: ?>
            <p class="form-help">This order was cancelled — no further processing will happen.</p>
          <?php endif; ?>

          <!-- Items -->
          <div class="table-wrap">
            <table class="table">
              <thead>
                <tr><th>Item</th><th>Store</th><th>Qty</th><th>Unit price</th><th>Line total</th><th></th></tr>
              </thead>
              <tbody>
                <?php if (!$detailItems): ?>
                  <tr><td colspan="6" class="muted">No line items recorded for this order.</td></tr>
                <?php endif; ?>
                <?php foreach ($detailItems as $it): $line = (float)$it['unit_price'] * (int)$it['quantity']; ?>
                  <tr>
                    <td><strong><?= e($it['product_name']) ?></strong></td>
                    <td><span class="badge"><?= $it['product_type'] === 'skincare' ? '🧴 Beauty' : '💊 Pharmacy' ?></span></td>
                    <td><?= (int)$it['quantity'] ?></td>
                    <td><?= e(money($it['unit_price'])) ?></td>
                    <td><?= e(money($line)) ?></td>
                    <td class="cell-actions">
                      <a class="btn btn-outline btn-sm" href="<?= e(details_url((string)$it['product_type']) . '?id=' . (int)$it['product_id'] . '&type=' . e((string)$it['product_type'])) ?>">View</a>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>

          <div class="grid grid-2">
            <div>
              <h3 style="font-size:1rem;">🚚 Delivery</h3>
              <p class="muted"><?= e($detail['delivery_address'] !== '' ? $detail['delivery_address'] : 'No delivery address recorded.') ?></p>
            </div>
            <div>
              <h3 style="font-size:1rem;">ℹ️ Summary</h3>
              <div class="list-row"><span>Placed</span><span><?= e(date('j F Y, H:i', strtotime((string)$detail['created_at']))) ?></span></div>
              <div class="list-row"><span>Payment method</span><span class="badge"><?= e($paymentLabel[$detail['payment_method']] ?? (string)$detail['payment_method']) ?></span></div>
              <div class="list-row"><span>Total</span><strong><?= e(money($detail['total'])) ?></strong></div>
            </div>
          </div>

          <p class="form-help" style="margin-top:.75rem;">ℹ️ Payments in this demo never charge anything — all payment options are simulated.</p>
        </div>
      </div>
    <?php endif; ?>

  </div>
</div>
<?php require_once $ROOT . '/includes/footer.php'; ?>
