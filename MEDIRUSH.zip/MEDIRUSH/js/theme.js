/* ============================================================
   MEDIRUSH — js/theme.js
   Light / dark mode. Loaded in <head> to apply the saved theme
   BEFORE first paint (no flash of wrong theme).
   ============================================================ */
(function () {
  'use strict';
  var STORAGE_KEY = 'medirush-theme';
  var root = document.documentElement;

  function stored() {
    try { return localStorage.getItem(STORAGE_KEY); } catch (e) { return null; }
  }

  function apply(theme) {
    root.setAttribute('data-theme', theme);
    var toggle = document.getElementById('themeToggle');
    if (toggle) {
      toggle.textContent = theme === 'dark' ? '☀️' : '🌙';
      toggle.title = theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode';
    }
  }

  // Apply immediately (default: light, or the user's saved choice).
  var saved = stored();
  if (!saved) {
    try {
      saved = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    } catch (e) { saved = 'light'; }
  }
  apply(saved);

  // Wire the toggle once the DOM is ready.
  document.addEventListener('DOMContentLoaded', function () {
    var toggle = document.getElementById('themeToggle');
    if (toggle) {
      toggle.addEventListener('click', function () {
        var next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
        apply(next);
        try { localStorage.setItem(STORAGE_KEY, next); } catch (e) { /* private mode */ }
      });
    }
  });
})();
