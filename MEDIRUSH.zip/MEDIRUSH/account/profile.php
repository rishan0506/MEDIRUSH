<?php
/**
 * MEDIRUSH — account/profile.php
 * View + edit the logged-in user's profile.
 */
declare(strict_types=1);

$ROOT = '..';
$PAGE_TITLE = 'My Profile · MEDIRUSH';
$ACTIVE = 'account';
$SHOW_SIDEBAR = true;

require_once $ROOT . '/includes/auth.php';
require_login();

$uid = (int)$_SESSION['user_id'];

/* ------------------------------ POST: save_profile ------------------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_profile') {
    verify_csrf();

    $fullName = trim((string)($_POST['full_name'] ?? ''));
    $phone    = trim((string)($_POST['phone'] ?? ''));
    $address  = trim((string)($_POST['address'] ?? ''));
    $dob      = trim((string)($_POST['date_of_birth'] ?? ''));
    $gender   = (string)($_POST['gender'] ?? 'other');
    $blood    = (string)($_POST['blood_type'] ?? '');
    $allerg   = trim((string)($_POST['allergies'] ?? ''));
    $chronic  = trim((string)($_POST['chronic_conditions'] ?? ''));
    $emName   = trim((string)($_POST['emergency_contact_name'] ?? ''));
    $emPhone  = trim((string)($_POST['emergency_contact_phone'] ?? ''));

    $errors = [];

    if (mb_strlen($fullName) < 3 || mb_strlen($fullName) > 80) {
        $errors[] = 'Full name must be between 3 and 80 characters.';
    }
    if ($phone !== '' && !valid_phone($phone)) {
        $errors[] = 'Phone number looks invalid (7–20 digits, spaces, + or -).';
    }
    if (mb_strlen($address) > 255) {
        $errors[] = 'Address must be 255 characters or fewer.';
    }
    if ($dob !== '') {
        $dobTime = strtotime($dob);
        if ($dobTime === false || date('Y-m-d', $dobTime) !== $dob) {
            $errors[] = 'Date of birth must be a valid date.';
        } else {
            $age = (int)floor((time() - $dobTime) / 31557600); // ~365.25 days/year
            if ($dobTime > time()) {
                $errors[] = 'Date of birth cannot be in the future.';
            } elseif ($age < 5 || $age > 120) {
                $errors[] = 'Your age must be between 5 and 120 years.';
            }
        }
    }
    if (!in_array($gender, ['male', 'female', 'other'], true)) {
        $gender = 'other';
    }
    if (!in_array($blood, ['', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'], true)) {
        $blood = '';
    }
    if (mb_strlen($allerg) > 1000 || mb_strlen($chronic) > 1000) {
        $errors[] = 'Allergy and condition notes must be 1000 characters or fewer.';
    }
    if (mb_strlen($emName) > 80) {
        $errors[] = 'Emergency contact name must be 80 characters or fewer.';
    }
    if ($emPhone !== '' && !valid_phone($emPhone)) {
        $errors[] = 'Emergency contact phone looks invalid.';
    }

    if ($errors) {
        flash('error', implode(' ', $errors));
        // Keep submitted values in the form below.
        $form = [
            'full_name' => $fullName,
            'email'     => (string)($_SESSION['full_name'] ?? ''),
            'phone'     => $phone,
            'address'   => $address,
            'date_of_birth' => $dob,
            'gender'    => $gender,
            'blood_type' => $blood,
            'allergies' => $allerg,
            'chronic_conditions' => $chronic,
            'emergency_contact_name' => $emName,
            'emergency_contact_phone' => $emPhone,
            'created_at' => null,
        ];
        $form['email'] = '';
        $row = fetch_one('SELECT email, created_at FROM users WHERE id = ? LIMIT 1', 'i', [$uid]);
        if ($row) {
            $form['email'] = $row['email'];
            $form['created_at'] = $row['created_at'];
        }
    } else {
        try {
            $stmt = db()->prepare('UPDATE users SET full_name = ?, phone = ? WHERE id = ?');
            $stmt->bind_param('ssi', $fullName, $phone, $uid);
            $stmt->execute();
            $stmt->close();

            $_SESSION['full_name'] = $fullName;

            $photoRow = fetch_one('SELECT id FROM user_profiles WHERE user_id = ? LIMIT 1', 'i', [$uid]);
            if ($photoRow) {
                $stmt = db()->prepare(
                    'UPDATE user_profiles
                       SET address = ?, date_of_birth = ?, gender = ?, blood_type = ?,
                           allergies = ?, chronic_conditions = ?,
                           emergency_contact_name = ?, emergency_contact_phone = ?
                     WHERE user_id = ?'
                );
                $types = 'ssssssssi';
                $stmt->bind_param($types, $address, $dob, $gender, $blood, $allerg, $chronic, $emName, $emPhone, $uid);
            } else {
                $stmt = db()->prepare(
                    'INSERT INTO user_profiles
                        (user_id, address, date_of_birth, gender, blood_type,
                         allergies, chronic_conditions, emergency_contact_name, emergency_contact_phone)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
                );
                $types = 'issssssss';
                $stmt->bind_param($types, $uid, $address, $dob, $gender, $blood, $allerg, $chronic, $emName, $emPhone);
            }
            $stmt->execute();
            $stmt->close();

            add_notification($uid, 'profile', 'Profile updated', 'Your profile details were saved successfully.');
            flash('success', 'Profile saved successfully.');
            redirect('account/profile.php');
        } catch (Throwable $ex) {
            error_log('profile save failed: ' . $ex->getMessage());
            flash('error', 'We could not save your profile right now — please try again.');
        }
    }
}

$prefillFailed = isset($form);
if (!$prefillFailed) {
    $row = fetch_one(
        'SELECT u.full_name, u.email, u.phone, u.created_at,
                p.address, p.date_of_birth, p.gender, p.blood_type,
                p.allergies, p.chronic_conditions,
                p.emergency_contact_name, p.emergency_contact_phone
           FROM users u
      LEFT JOIN user_profiles p ON p.user_id = u.id
          WHERE u.id = ? LIMIT 1',
        'i',
        [$uid]
    );
    if (!$row) { // stale session fallback
        logout_current_user();
        require_login();
    }
    $form = [
        'full_name' => (string)($row['full_name'] ?? ''),
        'email'     => (string)($row['email'] ?? ''),
        'phone'     => (string)($row['phone'] ?? ''),
        'address'   => (string)($row['address'] ?? ''),
        'date_of_birth' => (string)($row['date_of_birth'] ?? ''),
        'gender'    => (string)($row['gender'] ?? 'other'),
        'blood_type' => (string)($row['blood_type'] ?? ''),
        'allergies' => (string)($row['allergies'] ?? ''),
        'chronic_conditions' => (string)($row['chronic_conditions'] ?? ''),
        'emergency_contact_name' => (string)($row['emergency_contact_name'] ?? ''),
        'emergency_contact_phone' => (string)($row['emergency_contact_phone'] ?? ''),
        'created_at' => (string)($row['created_at'] ?? ''),
    ];
}

$memberSince = $form['created_at'] !== '' ? date('j F Y', strtotime($form['created_at'])) : '—';
$initial = strtoupper(mb_substr($form['full_name'] !== '' ? $form['full_name'] : 'U', 0, 1));

require_once $ROOT . '/includes/header.php';
?>
<div class="sidebar-wrap">
  <div class="sidebar-main">

    <div class="page-head">
      <h1 class="section-title">👤 My Profile</h1>
      <p class="section-subtitle">Keep your details up to date — some of this information helps during consultations and deliveries.</p>
    </div>

    <div class="grid grid-2">

      <!-- Profile photo card -->
      <div class="card">
        <div class="card-body">
          <h2 class="section-title" style="font-size:1.05rem;">Profile photo</h2>
          <div class="list-row" style="align-items:center;">
            <span class="avatar avatar-lg"><?= e($initial) ?></span>
            <div>
              <strong>Your initials, as a placeholder</strong>
              <div class="form-help">📤 Photo upload is disabled in this demo build — your initial letter is shown instead.</div>
            </div>
          </div>
          <p class="form-help">Member since <?= e($memberSince) ?></p>
        </div>
      </div>

      <!-- Read-only account fields -->
      <div class="card">
        <div class="card-body">
          <h2 class="section-title" style="font-size:1.05rem;">Account details</h2>
          <div class="list-row"><strong>Name</strong><span><?= e($form['full_name'] !== '' ? $form['full_name'] : '—') ?></span></div>
          <div class="list-row"><strong>Email</strong><span class="muted"><?= e($form['email'] !== '' ? $form['email'] : '—') ?></span></div>
          <div class="form-help">ℹ️ Email is read-only — contact support to change your email address.</div>
        </div>
      </div>
    </div>

    <!-- Edit form -->
    <div class="card" style="margin-top:var(--gap,1rem);">
      <div class="card-body">
        <h2 class="section-title" style="font-size:1.05rem;">Edit details</h2>
        <form method="post" action="<?= u('account/profile.php') ?>">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="save_profile">

          <div class="grid grid-2">
            <div class="form-group">
              <label class="form-label" for="full_name">Full name</label>
              <input class="form-input" type="text" id="full_name" name="full_name" maxlength="80" required
                     value="<?= e($form['full_name']) ?>">
              <div class="form-help">3–80 characters.</div>
            </div>
            <div class="form-group">
              <label class="form-label" for="phone">Phone number</label>
              <input class="form-input" type="text" id="phone" name="phone" maxlength="20" inputmode="tel"
                     placeholder="e.g. +27 82 123 4567" value="<?= e($form['phone']) ?>">
              <div class="form-help">Optional, but handy for delivery updates.</div>
            </div>
            <div class="form-group">
              <label class="form-label" for="date_of_birth">Date of birth</label>
              <input class="form-input" type="date" id="date_of_birth" name="date_of_birth"
                     value="<?= e($form['date_of_birth']) ?>">
              <div class="form-help">Optional — must be a past date (age 5–120).</div>
            </div>
            <div class="form-group">
              <label class="form-label" for="gender">Gender</label>
              <select class="form-select" id="gender" name="gender">
                <?php foreach (['male' => 'Male', 'female' => 'Female', 'other' => 'Other / prefer not to say'] as $gk => $gLabel): ?>
                  <option value="<?= e($gk) ?>"<?= $form['gender'] === $gk ? ' selected' : '' ?>><?= e($gLabel) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label" for="blood_type">Blood type</label>
              <select class="form-select" id="blood_type" name="blood_type">
                <?php
                $bloodOptions = ['' => 'Unknown', 'A+' => 'A+', 'A-' => 'A-', 'B+' => 'B+', 'B-' => 'B-',
                                 'AB+' => 'AB+', 'AB-' => 'AB-', 'O+' => 'O+', 'O-' => 'O-'];
                foreach ($bloodOptions as $bk => $bLabel): ?>
                  <option value="<?= e($bk) ?>"<?= $form['blood_type'] === $bk ? ' selected' : '' ?>><?= e($bLabel) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label" for="address">Delivery address</label>
              <input class="form-input" type="text" id="address" name="address" maxlength="255"
                     placeholder="Street, suburb, city" value="<?= e($form['address']) ?>">
              <div class="form-help">Used as the default delivery address (max 255 chars).</div>
            </div>
            <div class="form-group">
              <label class="form-label" for="allergies">Allergies</label>
              <textarea class="form-textarea" id="allergies" name="allergies" rows="3"
                        placeholder="e.g. Penicillin, peanuts"><?= e($form['allergies']) ?></textarea>
            </div>
            <div class="form-group">
              <label class="form-label" for="chronic_conditions">Chronic conditions</label>
              <textarea class="form-textarea" id="chronic_conditions" name="chronic_conditions" rows="3"
                        placeholder="e.g. Asthma, hypertension"><?= e($form['chronic_conditions']) ?></textarea>
            </div>
            <div class="form-group">
              <label class="form-label" for="emergency_contact_name">Emergency contact name</label>
              <input class="form-input" type="text" id="emergency_contact_name" name="emergency_contact_name" maxlength="80"
                     value="<?= e($form['emergency_contact_name']) ?>">
            </div>
            <div class="form-group">
              <label class="form-label" for="emergency_contact_phone">Emergency contact phone</label>
              <input class="form-input" type="text" id="emergency_contact_phone" name="emergency_contact_phone" maxlength="20"
                     inputmode="tel" value="<?= e($form['emergency_contact_phone']) ?>">
            </div>
          </div>

          <button type="submit" class="btn btn-primary">💾 Save profile</button>
        </form>
      </div>
    </div>

  </div>
</div>
<?php require_once $ROOT . '/includes/footer.php'; ?>
