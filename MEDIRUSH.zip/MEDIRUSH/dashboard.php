<?php
/**
 * MEDIRUSH — User dashboard (login required, sidebar layout).
 */
$ROOT = '.';
$PAGE_TITLE = 'My dashboard';
$ACTIVE = 'dashboard';
$SHOW_SIDEBAR = true;
require_once $ROOT . '/includes/auth.php';
require_login();
$_SESSION['active_tab'] = 'dashboard';

$me = current_user();
$meId = (int)$me['id'];

/* POST: mark all notifications as read */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'mark_all_read') {
    verify_csrf();
    $stmt = db()->prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0');
    $stmt->bind_param('i', $meId);
    $stmt->execute();
    $stmt->close();
    flash('success', 'All notifications marked as read.');
    redirect('dashboard.php');
}

$today = date('Y-m-d');

/* ---- Stat cards ---- */
$appointmentsUpcoming = fetch_one(
    "SELECT COUNT(*) AS c FROM appointments
     WHERE user_id = ? AND appointment_date >= ? AND status = 'scheduled'",
    'is', [$meId, $today]
);
$medicationsActive = fetch_one(
    'SELECT COUNT(*) AS c FROM medications WHERE user_id = ? AND is_active = 1',
    'i', [$meId]
);
$prescriptionsPending = fetch_one(
    "SELECT COUNT(*) AS c FROM prescriptions WHERE user_id = ? AND status = 'pending'",
    'i', [$meId]
);
$notificationsUnread = notifications_count($meId);

/* ---- Upcoming appointments ---- */
$upcomingAppointments = fetch_all(
    "SELECT a.id, a.appointment_date, a.appointment_time, a.mode, a.status,
            d.name AS doctor_name, d.specialization, d.image
     FROM appointments a JOIN doctors d ON d.id = a.doctor_id
     WHERE a.user_id = ? AND a.appointment_date >= ? AND a.status = 'scheduled'
     ORDER BY a.appointment_date ASC, a.appointment_time ASC LIMIT 6",
    'is', [$meId, $today]
);

/* ---- Recent prescriptions ---- */
$recentPrescriptions = fetch_all(
    'SELECT id, doctor_name, status, file_path, original_filename, uploaded_at, admin_note
     FROM prescriptions WHERE user_id = ? ORDER BY uploaded_at DESC, id DESC LIMIT 5',
    'i', [$meId]
);

/* ---- Latest 5 notifications ---- */
$latestNotifications = fetch_all(
    'SELECT id, type, title, message, is_read, created_at
     FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 5',
    'i', [$meId]
);

$modeBadge = ['in_person' => ['badge-info', '🏥 In person'], 'video' => ['badge-success', '🎥 Video'], 'phone' => ['badge-warning', '📞 Phone']];
$rxBadge   = ['pending' => 'badge-warning', 'approved' => 'badge-success', 'rejected' => 'badge-danger'];

require_once $ROOT . '/includes/header.php';
?>
<div class="sidebar-wrap">
  <div class="sidebar-main">
    <div class="container">

      <h1 class="section-title">Hello, <?= e($me['full_name']) ?> 👋</h1>
      <p class="section-subtitle">Here is what is happening in your MEDIRUSH account today.</p>

      <section class="section" id="stats">
        <div class="grid grid-4">
          <div class="card stat-card">
            <div class="stat-icon" aria-hidden="true">📅</div>
            <div><div class="stat-value"><?= (int)$appointmentsUpcoming['c'] ?></div><div class="stat-label">Upcoming appointments</div></div>
          </div>
          <div class="card stat-card">
            <div class="stat-icon" aria-hidden="true">💊</div>
            <div><div class="stat-value"><?= (int)$medicationsActive['c'] ?></div><div class="stat-label">Active medications</div></div>
          </div>
          <div class="card stat-card">
            <div class="stat-icon" aria-hidden="true">📝</div>
            <div><div class="stat-value"><?= (int)$prescriptionsPending['c'] ?></div><div class="stat-label">Pending prescriptions</div></div>
          </div>
          <div class="card stat-card">
            <div class="stat-icon" aria-hidden="true">🔔</div>
            <div><div class="stat-value"><?= (int)$notificationsUnread ?></div><div class="stat-label">Unread notifications</div></div>
          </div>
        </div>
      </section>

      <section class="section" id="appointments">
        <h2 class="section-title">Upcoming appointments</h2>
        <p class="section-subtitle">Your next confirmed visits and calls with our doctors.</p>
        <?php if ($upcomingAppointments): ?>
          <div class="table-wrap card">
            <table class="table">
              <thead>
                <tr><th>When</th><th>Doctor</th><th>Specialization</th><th>Mode</th></tr>
              </thead>
              <tbody>
                <?php foreach ($upcomingAppointments as $a): ?>
                  <tr>
                    <td>
                      <strong><?= e(date('D, d M Y', strtotime($a['appointment_date']))) ?></strong><br>
                      <span class="muted"><?= e(date('H:i', strtotime($a['appointment_time']))) ?></span>
                    </td>
                    <td><?= e(icon($a['image'], '🩺')) ?> <?= e($a['doctor_name']) ?></td>
                    <td><?= e($a['specialization']) ?></td>
                    <td><span class="badge <?= e($modeBadge[$a['mode']][0]) ?>"><?= e($modeBadge[$a['mode']][1]) ?></span></td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php else: ?>
          <div class="card empty-state">
            <div class="empty-icon" aria-hidden="true">📅</div>
            <h3>No upcoming appointments</h3>
            <p>When you book one, it will show up here.</p>
            <a class="btn btn-primary" href="<?= u('healthcare/doctor_consultation.php') ?>">Book a doctor</a>
          </div>
        <?php endif; ?>
      </section>

      <section class="section" id="prescriptions">
        <h2 class="section-title">Recent prescriptions</h2>
        <p class="section-subtitle">Verification status of what you uploaded. Upload more under <a href="<?= u('my_health/upload.php') ?>">My Health → Uploads</a>.</p>
        <?php if ($recentPrescriptions): ?>
          <div class="table-wrap card">
            <table class="table">
              <thead>
                <tr><th>Doctor</th><th>File</th><th>Status</th><th>Uploaded</th><th></th></tr>
              </thead>
              <tbody>
                <?php foreach ($recentPrescriptions as $r): ?>
                  <tr>
                    <td><strong><?= e($r['doctor_name']) ?></strong></td>
                    <td><?= e($r['original_filename']) ?></td>
                    <td><span class="badge <?= e($rxBadge[$r['status']] ?? '') ?>"><?= e(ucfirst($r['status'])) ?></span>
                      <?php if ($r['status'] !== 'approved' && trim((string)$r['admin_note']) !== ''): ?>
                        <br><span class="muted">Note: <?= e($r['admin_note']) ?></span>
                      <?php endif; ?>
                    </td>
                    <td><?= e(date('d M Y', strtotime($r['uploaded_at']))) ?></td>
                    <td>
                      <a class="btn btn-outline btn-sm" href="<?= u('my_health/upload.php') ?>">Manage</a>
                      <?php if ($r['file_path'] !== ''): ?>
                        <a class="btn btn-outline btn-sm" href="<?= u('download.php') ?>?file=<?= e(rawurlencode(basename($r['file_path']))) ?>">Download</a>
                      <?php endif; ?>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php else: ?>
          <div class="card empty-state">
            <div class="empty-icon" aria-hidden="true">📝</div>
            <h3>No prescriptions yet</h3>
            <p>Upload a prescription and our team will verify it.</p>
            <a class="btn btn-primary" href="<?= u('my_health/upload.php') ?>">Upload a prescription</a>
          </div>
        <?php endif; ?>
      </section>

      <section class="section" id="quick-actions">
        <h2 class="section-title">Quick actions</h2>
        <p class="section-subtitle">Jump straight to what you need most often.</p>
        <div class="grid grid-4">
          <a class="card feature-card" href="<?= u('my_health/upload.php') ?>">
            <div class="feature-icon" aria-hidden="true">📤</div><h3>Upload documents</h3>
            <p>Add records or prescriptions securely.</p>
          </a>
          <a class="card feature-card" href="<?= u('healthcare/doctor_consultation.php') ?>">
            <div class="feature-icon" aria-hidden="true">🩺</div><h3>Book doctor</h3>
            <p>In-person, video or phone visits.</p>
          </a>
          <a class="card feature-card" href="<?= u('pharmacy/pharmacy.php') ?>">
            <div class="feature-icon" aria-hidden="true">💊</div><h3>Order medicine</h3>
            <p>Shop the online pharmacy.</p>
          </a>
          <a class="card feature-card" href="<?= u('beauty/skincare_assistant.php') ?>">
            <div class="feature-icon" aria-hidden="true">✨</div><h3>Skincare assistant</h3>
            <p>Get routine suggestions for your skin.</p>
          </a>
          <a class="card feature-card" href="<?= u('account/profile.php') ?>">
            <div class="feature-icon" aria-hidden="true">👤</div><h3>Profile</h3>
            <p>Update your details and contacts.</p>
          </a>
        </div>
      </section>

      <section class="section" id="notifications">
        <div class="product-meta">
          <div>
            <h2 class="section-title">Notifications</h2>
            <p class="section-subtitle">Latest 5 — the bell badge updates as you read them.</p>
          </div>
          <form action="<?= u('dashboard.php') ?>" method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="mark_all_read">
            <button type="submit" class="btn btn-outline btn-sm" <?= $notificationsUnread === 0 ? 'disabled' : '' ?>>✓ Mark all as read</button>
          </form>
        </div>
        <?php if ($latestNotifications): ?>
          <div class="card">
            <?php foreach ($latestNotifications as $n): ?>
              <div class="list-row">
                <div>
                  <strong><?= e($n['title']) ?></strong>
                  <?php if (!$n['is_read']): ?><span class="badge badge-info">New</span><?php endif; ?><br>
                  <span class="muted"><?= e($n['message']) ?></span>
                </div>
                <span class="badge"><?= e(date('d M H:i', strtotime($n['created_at']))) ?></span>
              </div>
            <?php endforeach; ?>
          </div>
        <?php else: ?>
          <div class="card empty-state">
            <div class="empty-icon" aria-hidden="true">🔕</div>
            <h3>Nothing here yet</h3>
            <p>Order updates and prescription results will pop up in this list.</p>
          </div>
        <?php endif; ?>
      </section>

    </div>
  </div>
</div>
<?php require_once $ROOT . '/includes/footer.php'; ?>
