<?php
/**
 * MEDIRUSH — account/settings.php
 * Change password, country/language (double confirmation), theme,
 * notifications & privacy info.
 */
declare(strict_types=1);

$ROOT = '..';
$PAGE_TITLE = 'Account Settings · MEDIRUSH';
$ACTIVE = 'account';
$SHOW_SIDEBAR = true;

require_once $ROOT . '/includes/auth.php';
require_login();

$uid = (int)$_SESSION['user_id'];
$profile = fetch_one('SELECT country FROM user_profiles WHERE user_id = ? LIMIT 1', 'i', [$uid]);
$currentCountry = (string)($profile['country'] ?? '');

/* ---------------------------- POST: change_password ------------------------ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'change_password') {
    verify_csrf();

    $current = (string)($_POST['current_password'] ?? '');
    $new     = (string)($_POST['new_password'] ?? '');
    $confirm = (string)($_POST['confirm_password'] ?? '');

    // Fetch only this user's row, by session id.
    $userRow = fetch_one('SELECT id, password_hash FROM users WHERE id = ? LIMIT 1', 'i', [$uid]);

    if (!$userRow || !password_verify($current, (string)$userRow['password_hash'])) {
        flash('error', 'Your current password is incorrect. Please try again.');
    } elseif (mb_strlen($new) < 8) {
        flash('error', 'New password must be at least 8 characters long.');
    } elseif ($new !== $confirm) {
        flash('error', 'New password and confirmation do not match.');
    } else {
        try {
            $hash = password_hash($new, PASSWORD_DEFAULT);
            $stmt = db()->prepare('UPDATE users SET password_hash = ? WHERE id = ?');
            $stmt->bind_param('si', $hash, $uid);
            $stmt->execute();
            $stmt->close();
            add_notification($uid, 'security', 'Password changed', 'Your MEDIRUSH account password was changed successfully.');
            flash('success', 'Password changed successfully. Use your new password next time you log in.');
        } catch (Throwable $ex) {
            error_log('change_password failed: ' . $ex->getMessage());
            flash('error', 'We could not change your password right now — please try again.');
        }
    }
    redirect('account/settings.php');
}

/* ---------------------------- POST: change_country ------------------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'change_country') {
    verify_csrf();

    $country = trim((string)($_POST['country'] ?? ''));
    if ($country !== '' && !in_array($country, medirush_countries(), true)) {
        $country = ''; // whitelist: only the 5 ASEAN countries or empty
    }

    try {
        $stmt = db()->prepare('UPDATE user_profiles SET country = ? WHERE user_id = ?');
        $stmt->bind_param('si', $country, $uid);
        $stmt->execute();
        $stmt->close();

        $currentCountry = $country;
        $_SESSION['country'] = $country; // language + pharmacy location update instantly

        $label = $country !== '' ? $country : 'None (English)';
        add_notification($uid, 'account', 'Country changed',
            'Your delivery country is now set to ' . $label . '. The site language follows your country.');
        flash('success', $country !== ''
            ? 'Country updated to ' . $country . ' 🌍 — the site language follows automatically.'
            : 'Country removed — the site now uses English.');
    } catch (Throwable $ex) {
        error_log('change_country failed: ' . $ex->getMessage());
        flash('error', 'We could not change your country right now — please try again.');
    }
    redirect('account/settings.php');
}

$lastLogin = isset($_SESSION['login_time']) && $_SESSION['login_time']
    ? date('l, j F Y \a\t H:i', (int)$_SESSION['login_time'])
    : null;

require_once $ROOT . '/includes/header.php';
?>
<div class="sidebar-wrap">
  <div class="sidebar-main">

    <div class="page-head">
      <h1 class="section-title">⚙️ Account Settings</h1>
      <p class="section-subtitle">Security, appearance and account preferences.</p>
    </div>

    <!-- Section A: Country & language -->
    <div class="card">
      <div class="card-body">
        <h2 class="section-title" style="font-size:1.05rem;">🌍 Country &amp; language</h2>
        <p>Your registered country is used as the pharmacy delivery location and selects the site language
          automatically: <strong>Philippines → Filipino</strong>, <strong>Thailand → ไทย</strong>,
          <strong>Indonesia → Indonesia</strong>, <strong>Malaysia → Bahasa Melayu</strong>,
          <strong>Vietnam → Tiếng Việt</strong>. No country set → English.</p>

        <form method="post" action="<?= u('account/settings.php') ?>" id="countryForm">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="change_country">

          <div class="form-group" style="max-width:340px;">
            <label class="form-label" for="country">Delivery country / language</label>
            <select class="form-select" id="country" name="country">
              <option value="">— No country (English) —</option>
              <?php foreach (medirush_countries() as $c): ?>
                <?php $flag = medirush_flags()[$c] ?? ''; ?>
                <option value="<?= e($c) ?>"<?= $currentCountry === $c ? ' selected' : '' ?>><?= e(trim($flag . ' ' . $c)) ?></option>
              <?php endforeach; ?>
            </select>
            <small class="form-help">Current: <strong><?= $currentCountry !== '' ? e(trim((medirush_flags()[$currentCountry] ?? '') . ' ' . $currentCountry)) : 'not set' ?></strong> · Language: <strong><?= e(medirush_lang()) ?></strong></small>
          </div>

          <button type="submit" class="btn btn-primary">🌍 Update country</button>
        </form>

        <script>
        // Double confirmation, as required — two separate browser dialogs.
        document.getElementById('countryForm').addEventListener('submit', function (e) {
          var value = this.querySelector('#country').value;
          if (value) {
            if (!confirm('Change your country to "' + value + '"?\n\nThis also changes the site language and your pharmacy delivery location.')) {
              e.preventDefault(); return false;
            }
            if (!confirm('Double check ✅ — save "' + value + '" as your country?')) {
              e.preventDefault(); return false;
            }
          } else {
            if (!confirm('Remove your country? The site will switch to English and no delivery location is shown.')) {
              e.preventDefault(); return false;
            }
          }
        });
        </script>
      </div>
    </div>

    <!-- Section B: Change password -->
    <div class="card" style="margin-top:var(--gap,1rem);">
      <div class="card-body">
        <h2 class="section-title" style="font-size:1.05rem;">🔒 Change password</h2>
        <div class="alert alert-info" style="margin-bottom:.75rem;">💡 Demo note: passwords must be at least 8 characters. This is a demo environment — please don't reuse a password you use on any real website.</div>
        <form method="post" action="<?= u('account/settings.php') ?>">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="change_password">
          <div class="grid grid-3">
            <div class="form-group">
              <label class="form-label" for="current_password">Current password</label>
              <input class="form-input" type="password" id="current_password" name="current_password" required autocomplete="current-password">
            </div>
            <div class="form-group">
              <label class="form-label" for="new_password">New password</label>
              <input class="form-input" type="password" id="new_password" name="new_password" required minlength="8" autocomplete="new-password">
              <div class="form-help">Minimum 8 characters.</div>
            </div>
            <div class="form-group">
              <label class="form-label" for="confirm_password">Confirm new password</label>
              <input class="form-input" type="password" id="confirm_password" name="confirm_password" required minlength="8" autocomplete="new-password">
            </div>
          </div>
          <button type="submit" class="btn btn-primary">🔑 Update password</button>
        </form>
      </div>
    </div>

    <!-- Section C: Preferences (theme) -->
    <div class="card" style="margin-top:var(--gap,1rem);">
      <div class="card-body">
        <h2 class="section-title" style="font-size:1.05rem;">🎨 Preferences — Light / Dark theme</h2>
        <p>The ☀️/🌙 button in the top navigation switches between light and dark mode. Your choice is <strong>remembered in this browser</strong> (saved by <code>js/theme.js</code> in your browser's local storage) — no account setting is stored on the server, so each device can have its own theme.</p>
        <button type="button" class="btn btn-outline" id="prefsThemeBtn" title="Toggle light/dark mode">🌓 Try it now: toggle theme</button>
        <p class="form-help">Hint: the current mode is applied before the first paint, so you'll never see a flash of the wrong theme.</p>
        <script>
        // Same init-time logic as js/theme.js — mirrors the header toggle.
        document.getElementById('prefsThemeBtn').addEventListener('click', function () {
          var root = document.documentElement;
          var next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
          root.setAttribute('data-theme', next);
          var toggle = document.getElementById('themeToggle');
          if (toggle) {
            toggle.textContent = next === 'dark' ? '☀️' : '🌙';
            toggle.title = next === 'dark' ? 'Switch to light mode' : 'Switch to dark mode';
          }
          try { localStorage.setItem('medirush-theme', next); } catch (err) { /* private mode */ }
        });
        </script>
      </div>
    </div>

    <!-- Section D: Notifications -->
    <div class="card" style="margin-top:var(--gap,1rem);">
      <div class="card-body">
        <h2 class="section-title" style="font-size:1.05rem;">🔔 Notifications</h2>
        <p>You receive in-app notifications for order updates, appointment changes and account activity. The 🔔 bell in the navigation shows the number of unread notifications — click it to open your dashboard notification feed.</p>
        <p class="form-help">Read-only: open your <a href="<?= u('dashboard.php') ?>">dashboard</a> to review notifications and <strong>mark them all as read</strong>.</p>
      </div>
    </div>

    <!-- Section E: Privacy & data -->
    <div class="card" style="margin-top:var(--gap,1rem);">
      <div class="card-body">
        <h2 class="section-title" style="font-size:1.05rem;">🛡️ Privacy &amp; data</h2>
        <ul>
          <li>Documents and prescriptions you upload are stored <strong>outside the public site</strong> — <code>assets/uploads/</code> denies direct web access.</li>
          <li>Files are served only through <code>download.php</code>, which checks the record <strong>belongs to your logged-in account</strong> before sending anything.</li>
          <li>Stored file names are randomized (never your original filename); the original name is kept in the database and shown only to you.</li>
          <li>Only <code>PDF, JPG, JPEG, PNG, WEBP</code> files up to 5&nbsp;MB are accepted, and file type is verified by content — not just by extension.</li>
          <li>Every query on your data is scoped to your user id — one account can never read another account's records or orders.</li>
        </ul>
        <p class="form-help">Full technical notes: <a href="<?= e('../PROJECT_SPEC.md') ?>" target="_blank" rel="noopener">PROJECT_SPEC.md</a> (§5 Security rules, §6 External APIs) · Related page: <a href="<?= u('my_health/upload.php') ?>">📤 My uploads</a></p>
      </div>
    </div>

    <!-- Session info -->
    <div class="card" style="margin-top:var(--gap,1rem);">
      <div class="card-body">
        <h2 class="section-title" style="font-size:1.05rem;">🖥️ Session</h2>
        <p class="form-help"><?= $lastLogin !== null ? 'You logged in on: <span>' . e($lastLogin) . '</span>' : 'Session started before login information was recorded.' ?></p>
      </div>
    </div>

  </div>
</div>
<?php require_once $ROOT . '/includes/footer.php'; ?>