<?php
/**
 * MEDIRUSH — Doctor directory + booking.
 * Public page: guests may browse doctors, but POSTing a booking requires login.
 * auth.php is loaded FIRST so the session/POST handling runs before header output.
 */
$ROOT = '..';
$PAGE_TITLE = 'Doctor Consultation — MEDIRUSH';
$ACTIVE = 'healthcare';
require_once $ROOT . '/includes/auth.php';

$SELF = 'healthcare/doctor_consultation.php';

/* --------------------------- Booking POST handler --------------------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();                                  // 1) security check first
    require_login($SELF);                           // 2) must be logged in (flash + login.php?next=...)

    $user   = current_user();
    $userId = (int)$user['id'];

    $doctorId = (int)($_POST['doctor_id'] ?? 0);
    $date     = trim($_POST['appointment_date'] ?? '');
    $timeRaw  = trim($_POST['appointment_time'] ?? '');
    $mode     = trim($_POST['mode'] ?? 'in_person');
    $notes    = trim($_POST['notes'] ?? '');

    $errors = [];

    /* Doctor must exist. */
    $doctor = fetch_one('SELECT id, name, available_from, available_to, available_days, video_enabled FROM doctors WHERE id = ?', 'i', [$doctorId]);
    if ($doctorId <= 0) {
        $errors[] = 'Please choose a doctor to book with.';
    } elseif (!$doctor) {
        $errors[] = 'That doctor could not be found — please try again.';
    }

    /* Date: must be valid and today or later. */
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) || strtotime($date) === false) {
        $errors[] = 'Please pick a valid appointment date.';
    } elseif ($date < date('Y-m-d')) {
        $errors[] = 'The appointment date cannot be in the past.';
    }

    /* Time: HH:MM (or HH:MM:SS), normalised for storage. */
    $time = $timeRaw;
    if (preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $time)) {
        $time = $time . ':00';
    } elseif (preg_match('/^([01]\d|2[0-3]):[0-5]\d:00$/', $time)) {
        // already in DB format
    } else {
        $errors[] = 'Please pick a valid appointment time.';
    }
    $timeShort = substr($time, 0, 5);

    /* Must fall inside the doctor's published window and available days. */
    if ($doctor && !$errors) {
        $from = substr((string)$doctor['available_from'], 0, 5);
        $to   = substr((string)$doctor['available_to'], 0, 5);
        if ($timeShort === '' || $timeShort < $from || $timeShort > $to) {
            $errors[] = "Please choose a time between {$from} and {$to} for {$doctor['name']}.";
        } elseif (trim((string)$doctor['available_days']) !== '') {
            $dayAbbr = [
                'mon' => 'mon', 'monday' => 'mon', 'tue' => 'tue', 'tues' => 'tue', 'tuesday' => 'tue',
                'wed' => 'wed', 'wednesday' => 'wed', 'thu' => 'thu', 'thur' => 'thu', 'thurs' => 'thu', 'thursday' => 'thu',
                'fri' => 'fri', 'friday' => 'fri', 'sat' => 'sat', 'saturday' => 'sat', 'sun' => 'sun', 'sunday' => 'sun',
            ];
            $tokens = array_values(array_filter(array_map(
                function ($t) use ($dayAbbr) {
                    return $dayAbbr[strtolower(trim($t))] ?? '';
                },
                explode(',', (string)$doctor['available_days'])
            )));
            if ($tokens) {
                $weekday = strtolower(date('D', strtotime($date)));
                if (!in_array($weekday, $tokens, true)) {
                    $errors[] = $doctor['name'] . ' sees patients on ' . $doctor['available_days'] . ' — please pick one of those days.';
                }
            }
        }
    }

    /* Mode whitelist. Video falls back to phone when the doctor has it disabled. */
    if (!in_array($mode, ['in_person', 'video', 'phone'], true)) {
        $mode = 'in_person';
    }
    if ($doctor && $mode === 'video' && !(int)$doctor['video_enabled']) {
        $mode = 'phone'; // default back to phone per spec
    }

    /* Notes length cap. */
    if (mb_strlen($notes) > 500) {
        $errors[] = 'Notes must be 500 characters or fewer.';
    }

    if ($errors) {
        flash('error', reset($errors));
        redirect($SELF);
    }

    /* Insert (status defaults to 'scheduled'). */
    $stmt = db()->prepare('INSERT INTO appointments (user_id, doctor_id, appointment_date, appointment_time, mode, notes) VALUES (?, ?, ?, ?, ?, ?)');
    $stmt->bind_param('iissss', $userId, $doctorId, $date, $time, $mode, $notes);
    $stmt->execute();
    $stmt->close();

    $modeTxt = ['in_person' => 'in person', 'video' => 'by video call', 'phone' => 'by phone'][$mode];
    add_notification($userId, 'appointment', 'Appointment booked',
        "Your {$modeTxt} appointment with {$doctor['name']} on {$date} at {$timeShort} is scheduled.");

    flash('success', "📅 Appointment booked with " . $doctor['name'] . " on {$date} at {$timeShort} ({$modeTxt}).");
    redirect('account/appointments.php');
}

require_once $ROOT . '/includes/header.php';

/* ------------------------------- Doctor list ------------------------------- */
$doctors = fetch_all(
    'SELECT id, name, specialization, bio, consultation_fee, image, contact_phone, available_days, available_from, available_to, video_enabled
     FROM doctors ORDER BY name ASC'
);
$today = date('Y-m-d');
?>

<sect class="section">
  <h1 class="section-title">🩺 Our doctors</h1>
  <p class="section-subtitle">
    Pick a doctor and book an appointment — in person, by video call or over the phone.
    Booking takes under a minute.
  </p>

  <div class="notice mb-3">
    🎥 Video consultation ready — add <code>VIDEO_CONSULT_API_KEY</code> in <code>includes/config.php</code>
    to enable live rooms (demo mode shows a placeholder room).
  </div>

   <?php if (!$doctors): ?>
    <div class="empty-state">
      <div class="empty-icon">👨‍⚕️</div>
      <h3>No doctors listed yet</h3>
      <p>Please check back soon — our medical team is being set up.</p>
    </div>
  <?php else: ?>
    <div class="doc-list">
      <?php foreach ($doctors as $doc): ?>
        <?php
            $video  = (int)$doc['video_enabled'] === 1;
            $from   = substr((string)$doc['available_from'], 0, 5);
            $to     = substr((string)$doc['available_to'], 0, 5);
            $nextUrl = u('login.php') . '?next=' . urlencode($SELF);
        ?>
        <div class="card doc-card">
          <!-- Left: who the doctor is -->
          <div class="doc-info">
            <div class="facility-head mb-1">
              <div class="facility-icon"><?= icon($doc['image'], '🩺') ?></div>
              <div>
                <h3><?= e($doc['name']) ?></h3>
                <span class="badge badge-info"><?= e($doc['specialization']) ?></span>
              </div>
            </div>

            <p class="product-desc"><?= e($doc['bio']) ?></p>

            <div class="mt-2 mb-1">
              <strong class="product-price"><?= money($doc['consultation_fee']) ?></strong>
              <span class="muted">consultation fee</span>
            </div>

            <p class="muted mb-1">🕒 <?= e($doc['available_days']) ?> · <?= e($from) ?>–<?= e($to) ?></p>

            <div class="mb-2">
              <?php if ($video): ?>
                <span class="badge badge-success">📹 Video visits available</span>
              <?php else: ?>
                <span class="badge">📱 In-person &amp; phone only</span>
              <?php endif; ?>
            </div>
          </div>

          <!-- Right: the booking form, in its own breathing space -->
          <div class="doc-book">
            <?php if (is_logged_in()): ?>
              <p class="muted" style="margin:0;">📅 Book your visit — pick a date and time inside <?= e($doc['name']) ?>'s consultation window.</p>

              <form method="post" action="<?= u($SELF) ?>" class="js-trim">
                <?= csrf_field() ?>
                <input type="hidden" name="doctor_id" value="<?= (int)$doc['id'] ?>">

                <div class="form-row">
                  <div class="form-group">
                    <label class="form-label" for="appt-date-<?= (int)$doc['id'] ?>">Date</label>
                    <input class="form-input" type="date" id="appt-date-<?= (int)$doc['id'] ?>"
                           name="appointment_date" min="<?= e($today) ?>" value="<?= e($today) ?>" required>
                  </div>
                  <div class="form-group">
                    <label class="form-label" for="appt-time-<?= (int)$doc['id'] ?>">Time</label>
                    <input class="form-input" type="time" id="appt-time-<?= (int)$doc['id'] ?>"
                           name="appointment_time" min="<?= e($from) ?>" max="<?= e($to) ?>" value="<?= e($from) ?>" required>
                  </div>
                </div>

                <div class="form-group">
                  <label class="form-label" for="appt-mode-<?= (int)$doc['id'] ?>">Consultation mode</label>
                  <select class="form-select" id="appt-mode-<?= (int)$doc['id'] ?>" name="mode">
                    <option value="in_person">In person — <?= e($from) ?>–<?= e($to) ?></option>
                    <?php if ($video): ?><option value="video">Video call</option><?php endif; ?>
                    <option value="phone">Phone call</option>
                  </select>
                </div>

                <div class="form-group">
                  <label class="form-label" for="appt-notes-<?= (int)$doc['id'] ?>">Notes (optional)</label>
                  <textarea class="form-textarea" id="appt-notes-<?= (int)$doc['id'] ?>" name="notes" rows="3"
                            maxlength="500" placeholder="Symptoms or questions for the doctor (max 500 chars)"></textarea>
                </div>

                <button type="submit" class="btn btn-primary btn-sm btn-block">📅 Book appointment</button>
              </form>
            <?php else: ?>
              <p class="muted" style="margin:0;">🔐 Booking requires an account — logging in takes a moment and keeps your appointments in one place.</p>
              <a class="btn btn-outline btn-sm btn-block" href="<?= $nextUrl ?>">Log in to book</a>
            <?php endif; ?>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</section>

<?php require_once $ROOT . '/includes/footer.php'; ?>
