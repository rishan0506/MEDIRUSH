<?php
/**
 * MEDIRUSH — my_health/skincare_tracker.php — Skincare routine tracker (7-day completions + streaks).
 */
declare(strict_types=1);
$ROOT = '..';
$PAGE_TITLE = 'Skincare Tracker — MEDIRUSH';
$ACTIVE = 'my_health';
$SHOW_SIDEBAR = true;
require_once $ROOT . '/includes/auth.php';
require_login();

$user = current_user();
$userId = (int)$user['id'];

/* ------------------------------ POST handlers ------------------------------ */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    /* Add a routine */
    if (isset($_POST['add_routine'])) {
        $name     = trim((string)($_POST['name'] ?? ''));
        $skinType = trim((string)($_POST['skin_type'] ?? 'all'));
        $morning  = trim((string)($_POST['morning_routine'] ?? ''));
        $evening  = trim((string)($_POST['evening_routine'] ?? ''));
        $notes    = mb_substr(trim((string)($_POST['notes'] ?? '')), 0, 500);

        if (mb_strlen($name) < 2 || mb_strlen($name) > 80) {
            flash('error', 'Routine name must be between 2 and 80 characters.');
            redirect('my_health/skincare_tracker.php');
        }
        if (!in_array($skinType, ['oily', 'dry', 'combination', 'sensitive', 'all'], true)) {
            flash('error', 'Choose a valid skin type from the list.');
            redirect('my_health/skincare_tracker.php');
        }
        if ($morning === '' && $evening === '') {
            flash('error', 'Describe at least a morning or an evening routine.');
            redirect('my_health/skincare_tracker.php');
        }
        if (mb_strlen($morning) > 1000 || mb_strlen($evening) > 1000) {
            flash('error', 'Routine descriptions are too long (max 1000 characters each).');
            redirect('my_health/skincare_tracker.php');
        }

        try {
            $stmt = db()->prepare(
                'INSERT INTO skincare_routines (user_id, name, skin_type, morning_routine, evening_routine, notes)
                 VALUES (?, ?, ?, ?, ?, ?)'
            );
            $stmt->bind_param('isssss', $userId, $name, $skinType, $morning, $evening, $notes);
            $stmt->execute();
            $stmt->close();
        } catch (Throwable $ex) {
            error_log('[MEDIRUSH] add_routine failed: ' . $ex->getMessage());
            flash('error', 'Could not save the routine. Please try again.');
            redirect('my_health/skincare_tracker.php');
        }

        add_notification($userId, 'skincare', 'Routine created',
            'You started a new skincare routine "' . $name . '" — keep the streak going!');
        flash('success', 'Routine "' . $name . '" added. Tick off your first day below!');
        redirect('my_health/skincare_tracker.php');
    }

    /* Mark today complete (upsert on UNIQUE routine_id + log_date) */
    if (isset($_POST['log_today'])) {
        $routineId = (int)$_POST['log_today'];
        $routine = fetch_one('SELECT id, name FROM skincare_routines WHERE id = ? AND user_id = ? LIMIT 1', 'ii', [$routineId, $userId]);
        if (!$routine) {
            flash('error', 'Routine not found.');
            redirect('my_health/skincare_tracker.php');
        }
        $stmt = db()->prepare(
            'INSERT INTO skincare_logs (user_id, routine_id, log_date, completed, notes)
             VALUES (?, ?, CURDATE(), 1, NULL)
             ON DUPLICATE KEY UPDATE completed = 1'
        );
        $stmt->bind_param('ii', $userId, $routineId);
        $stmt->execute();
        $stmt->close();
        flash('success', 'Nice! "' . $routine['name'] . '" is marked complete for today. ✅');
        redirect('my_health/skincare_tracker.php');
    }

    /* Undo today's completion */
    if (isset($_POST['undo_today'])) {
        $routineId = (int)$_POST['undo_today'];
        $stmt = db()->prepare(
            'UPDATE skincare_logs SET completed = 0 WHERE routine_id = ? AND user_id = ? AND log_date = CURDATE()'
        );
        $stmt->bind_param('ii', $routineId, $userId);
        $stmt->execute();
        $stmt->close();
        flash('success', 'Today\'s completion removed for that routine.');
        redirect('my_health/skincare_tracker.php');
    }

    /* Delete a routine (and its logs — explicitly, cascades included) */
    if (isset($_POST['delete_routine'])) {
        $routineId = (int)$_POST['delete_routine'];
        $row = fetch_one('SELECT id FROM skincare_routines WHERE id = ? AND user_id = ? LIMIT 1', 'ii', [$routineId, $userId]);
        if (!$row) {
            flash('error', 'Routine not found.');
            redirect('my_health/skincare_tracker.php');
        }
        $stmt = db()->prepare('DELETE FROM skincare_logs WHERE routine_id = ? AND user_id = ?');
        $stmt->bind_param('ii', $routineId, $userId);
        $stmt->execute();
        $stmt->close();
        $stmt = db()->prepare('DELETE FROM skincare_routines WHERE id = ? AND user_id = ?');
        $stmt->bind_param('ii', $routineId, $userId);
        $stmt->execute();
        $stmt->close();
        flash('success', 'Routine and its history deleted.');
        redirect('my_health/skincare_tracker.php');
    }

    flash('error', 'Unknown action.');
    redirect('my_health/skincare_tracker.php');
}

require_once $ROOT . '/includes/header.php';

/* ------------------------------ Fetch data ------------------------------ */
$routines = fetch_all(
    'SELECT * FROM skincare_routines WHERE user_id = ? ORDER BY created_at DESC, id DESC',
    'i', [$userId]
);

/* All logs of the last 7 days, grouped in PHP by routine and date */
$today = date('Y-m-d');
$weekStart = date('Y-m-d', strtotime('-6 days')); // CURDATE() - INTERVAL 6 DAY
$logRows = fetch_all(
    'SELECT routine_id, log_date, completed FROM skincare_logs WHERE user_id = ? AND log_date >= ?',
    'is', [$userId, $weekStart]
);
$logMap = []; // [routineId][Y-m-d] => completed*1
foreach ($logRows as $l) {
    $logMap[(int)$l['routine_id']][(string)$l['log_date']] = (int)$l['completed'] === 1;
}

/* Build the fixed 7-day window (oldest → today) with S M T W T F S labels */
$days = [];
$dayLetters = ['Mon' => 'M', 'Tue' => 'T', 'Wed' => 'W', 'Thu' => 'T', 'Fri' => 'F', 'Sat' => 'S', 'Sun' => 'S'];
for ($i = 6; $i >= 0; $i--) {
    $ts = strtotime("-$i days");
    $days[] = [
        'ymd'    => date('Y-m-d', $ts),
        'letter' => $dayLetters[date('D', $ts)] ?? '?',
        'isToday'=> $i === 0,
    ];
}

function streak_for(array $logMap, int $routineId, string $today): int {
    $streak = 0;
    $ts = strtotime($today);
    for ($i = 0; $i < 3650; $i++) { // sanity cap
        $ymd = date('Y-m-d', $ts);
        if (!isset($logMap[$routineId][$ymd]) || !$logMap[$routineId][$ymd]) {
            break;
        }
        $streak++;
        $ts = strtotime('-1 day', $ts);
    }
    return $streak;
}

$skinTypeLabels = ['oily' => 'Oily skin', 'dry' => 'Dry skin', 'combination' => 'Combination skin', 'sensitive' => 'Sensitive skin', 'all' => 'All skin types'];
?>
<div class="sidebar-wrap">
  <div class="sidebar-main">
    <div class="container">

      <div style="margin: 28px 0 18px;">
        <h1 class="section-title" style="margin-bottom: 2px;">🧴 Skincare routines</h1>
        <p class="muted">Consistency beats complexity — build a routine, tick off each day and keep your streak alive.</p>
      </div>

      <!-- Add routine -->
      <div class="card">
        <div class="card-body">
          <h2 style="font-size: 1.1rem;">➕ Add a routine</h2>
          <form method="post" action="<?= e(u('my_health/skincare_tracker.php')) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="add_routine" value="1">
            <div class="grid grid-2">
              <div class="form-group">
                <label class="form-label" for="name">Routine name *</label>
                <input class="form-input" type="text" id="name" name="name" minlength="2" maxlength="80" placeholder="e.g. Morning basics" required>
              </div>
              <div class="form-group">
                <label class="form-label" for="skin_type">Skin type</label>
                <select class="form-select" id="skin_type" name="skin_type">
                  <option value="all">All skin types</option>
                  <option value="oily">Oily</option>
                  <option value="dry">Dry</option>
                  <option value="combination">Combination</option>
                  <option value="sensitive">Sensitive</option>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label class="form-label" for="morning_routine">Morning routine</label>
              <textarea class="form-textarea" id="morning_routine" name="morning_routine" maxlength="1000" placeholder="e.g. 🧼 Gentle cleanser → 💧 hydrating toner → 🧴 moisturiser → ☀️ SPF 50"></textarea>
            </div>
            <div class="form-group">
              <label class="form-label" for="evening_routine">Evening routine</label>
              <textarea class="form-textarea" id="evening_routine" name="evening_routine" maxlength="1000" placeholder="e.g. 🧼 double cleanse → 💦 micellar water → 🌙 night cream"></textarea>
            </div>
            <div class="form-group">
              <label class="form-label" for="notes">Notes <span class="muted">(optional, ≤ 500)</span></label>
              <textarea class="form-textarea" id="notes" name="notes" maxlength="500" placeholder="Products, patch-test warnings, prices…"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">💾 Save routine</button>
            <p class="form-help" style="margin-top: 10px;">💡 Editing a routine: currently it's delete + re-add — your 7-day history resets when the routine is deleted, so only re-create when you truly change steps.</p>
          </form>
        </div>
      </div>

      <!-- Routines list -->
      <div style="margin-top: 24px;">
        <h2 class="section-title" style="font-size: 1.25rem;">🗓 Your routines</h2>
        <?php if (!$routines): ?>
          <div class="empty-state card">
            <p style="font-size: 2.4rem; margin-bottom: 6px;">🧴</p>
            <h3>No routines yet</h3>
            <p>Start with something simple like "Morning basics" — cleanser, moisturiser, SPF. Small habits stick better than complicated ones.</p>
          </div>
        <?php else: ?>
          <?php foreach ($routines as $r): $rid = (int)$r['id']; ?>
            <div class="card" style="margin-bottom: 18px;">
              <div class="card-body">
                <div class="flex-between">
                  <div>
                    <h3 style="font-size: 1.1rem; margin: 0 0 4px;">🧼 <?= e($r['name']) ?></h3>
                    <span class="badge badge-info"><?= e($skinTypeLabels[$r['skin_type']] ?? ucfirst((string)$r['skin_type'])) ?></span>
                    <?php $streak = streak_for($logMap, $rid, $today); ?>
                    <span class="badge badge-success" title="Consecutive days completed up to today">🔥 <?= (int)$streak ?> day<?= $streak === 1 ? '' : 's' ?> streak</span>
                  </div>
                  <form method="post" action="<?= e(u('my_health/skincare_tracker.php')) ?>" onsubmit="return confirm('Delete this routine and its full history?');">
                    <?= csrf_field() ?>
                    <input type="hidden" name="delete_routine" value="<?= $rid ?>">
                    <button type="submit" class="btn btn-danger btn-sm">🗑 Delete</button>
                  </form>
                </div>

                <?php if (trim((string)($r['morning_routine'] ?? '')) !== ''): ?>
                  <p style="margin: 10px 0 0;"><strong>🌅 Morning:</strong> <span class="muted"><?= e($r['morning_routine']) ?></span></p>
                <?php endif; ?>
                <?php if (trim((string)($r['evening_routine'] ?? '')) !== ''): ?>
                  <p style="margin: 4px 0 0;"><strong>🌙 Evening:</strong> <span class="muted"><?= e($r['evening_routine']) ?></span></p>
                <?php endif; ?>
                <?php if (trim((string)($r['notes'] ?? '')) !== ''): ?>
                  <p class="form-help" style="margin-top: 4px;">📝 <?= e($r['notes']) ?></p>
                <?php endif; ?>

                <!-- 7-day strip -->
                <div style="margin-top: 14px; display: flex; gap: 14px; align-items: center; flex-wrap: wrap; padding: 10px 14px; border: 1px solid var(--border); border-radius: var(--radius-sm); background: var(--bg);">
                  <?php foreach ($days as $d): ?>
                    <?php $done = $logMap[$rid][$d['ymd']] ?? false; ?>
                    <span style="text-align: center; min-width: 44px;" title="<?= e($d['ymd']) ?><?= $d['isToday'] ? ' (today)' : '' ?>">
                      <strong class="<?= $d['isToday'] ? 'badge badge-info' : 'muted' ?>" style="display: block; margin-bottom: 2px;"><?= e($d['letter']) ?></strong>
                      <span style="font-size: 1.15rem;"><?= $done ? '✅' : '⬜' ?></span>
                    </span>
                  <?php endforeach; ?>
                </div>

                <!-- Today's action -->
                <div class="flex-between" style="margin-top: 12px;">
                  <?php $doneToday = $logMap[$rid][$today] ?? false; ?>
                  <?php if ($doneToday): ?>
                    <form method="post" action="<?= e(u('my_health/skincare_tracker.php')) ?>">
                      <?= csrf_field() ?>
                      <input type="hidden" name="undo_today" value="<?= $rid ?>">
                      <button type="submit" class="btn btn-outline btn-sm" title="Remove today's completion">↩ Undo</button>
                    </form>
                  <?php else: ?>
                    <form method="post" action="<?= e(u('my_health/skincare_tracker.php')) ?>">
                      <?= csrf_field() ?>
                      <input type="hidden" name="log_today" value="<?= $rid ?>">
                      <button type="submit" class="btn btn-primary btn-sm">✅ Mark today complete</button>
                    </form>
                  <?php endif; ?>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
          <p class="form-help" style="margin-bottom: 10px;">Dots show your last 7 days (oldest → today). ✅ means done, ⬜ means missed. Today's column is highlighted.</p>
        <?php endif; ?>
      </div>

    </div>
  </div>
</div>
<?php require_once $ROOT . '/includes/footer.php'; ?>
