<?php
/**
 * MEDIRUSH — Checkout (protected). Demo payment only.
 */
$ROOT = '..';
$PAGE_TITLE = 'Checkout — MEDIRUSH';
$ACTIVE = 'pharmacy';
$SHOW_SIDEBAR = false;
require_once $ROOT . '/includes/auth.php';

if (!is_logged_in()) {
    require_login('pharmacy/checkout.php');
}
$user = current_user();
$cartId = get_or_create_cart((int)$user['id']);

$PAY_METHODS = [
    'demo_card'        => '💳 Demo Card',
    'demo_ewallet'     => '👛 Demo e-Wallet',
    'cash_on_delivery' => '💵 Cash on Delivery',
];

/* --------------------------- Place the order (POST) ------------------------ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'place_order') {
    verify_csrf();
    $deliveryAddress = trim((string)($_POST['delivery_address'] ?? ''));
    $paymentMethod   = (string)($_POST['payment_method'] ?? '');

    if (mb_strlen($deliveryAddress) < 10) {
        flash('error', 'Please enter a full delivery address (at least 10 characters).');
        redirect('pharmacy/checkout.php');
    }
    if (!array_key_exists($paymentMethod, $PAY_METHODS)) {
        flash('error', 'Please choose a valid payment method.');
        redirect('pharmacy/checkout.php');
    }

    // Load cart with live prices — totals are computed server-side, never trusted from the client.
    $pharmacyItems = fetch_all(
        "SELECT ci.product_id, ci.quantity, p.name, p.price, p.stock
         FROM cart_items ci
         JOIN carts c ON c.id = ci.cart_id AND c.user_id = ?
         LEFT JOIN pharmacy_products p ON p.id = ci.product_id
         WHERE ci.product_type = 'pharmacy'",
        'i',
        [(int)$user['id']]
    );
    $skincareItems = fetch_all(
        "SELECT ci.product_id, ci.quantity, s.name, s.price, s.stock
         FROM cart_items ci
         JOIN carts c ON c.id = ci.cart_id AND c.user_id = ?
         LEFT JOIN skincare_products s ON s.id = ci.product_id
         WHERE ci.product_type = 'skincare'",
        'i',
        [(int)$user['id']]
    );

    $total = 0.00;
    $hasItems = false;
    foreach ($pharmacyItems as $it) {
        if ($it['name'] === null) continue;
        $hasItems = true;
        $total += (float)$it['price'] * (int)$it['quantity'];
    }
    foreach ($skincareItems as $it) {
        if ($it['name'] === null) continue;
        $hasItems = true;
        $total += (float)$it['price'] * (int)$it['quantity'];
    }

    if (!$hasItems) {
        flash('info', 'Your cart is empty — add some products first.');
        redirect('pharmacy/cart.php');
    }

    $orderNumber = 'MD-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(3)));
    $conn = db();
    try {
        $conn->begin_transaction();

        $stmt = $conn->prepare(
            'INSERT INTO orders (user_id, order_number, total, status, payment_method, delivery_address)
             VALUES (?, ?, ?, ?, ?, ?)'
        );
        $status = 'processing';
        $userId = (int)$user['id'];
        $stmt->bind_param('isdsss', $userId, $orderNumber, $total, $status, $paymentMethod, $deliveryAddress);
        $stmt->execute();
        $orderId = (int)$conn->insert_id;
        $stmt->close();

        $insItem = $conn->prepare(
            'INSERT INTO order_items (order_id, product_type, product_id, product_name, quantity, unit_price)
             VALUES (?, ?, ?, ?, ?, ?)'
        );
        $decPharm = $conn->prepare('UPDATE pharmacy_products SET stock = GREATEST(stock - ?, 0) WHERE id = ?');
        $decSkin  = $conn->prepare('UPDATE skincare_products SET stock = GREATEST(stock - ?, 0) WHERE id = ?');

        foreach (['pharmacy' => $pharmacyItems, 'skincare' => $skincareItems] as $type => $rows) {
            foreach ($rows as $it) {
                if ($it['name'] === null) continue; // product deleted — skip
                $qty = (int)$it['quantity'];
                $stmtT = $type; $pid = (int)$it['product_id'];
                $insItem->bind_param('isisid', $orderId, $stmtT, $pid, $it['name'], $qty, $it['price']);
                $insItem->execute();
                if ($type === 'pharmacy') {
                    $decPharm->bind_param('ii', $qty, $pid);
                    $decPharm->execute();
                } else {
                    $decSkin->bind_param('ii', $qty, $pid);
                    $decSkin->execute();
                }
            }
        }
        $insItem->close();
        $decPharm->close();
        $decSkin->close();

        // Empty the cart.
        $stmt = $conn->prepare('DELETE FROM cart_items WHERE cart_id = ?');
        $stmt->bind_param('i', $cartId);
        $stmt->execute();
        $stmt->close();

        $conn->commit();
    } catch (Throwable $ex) {
        $conn->rollback();
        error_log('MEDIRUSH checkout error: ' . $ex->getMessage());
        flash('error', 'We could not place your order right now — please try again.');
        redirect('pharmacy/cart.php');
    }

    add_notification((int)$user['id'], 'order', 'Order placed — #' . $orderNumber, 'We received your order ' . $orderNumber . ' (' . money($total) . '). Track it in My Orders.');
    flash('success', 'Order placed successfully 🎉');
    redirect('account/orders.php');
}

/* ----------------------------- Render the page ----------------------------- */
$cartEmpty = !fetch_one(
    "SELECT id FROM cart_items
     JOIN carts c ON c.id = cart_items.cart_id AND c.user_id = ?
     WHERE cart_items.cart_id = ? LIMIT 1",
    'ii',
    [(int)$user['id'], $cartId]
);
if ($cartEmpty) {
    flash('info', 'Your cart is empty — add some products first.');
    redirect('pharmacy/cart.php');
}

// Prefill the delivery address from the user's profile.
$profile = fetch_one('SELECT address FROM user_profiles WHERE user_id = ? LIMIT 1', 'i', [(int)$user['id']]);
$savedAddress = trim((string)($profile['address'] ?? ''));

$pharmacyItems = fetch_all(
    "SELECT ci.id, ci.product_id, ci.quantity, p.name, p.price, p.image
     FROM cart_items ci
     JOIN carts c ON c.id = ci.cart_id AND c.user_id = ?
     LEFT JOIN pharmacy_products p ON p.id = ci.product_id
     WHERE ci.product_type = 'pharmacy'
     ORDER BY ci.id ASC",
    'i',
    [(int)$user['id']]
);
$skincareItems = fetch_all(
    "SELECT ci.id, ci.product_id, ci.quantity, s.name, s.price, s.image
     FROM cart_items ci
     JOIN carts c ON c.id = ci.cart_id AND c.user_id = ?
     LEFT JOIN skincare_products s ON s.id = ci.product_id
     WHERE ci.product_type = 'skincare'
     ORDER BY ci.id ASC",
    'i',
    [(int)$user['id']]
);

$pharmacySubtotal = 0.00;
$skincareSubtotal = 0.00;
foreach ($pharmacyItems as $it) { if ($it['name'] !== null) $pharmacySubtotal += (float)$it['price'] * (int)$it['quantity']; }
foreach ($skincareItems as $it) { if ($it['name'] !== null) $skincareSubtotal += (float)$it['price'] * (int)$it['quantity']; }
$grandTotal = $pharmacySubtotal + $skincareSubtotal;

require_once $ROOT . '/includes/header.php';
?>

<section class="section">
  <div class="container">
    <h1 class="section-title">💳 Checkout</h1>
    <p class="section-subtitle">Confirm your delivery details and place your order.</p>

    <div class="grid grid-2">
      <div class="card">
        <div class="card-body">
          <h2 class="section-title">📦 Order summary</h2>

          <h3 class="form-label"><span class="badge badge-info">Pharmacy</span></h3>
          <?php if ($pharmacyItems): ?>
            <?php foreach ($pharmacyItems as $it): if ($it['name'] === null) continue; ?>
              <div class="order-summary-line">
                <span><?= e(icon($it['image'], '💊')) ?> <?= e($it['name']) ?> × <?= (int)$it['quantity'] ?></span>
                <span><?= money((float)$it['price'] * (int)$it['quantity']) ?></span>
              </div>
            <?php endforeach; ?>
            <div class="order-summary-line"><span><em>Pharmacy subtotal</em></span><span><em><?= money($pharmacySubtotal) ?></em></span></div>
          <?php else: ?>
            <p class="muted">No pharmacy items.</p>
          <?php endif; ?>

          <h3 class="form-label"><span class="badge badge-success">Skincare</span></h3>
          <?php if ($skincareItems): ?>
            <?php foreach ($skincareItems as $it): if ($it['name'] === null) continue; ?>
              <div class="order-summary-line">
                <span><?= e(icon($it['image'], '🧴')) ?> <?= e($it['name']) ?> × <?= (int)$it['quantity'] ?></span>
                <span><?= money((float)$it['price'] * (int)$it['quantity']) ?></span>
              </div>
            <?php endforeach; ?>
            <div class="order-summary-line"><span><em>Skincare subtotal</em></span><span><em><?= money($skincareSubtotal) ?></em></span></div>
          <?php else: ?>
            <p class="muted">No skincare items.</p>
          <?php endif; ?>

          <div class="order-summary-line total">
            <span><strong>Grand total</strong></span>
            <span><strong><?= money($grandTotal) ?></strong></span>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-body">
          <form method="post" action="<?= u('pharmacy/checkout.php') ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="place_order">

            <div class="form-group">
              <label class="form-label" for="delivery_address">Delivery address</label>
              <textarea id="delivery_address" name="delivery_address" class="form-textarea" rows="4" required
                placeholder="Street, suburb, city, postal code…"><?= e($savedAddress) ?></textarea>
              <p class="form-help">At least 10 characters. This is where your order will be delivered.</p>
            </div>

            <div class="form-group">
              <span class="form-label">Payment method</span>
              <?php $first = true; foreach ($PAY_METHODS as $key => $label): ?>
                <label class="payment-radio">
                  <input type="radio" name="payment_method" value="<?= e($key) ?>"<?= $first ? ' checked' : '' ?>>
                  <?= e($label) ?>
                </label>
                <?php $first = false; endforeach; ?>
              <p class="form-help">💳 Demo payment — Checkout always succeeds in this demo; connect PAYMENT_GATEWAY_API_KEY in includes/config.php for real payments.</p>
            </div>

            <button type="submit" class="btn btn-primary btn-block">Place order</button>
            <p class="form-help">🔒 Demo checkout — no real payment is processed.</p>
          </form>

          <p><a href="<?= u('pharmacy/cart.php') ?>">← Back to cart</a></p>
        </div>
      </div>
    </div>
  </div>
</section>

<?php require_once $ROOT . '/includes/footer.php'; ?>
