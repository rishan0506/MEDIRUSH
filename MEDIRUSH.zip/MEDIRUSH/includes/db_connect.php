<?php
/**
 * MEDIRUSH — MySQL connection (mysqli) + SELF-CONTAINED schema installer.
 *
 * Default XAMPP credentials. Change DB_PASS if you set a MySQL root password.
 *
 * Behaviour:
 *   • MySQL down / wrong credentials  → friendly setup screen (shows why).
 *   • Server up, database missing     → creates `medirushdb` automatically.
 *   • Tables missing                  → builds the ENTIRE schema from the
 *                                       statements embedded in THIS FILE
 *                                       (+ idempotent demo seed data).
 *   • If anything fails               → setup screen lists the exact failing
 *                                       statement and MySQL error.
 *
 * The embedded schema is identical to database.sql (which remains available for
 * manual phpMyAdmin import). NOTE: mysqli_report(ERR|STRICT) throws exceptions on
 * errors, all probes are try/catch'd — '@' does not suppress exceptions.
 */
declare(strict_types=1);

if (!defined('MEDIRUSH_DB')) {
    define('MEDIRUSH_DB', true);

    define('DB_HOST', 'localhost');
    define('DB_NAME', 'medirushdb');
    define('DB_USER', 'root');
    define('DB_PASS', '');

    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

    $GLOBALS['MEDIRUSH_CONN'] = null;
    $GLOBALS['MEDIRUSH_INSTALL_ERR'] = null;

    /* ------------------------------------------------------------------ *
     *  EMBEDDED SCHEMA (19 tables) + demo seed — runs in order, idempotent
     * ------------------------------------------------------------------ */

    function medirush_schema_statements(): array {
        return [
            "CREATE TABLE IF NOT EXISTS users (
                id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                full_name VARCHAR(80) NOT NULL,
                email VARCHAR(120) NOT NULL UNIQUE,
                password_hash VARCHAR(255) NOT NULL,
                phone VARCHAR(20) NULL,
                role ENUM('user','admin') NOT NULL DEFAULT 'user',
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB",

            "CREATE TABLE IF NOT EXISTS user_profiles (
                id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                user_id INT UNSIGNED NOT NULL UNIQUE,
                address VARCHAR(255) NULL,
                date_of_birth DATE NULL,
                gender ENUM('male','female','other') NOT NULL DEFAULT 'other',
                blood_type VARCHAR(8) NULL,
                country VARCHAR(40) NOT NULL DEFAULT '',
                allergies TEXT NULL,
                chronic_conditions TEXT NULL,
                emergency_contact_name VARCHAR(80) NULL,
                emergency_contact_phone VARCHAR(20) NULL,
                profile_image VARCHAR(255) NULL,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            ) ENGINE=InnoDB",

            "CREATE TABLE IF NOT EXISTS medical_records (
                id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                user_id INT UNSIGNED NOT NULL,
                title VARCHAR(120) NOT NULL,
                record_type ENUM('lab_result','report','scan','other') NOT NULL DEFAULT 'other',
                file_path VARCHAR(255) NOT NULL,
                original_filename VARCHAR(255) NOT NULL,
                notes TEXT NULL,
                uploaded_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                INDEX idx_records_user (user_id)
            ) ENGINE=InnoDB",

            "CREATE TABLE IF NOT EXISTS prescriptions (
                id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                user_id INT UNSIGNED NOT NULL,
                doctor_name VARCHAR(120) NULL,
                file_path VARCHAR(255) NOT NULL,
                original_filename VARCHAR(255) NOT NULL,
                status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
                admin_note TEXT NULL,
                uploaded_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                verified_at DATETIME NULL,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                INDEX idx_rx_user (user_id),
                INDEX idx_rx_status (status)
            ) ENGINE=InnoDB",

            "CREATE TABLE IF NOT EXISTS pharmacy_products (
                id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(120) NOT NULL,
                category ENUM('pain_relief','antibiotics','vitamins','first_aid','chronic_care','other') NOT NULL DEFAULT 'other',
                description TEXT NOT NULL,
                price DECIMAL(10,2) NOT NULL,
                stock INT NOT NULL DEFAULT 0,
                image VARCHAR(50) NOT NULL DEFAULT '💊',
                requires_prescription TINYINT(1) NOT NULL DEFAULT 0,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB",

            "CREATE TABLE IF NOT EXISTS skincare_products (
                id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(120) NOT NULL,
                category ENUM('cleanser','moisturizer','serum','sunscreen','toner','mask','other') NOT NULL DEFAULT 'other',
                skin_type VARCHAR(20) NOT NULL DEFAULT 'all',
                description TEXT NOT NULL,
                price DECIMAL(10,2) NOT NULL,
                stock INT NOT NULL DEFAULT 0,
                image VARCHAR(50) NOT NULL DEFAULT '🧴',
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB",

            "CREATE TABLE IF NOT EXISTS carts (
                id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                user_id INT UNSIGNED NOT NULL UNIQUE,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            ) ENGINE=InnoDB",

            "CREATE TABLE IF NOT EXISTS cart_items (
                id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                cart_id INT UNSIGNED NOT NULL,
                product_type ENUM('pharmacy','skincare') NOT NULL,
                product_id INT UNSIGNED NOT NULL,
                quantity INT UNSIGNED NOT NULL DEFAULT 1,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (cart_id) REFERENCES carts(id) ON DELETE CASCADE,
                KEY idx_cart_product (cart_id, product_type, product_id)
            ) ENGINE=InnoDB",

            "CREATE TABLE IF NOT EXISTS orders (
                id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                user_id INT UNSIGNED NOT NULL,
                order_number VARCHAR(24) NOT NULL UNIQUE,
                total DECIMAL(10,2) NOT NULL,
                status ENUM('pending','processing','shipped','delivered','cancelled') NOT NULL DEFAULT 'pending',
                payment_method ENUM('demo_card','demo_ewallet','cash_on_delivery') NOT NULL DEFAULT 'cash_on_delivery',
                delivery_address VARCHAR(255) NOT NULL,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                INDEX idx_orders_user (user_id)
            ) ENGINE=InnoDB",

            "CREATE TABLE IF NOT EXISTS order_items (
                id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                order_id INT UNSIGNED NOT NULL,
                product_type ENUM('pharmacy','skincare') NOT NULL,
                product_id INT UNSIGNED NOT NULL,
                product_name VARCHAR(120) NOT NULL,
                unit_price DECIMAL(10,2) NOT NULL,
                quantity INT UNSIGNED NOT NULL DEFAULT 1,
                FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
            ) ENGINE=InnoDB",

            "CREATE TABLE IF NOT EXISTS doctors (
                id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(120) NOT NULL,
                specialization VARCHAR(100) NOT NULL,
                bio TEXT NULL,
                consultation_fee DECIMAL(10,2) NOT NULL DEFAULT 0,
                image VARCHAR(50) NOT NULL DEFAULT '🩺',
                contact_email VARCHAR(120) NULL,
                contact_phone VARCHAR(30) NULL,
                available_days VARCHAR(60) NOT NULL DEFAULT 'Mon-Fri',
                available_from TIME NOT NULL DEFAULT '08:30:00',
                available_to TIME NOT NULL DEFAULT '16:30:00',
                video_enabled TINYINT(1) NOT NULL DEFAULT 1
            ) ENGINE=InnoDB",

            "CREATE TABLE IF NOT EXISTS appointments (
                id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                user_id INT UNSIGNED NOT NULL,
                doctor_id INT UNSIGNED NOT NULL,
                appointment_date DATE NOT NULL,
                appointment_time TIME NOT NULL,
                mode ENUM('in_person','video','phone') NOT NULL DEFAULT 'in_person',
                status ENUM('scheduled','completed','cancelled') NOT NULL DEFAULT 'scheduled',
                notes VARCHAR(500) NULL,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE CASCADE,
                INDEX idx_appt_user (user_id)
            ) ENGINE=InnoDB",

            "CREATE TABLE IF NOT EXISTS medications (
                id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                user_id INT UNSIGNED NOT NULL,
                medicine_name VARCHAR(120) NOT NULL,
                dosage VARCHAR(60) NULL,
                frequency VARCHAR(60) NULL,
                start_date DATE NULL,
                end_date DATE NULL,
                instructions VARCHAR(500) NULL,
                is_active TINYINT(1) NOT NULL DEFAULT 1,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                INDEX idx_meds_user (user_id)
            ) ENGINE=InnoDB",

            "CREATE TABLE IF NOT EXISTS medication_reminders (
                id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                medication_id INT UNSIGNED NOT NULL,
                user_id INT UNSIGNED NOT NULL,
                reminder_time TIME NOT NULL,
                is_active TINYINT(1) NOT NULL DEFAULT 1,
                FOREIGN KEY (medication_id) REFERENCES medications(id) ON DELETE CASCADE,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            ) ENGINE=InnoDB",

            "CREATE TABLE IF NOT EXISTS skincare_routines (
                id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                user_id INT UNSIGNED NOT NULL,
                name VARCHAR(80) NOT NULL,
                skin_type VARCHAR(20) NOT NULL DEFAULT 'all',
                morning_routine TEXT NULL,
                evening_routine TEXT NULL,
                notes TEXT NULL,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            ) ENGINE=InnoDB",

            "CREATE TABLE IF NOT EXISTS skincare_logs (
                id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                user_id INT UNSIGNED NOT NULL,
                routine_id INT UNSIGNED NOT NULL,
                log_date DATE NOT NULL,
                completed TINYINT(1) NOT NULL DEFAULT 1,
                notes TEXT NULL,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                FOREIGN KEY (routine_id) REFERENCES skincare_routines(id) ON DELETE CASCADE,
                UNIQUE KEY uq_routine_day (routine_id, log_date)
            ) ENGINE=InnoDB",

            "CREATE TABLE IF NOT EXISTS healthcare_facilities (
                id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(120) NOT NULL,
                type ENUM('hospital','clinic','pharmacy','laboratory') NOT NULL DEFAULT 'clinic',
                address VARCHAR(255) NOT NULL,
                city VARCHAR(80) NULL,
                phone VARCHAR(30) NULL,
                latitude DECIMAL(10,7) NOT NULL,
                longitude DECIMAL(10,7) NOT NULL,
                is_emergency TINYINT(1) NOT NULL DEFAULT 0,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB",

            "CREATE TABLE IF NOT EXISTS notifications (
                id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                user_id INT UNSIGNED NOT NULL,
                type VARCHAR(40) NOT NULL DEFAULT 'general',
                title VARCHAR(120) NOT NULL,
                message TEXT NOT NULL,
                is_read TINYINT(1) NOT NULL DEFAULT 0,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                INDEX idx_notif_user (user_id, is_read)
            ) ENGINE=InnoDB",

            "CREATE TABLE IF NOT EXISTS messages (
                id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                user_id INT UNSIGNED NOT NULL,
                doctor_id INT UNSIGNED NULL,
                sender ENUM('user','pro') NOT NULL DEFAULT 'user',
                body VARCHAR(1000) NOT NULL,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                INDEX idx_msg_user (user_id)
            ) ENGINE=InnoDB",
        ];
    }

    /** Demo seed data — INSERT IGNORE with pinned ids, so re-runs never duplicate. */
    function medirush_seed_statements(): array {
        $hash = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'; // bcrypt("password")
        return [
            "INSERT IGNORE INTO users (id, full_name, email, password_hash, phone, role) VALUES
                (1, 'MEDIRUSH Admin', 'admin@medirush.local', '{$hash}', '0115550001', 'admin'),
                (2, 'Dineo Mokoena', 'demo@medirush.local', '{$hash}', '0825551234', 'user')",

            "INSERT IGNORE INTO user_profiles (id, user_id, address, date_of_birth, gender, blood_type, country, allergies, chronic_conditions, emergency_contact_name, emergency_contact_phone) VALUES
                (2, 2, '45 Jacaranda Street, Sandton', '1996-04-12', 'female', 'O+', '', 'Penicillin', 'Mild asthma', 'Thabo Mokoena', '0835559876')",

            "INSERT IGNORE INTO pharmacy_products (id, name, category, description, price, stock, image, requires_prescription) VALUES
                (1, 'Paracetamol 500mg (24 tabs)', 'pain_relief', 'Fast-acting relief for headaches, fever and mild aches.', 29.99, 140, '💊', 0),
                (2, 'Ibuprofen 200mg (24 tabs)', 'pain_relief', 'Anti-inflammatory pain relief for muscle pain and back pain.', 44.50, 96, '💊', 0),
                (3, 'Amoxicillin 250mg (21 caps)', 'antibiotics', 'Prescription antibiotic for bacterial infections. Complete the full course.', 118.00, 42, '🧫', 1),
                (4, 'Vitamin C 1000mg (60 tabs)', 'vitamins', 'Daily immune support with high-dose vitamin C and zinc.', 89.95, 77, '🍊', 0),
                (5, 'Multivitamin Complex', 'vitamins', 'Complete A-Z multivitamin for daily energy and wellbeing.', 129.00, 63, '🧬', 0),
                (6, 'First Aid Kit (family)', 'first_aid', 'Plasters, gauze, antiseptic, burn gel, gloves and bandages in one kit.', 249.00, 25, '🩹', 0),
                (7, 'Blood Pressure Monitor', 'chronic_care', 'Digital upper-arm BP monitor with irregular heartbeat detection.', 799.00, 14, '🩺', 0),
                (8, 'Glucometer Test Strips (50)', 'chronic_care', 'Blood glucose test strips, compatible with the MEDIRUSH kit monitor.', 219.00, 6, '🩸', 0)",

            "INSERT IGNORE INTO skincare_products (id, name, category, skin_type, description, price, stock, image) VALUES
                (1, 'Gentle Foaming Cleanser', 'cleanser', 'sensitive', 'Soap-free everyday cleanser for all skin types.', 149.00, 80, '🧼'),
                (2, 'Hydrating Cream Cleanser', 'cleanser', 'dry', 'Rich cream cleanser with glycerin that adds moisture while cleansing.', 159.00, 55, '🧴'),
                (3, 'Pore Clarifying Toner', 'toner', 'oily', 'Balancing toner with witch hazel to refine pores gently.', 129.00, 60, '💧'),
                (4, 'Hyaluronic Dew Serum', 'serum', 'all', 'Plumps skin with hyaluronic acid — layers perfectly under SPF.', 245.00, 40, '💦'),
                (5, 'Brightening Vitamin C Serum', 'serum', 'all', 'Antioxidant serum targeting dark spots and dullness over 8 weeks.', 289.00, 33, '🍋'),
                (6, 'Oil-Free Gel Moisturizer', 'moisturizer', 'oily', 'Oil-free niacinamide hydration — lightweight, non-comedogenic.', 199.00, 58, '🫧'),
                (7, 'Barrier Repair Cream', 'moisturizer', 'sensitive', 'Ceramide + centella cream that restores the moisture barrier.', 229.00, 21, '🌿'),
                (8, 'Clay Detox Mask', 'mask', 'oily', 'Kaolin clay mask that absorbs excess oil. Use weekly.', 169.99, 4, '🧖'),
                (9, 'SPF 50 Daily Sunscreen', 'sunscreen', 'all', 'No white cast, SPF 50 PA++++ for daily sun protection.', 179.00, 0, '☀️'),
                (10, 'Soothing Aloe Mask', 'mask', 'combination', 'Cooling gel mask for post-sun calm and hydration boosts.', 139.00, 47, '🌿')",

            "INSERT IGNORE INTO doctors (id, name, specialization, bio, consultation_fee, image, contact_email, contact_phone, available_days, available_from, available_to, video_enabled) VALUES
                (1, 'Dr. Sipho Ndlovu', 'General Practitioner', 'Family medicine with 12 years of experience in primary and urgent care.', 450.00, '🩺', 'sipho.ndlovu@medirush.local', '0115550101', 'Mon, Tue, Wed, Thu, Fri', '08:00:00', '16:00:00', 1),
                (2, 'Dr. Amara Chen', 'Dermatologist', 'Medical and cosmetic dermatology; acne, pigmentation and barrier care.', 750.00, '🧴', 'amara.chen@medirush.local', '0115550102', 'Mon, Wed, Fri', '09:00:00', '14:00:00', 1),
                (3, 'Dr. Lerato Khumalo', 'Paediatrician', 'Newborn to teen care, growth checks, vaccines and childhood illnesses.', 600.00, '🧒', 'lerato.k@medirush.local', '0115550103', 'Tue, Thu, Sat', '08:30:00', '13:00:00', 0),
                (4, 'Dr. Johan van Wyk', 'Cardiologist', 'Heart health, hypertension and cholesterol management.', 950.00, '❤️', 'j.vanwyk@medirush.local', '0115550104', 'Mon, Thu', '10:00:00', '15:00:00', 1),
                (5, 'Dr. Zanele Dube', 'Psychologist', 'Talk therapy for anxiety, burnout and everyday life stressors.', 620.00, '🧠', 'zanele.dube@medirush.local', '0115550105', 'Wed, Thu, Fri', '09:00:00', '17:00:00', 1)",

            "INSERT IGNORE INTO healthcare_facilities (id, name, type, address, city, phone, latitude, longitude, is_emergency) VALUES
                (1, 'Sandton Central Hospital', 'hospital', '12 Rivonia Road, Sandhurst', 'Johannesburg', '0115552001', -26.1394000, 28.0393000, 1),
                (2, 'Rhodesfield Clinic', 'clinic', '78 Main Avenue, Kempton Park', 'Kempton Park', '0115552002', -26.1072000, 28.2268000, 0),
                (3, 'Cuando Late-Night Pharmacy', 'pharmacy', '9 Eloff Street Extension, Selby', 'Johannesburg', '0115552003', -26.2141000, 28.0280000, 0),
                (4, 'PathCare Laboratories', 'laboratory', '3 Sherborne Rd, Parktown', 'Johannesburg', '0115552004', -26.1809000, 28.0305000, 0),
                (5, 'Soweto Trauma Unit', 'hospital', '145 Chris Hani Road, Diepkloof', 'Soweto', '0115552005', -26.2678000, 27.8603000, 1),
                (6, 'Rosebank Family Practice', 'clinic', '27 Tyrwhitt Avenue, Rosebank', 'Johannesburg', '0115552006', -26.1456000, 28.0408000, 0),

                (51, 'MEDIRUSH Pharmacy — Manila', 'pharmacy', '15 Avenida Street, Binondo', 'Manila', '+63-2-5550-101', 14.5951000, 120.9750000, 0),
                (52, 'MEDIRUSH Pharmacy — Bangkok', 'pharmacy', '44 Sukhumvit Road, Watthana', 'Bangkok', '+66-2-5550-102', 13.7409000, 100.5611000, 0),
                (53, 'MEDIRUSH Pharmacy — Jakarta', 'pharmacy', '8 Jalan Thamrin, Menteng', 'Jakarta', '+62-21-5550-103', -6.2040000, 106.8500000, 0),
                (54, 'MEDIRUSH Pharmacy — Kuala Lumpur', 'pharmacy', '120 Jalan Bukit Bintang', 'Kuala Lumpur', '+60-3-5550-104', 3.1466000, 101.6958000, 0),
                (55, 'MEDIRUSH Pharmacy — Hanoi', 'pharmacy', '36 Phan Dinh Phung, Ba Dinh', 'Hanoi', '+84-24-5550-105', 21.0333000, 105.8370000, 0)",

            "INSERT IGNORE INTO notifications (id, user_id, type, title, message) VALUES
                (1, 2, 'welcome', 'Welcome to MEDIRUSH 🩺', 'Explore My Health, order from the pharmacy, and try the skincare assistant.')",

            "INSERT IGNORE INTO messages (id, user_id, sender, body) VALUES
                (1, 2, 'pro', 'Hi Dineo! 👋 I am your skin consultant. Tell me about your skin — oily, dry or sensitive?')",
        ];
    }

    /* ------------------------------------------------------------------ *
     *  Connection + install flow
     * ------------------------------------------------------------------ */

    function db(): mysqli {
        if ($GLOBALS['MEDIRUSH_CONN'] === null) {
            try {
                $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
            } catch (mysqli_sql_exception $e) {
                // First-run case: server up but database missing (code 1049).
                if ($e->getCode() === 1049 || str_contains($e->getMessage(), 'Unknown database')) {
                    try {
                        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS);
                        $conn->set_charset('utf8mb4');
                        $conn->query('CREATE DATABASE IF NOT EXISTS `' . DB_NAME . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
                        $conn->select_db(DB_NAME);
                    } catch (mysqli_sql_exception $e2) {
                        error_log('MEDIRUSH DB create error: ' . $e2->getMessage());
                        http_response_code(500);
                        die(medirush_setup_page('Database could not be created', 'MySQL rejected the CREATE DATABASE — check the Control Panel that MySQL is green.'));
                    }
                } else {
                    error_log('MEDIRUSH DB error: ' . $e->getMessage());
                    http_response_code(500);
                    die(medirush_setup_page('MySQL server not reachable', 'MySQL is either not running in the XAMPP Control Panel, or the root password does not match DB_PASS in this file.'));
                }
            }
            if (!isset($conn) || $conn->connect_error) {
                http_response_code(500);
                die(medirush_setup_page('Connection failed', 'Unknown connection problem.'));
            }
            $conn->set_charset('utf8mb4');

            /* Schema probe: build anything missing from THIS file's statements. */
            if (!medirush_tables_present($conn)) {
                medirush_auto_install($conn);
                if (!medirush_tables_present($conn)) {
                    http_response_code(500);
                    $err = $GLOBALS['MEDIRUSH_INSTALL_ERR'] ?: 'unknown error';
                    die(medirush_setup_page(
                        'Database tables could not be created',
                        'The installer ran but one or more statements failed. First error: <br><code style="display:block;margin-top:6px">' . htmlspecialchars($err, ENT_QUOTES) . '</code>'
                    ));
                }
            }

            $GLOBALS['MEDIRUSH_CONN'] = $conn;
        }
        return $GLOBALS['MEDIRUSH_CONN'];
    }

    /** True when the site's core table exists (exception-safe probe). */
    function medirush_tables_present(mysqli $conn): bool {
        try {
            $conn->query('SELECT 1 FROM users LIMIT 1');
            return true;
        } catch (mysqli_sql_exception $e) {
            return false;
        }
    }

    /** Build schema + (re)seed demo data. Collects first error for the setup screen. */
    function medirush_auto_install(mysqli $conn): bool {
        try {
            foreach (medirush_schema_statements() as $sql) {
                try {
                    $conn->query($sql);
                } catch (mysqli_sql_exception $e) {
                    $GLOBALS['MEDIRUSH_INSTALL_ERR'] = 'CREATE failed: ' . $e->getMessage()
                        . ' — statement: ' . mb_substr(preg_replace('/\s+/', ' ', $sql), 0, 80);
                    error_log('MEDIRUSH installer: ' . $GLOBALS['MEDIRUSH_INSTALL_ERR']);
                    return false;
                }
            }
            foreach (medirush_seed_statements() as $sql) {
                try {
                    $conn->query($sql); // INSERT IGNORE — safe on every re-run
                } catch (mysqli_sql_exception $e) {
                    // Seed failures are non-fatal, but note them.
                    error_log('MEDIRUSH seed warning: ' . $e->getMessage());
                }
            }
        } catch (Throwable $e) {
            $GLOBALS['MEDIRUSH_INSTALL_ERR'] = $e->getMessage();
            return false;
        }
        return medirush_tables_present($conn);
    }

    /** Friendly setup screen; shows the collected error detail when present. */
    function medirush_setup_page(string $title, string $detail): string {
        $phpmyadmin = 'http://localhost/phpmyadmin';
        return '<!doctype html><html><head><meta charset="utf-8"><title>MEDIRUSH — Database setup</title>'
            . '<style>body{font-family:"Segoe UI",system-ui,sans-serif;background:#f6f8fb;color:#1c2434;display:grid;place-items:center;min-height:100vh;margin:0;padding:20px}'
            . '.box{max-width:660px;background:#fff;padding:32px;border-radius:14px;box-shadow:0 8px 30px rgba(0,0,0,.08);line-height:1.6}'
            . 'h1{font-size:1.35rem;margin-bottom:10px}code{background:#eef2f7;padding:1px 6px;border-radius:4px;word-break:break-word}'
            . 'ol{margin:12px 0 0 20px}a{color:#0d9488;font-weight:600}</style></head><body>'
            . '<div class="box"><h1>🗄️ MEDIRUSH — ' . htmlspecialchars($title) . '</h1>'
            . '<p>' . $detail . '</p>'
            . '<p style="margin-top:14px"><strong>Manual fix:</strong></p>'
            . '<ol><li>Confirm MySQL is green in the XAMPP Control Panel.</li>'
            . '<li>Open <a href="' . $phpmyadmin . '">phpMyAdmin</a> — the site uses the database <code>medirushdb</code>.</li>'
            . '<li>Select/create the database <code>medirushdb</code>.</li>'
            . '<li><strong>Import</strong> tab → <code>database.sql</code> → Go.</li></ol>'
            . '<p>Paste this screen onto the assistant chat for a pinpoint fix.</p></div></body></html>';
    }
}

// Establish the connection immediately for everything that includes this file directly.
if (session_status() === PHP_SESSION_NONE) {
    session_name('MEDIRUSH_SESSION');
    session_start();
}
db();