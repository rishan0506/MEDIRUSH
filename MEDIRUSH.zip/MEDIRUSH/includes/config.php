<?php
/**
 * MEDIRUSH — External service configuration.
 *
 * ⚠️  PASTE KEYS HERE ONLY. Keys are injected into pages SERVER-SIDE via
 *     window.MEDIRUSH_CONFIG (see header.php). Never put real keys in .js files.
 *     Leave a key empty ('') to keep that feature in clearly-labelled DEMO mode.
 */

// Google Maps — enables live interactive maps on healthcare/emergency_locator.php
define('GOOGLE_MAPS_API_KEY', '');

// AI Skincare Assistant (any HTTPS chat-completion endpoint) — enables live AI
// on beauty/skincare_assistant.php. Empty = built-in rule-based demo assistant.
define('SKINCARE_AI_API_KEY', '');
define('SKINCARE_AI_API_URL', '');   // e.g. https://api.openai.com/v1/chat/completions

// Payment gateway placeholder — checkout always uses labelled DEMO payment
// methods (demo card / demo wallet / cash on delivery) until a gateway is wired up.
define('PAYMENT_GATEWAY_API_KEY', '');

// Video consultation integration placeholder (doctor_consultation.php).
define('VIDEO_CONSULT_API_KEY', '');
