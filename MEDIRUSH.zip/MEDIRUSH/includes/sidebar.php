<?php
/**
 * MEDIRUSH — Dashboard sidebar (included when a page sets $SHOW_SIDEBAR = true).
 * Header/auth include must have run; requires current_user().
 */
declare(strict_types=1);
if (!function_exists('u')) {
    require_once __DIR__ . '/auth.php'; // safety net; normally already loaded by header.php
}
$sideUser = current_user();
$sideLinks = [
    ['dashboard.php',                  '🏠 Dashboard',          'dashboard'],
    ['my_health/my_health.php',        '❤️ My Health',          'my_health'],
    ['my_health/upload.php',           '📤 Uploads',            'upload'],
    ['my_health/medication.php',       '💊 Medications',        'medication'],
    ['my_health/skincare_tracker.php', '🧴 Skincare Tracker',   'skincare_tracker'],
    ['account/appointments.php',       '📅 Appointments',       'appointments'],
    ['account/orders.php',             '🧾 Orders',             'orders'],
    ['pharmacy/cart.php',              '🛒 Cart',               'cart'],
    ['account/profile.php',            '👤 Profile',            'profile'],
    ['account/settings.php',           '⚙️ Settings',           'settings'],
];
$currentPage = basename($_SERVER['SCRIPT_NAME']);
?>
<aside class="sidebar" aria-label="Account sidebar">
  <div class="side-user card">
    <span class="avatar avatar-lg"><?= e(strtoupper(mb_substr($sideUser['full_name'] ?? 'U', 0, 1))) ?></span>
    <strong><?= e($sideUser['full_name'] ?? '') ?></strong>
    <small class="muted"><?= e($sideUser['email'] ?? '') ?></small>
  </div>
  <nav class="side-nav">
    <?php foreach ($sideLinks as [$href, $label, $key]):
        $isActive = ($key === ($_SESSION['active_tab'] ?? '')) || basename($href) === $currentPage; ?>
      <a class="side-link<?= $isActive ? ' active' : '' ?>" href="<?= u($href) ?>"><?= $label ?></a>
    <?php endforeach; ?>
  </nav>
  <a class="btn btn-outline btn-block" href="<?= u('logout.php') ?>">🚪 Log out</a>
</aside>
