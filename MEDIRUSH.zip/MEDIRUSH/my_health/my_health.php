<?php
/**
 * MEDIRUSH — my_health/my_health.php — Personal health overview.
 */
declare(strict_types=1);
$ROOT = '..';
$PAGE_TITLE = 'My Health — MEDIRUSH';
$ACTIVE = 'my_health';
$SHOW_SIDEBAR = true;
require_once $ROOT . '/includes/auth.php';
require_login();

$user = current_user();
$userId = (int)$user['id'];

require_once $ROOT . '/includes/header.php';

/* Heading card — page content sits inside the sidebar layout */
$stmt = db()->prepare('SELECT COUNT(*) AS c FROM appointments WHERE user_id = ? AND status = \'scheduled\' AND appointment_date >= CURDATE()');
$stmt->bind_param('i', $userId);
$stmt->execute();
$upcomingCount = (int)($stmt->get_result()->fetch_assoc()['c'] ?? 0);
$stmt->close();

$stmt = db()->prepare('SELECT COUNT(*) AS c FROM medications WHERE user_id = ? AND is_active = 1');
$stmt->bind_param('i', $userId);
$stmt->execute();
$activeMeds = (int)($stmt->get_result()->fetch_assoc()['c'] ?? 0);
$stmt->close();

$stmt = db()->prepare('SELECT COUNT(*) AS c FROM medical_records WHERE user_id = ?');
$stmt->bind_param('i', $userId);
$stmt->execute();
$docCount = (int)($stmt->get_result()->fetch_assoc()['c'] ?? 0);
$stmt->close();

$stmt = db()->prepare('SELECT COUNT(*) AS c FROM skincare_routines WHERE user_id = ?');
$stmt->bind_param('i', $userId);
$stmt->execute();
$routineCount = (int)($stmt->get_result()->fetch_assoc()['c'] ?? 0);
$stmt->close();

/* Health profile (user_profiles) */
$profile = fetch_one('SELECT * FROM user_profiles WHERE user_id = ? LIMIT 1', 'i', [$userId]);

/* 5 latest uploads across prescriptions + medical_records */
$recent = fetch_all(
    'SELECT * FROM (
        (SELECT \'prescription\' AS kind, p.id AS row_id, p.doctor_name AS label, p.status AS status,
                p.file_path AS file_path, p.original_filename AS original_filename, p.uploaded_at AS uploaded_at
           FROM prescriptions p WHERE p.user_id = ?)
        UNION ALL
        (SELECT \'record\', m.id, m.title, m.record_type, m.file_path, m.original_filename, m.uploaded_at
           FROM medical_records m WHERE m.user_id = ?)
     ) AS t
     ORDER BY t.uploaded_at DESC LIMIT 5',
    'ii', [$userId, $userId]
);

$recordTypeLabels = ['lab_result' => 'Lab result', 'report' => 'Report', 'scan' => 'Scan', 'other' => 'Other'];
$recordTypeIcons  = ['lab_result' => '🔬', 'report' => '📋', 'scan' => '🩻', 'other' => '📄'];
$statusBadges = ['pending' => 'badge badge-warning', 'approved' => 'badge badge-success', 'rejected' => 'badge badge-danger'];
$statusLabels = ['pending' => 'Pending review', 'approved' => 'Approved', 'rejected' => 'Rejected'];
?>
<div class="sidebar-wrap">
  <div class="sidebar-main">
    <div class="container">

      <div class="flex-between" style="margin: 28px 0 18px;">
        <div>
          <h1 class="section-title" style="margin-bottom: 2px;">❤️ My health overview</h1>
          <p class="muted">Welcome back, <?= e($user['full_name']) ?> — here's the state of your health file.</p>
        </div>
        <a class="btn btn-primary" href="<?= e(u('my_health/upload.php')) ?>">📤 Upload a document</a>
      </div>

      <!-- Stat cards -->
      <div class="grid grid-4">
        <div class="card"><div class="card-body">
          <div class="stat-card">
            <span class="stat-icon">📅</span>
            <div>
              <div class="stat-value"><?= (int) $upcomingCount ?></div>
              <div class="stat-label">Upcoming appointments</div>
            </div>
          </div>
        </div></div>
        <div class="card"><div class="card-body">
          <div class="stat-card">
            <span class="stat-icon">💊</span>
            <div>
              <div class="stat-value"><?= (int) $activeMeds ?></div>
              <div class="stat-label">Active medications</div>
            </div>
          </div>
        </div></div>
        <div class="card"><div class="card-body">
          <div class="stat-card">
            <span class="stat-icon">📁</span>
            <div>
              <div class="stat-value"><?= (int) $docCount ?></div>
              <div class="stat-label">Uploaded documents</div>
            </div>
          </div>
        </div></div>
        <div class="card"><div class="card-body">
          <div class="stat-card">
            <span class="stat-icon">🧴</span>
            <div>
              <div class="stat-value"><?= (int) $routineCount ?></div>
              <div class="stat-label">Skincare routines</div>
            </div>
          </div>
        </div></div>
      </div>

      <!-- Health profile -->
      <div class="card" style="margin-top: 20px;">
        <div class="card-body">
          <div class="flex-between">
            <h2 style="font-size: 1.15rem;">🩺 My health profile</h2>
            <a class="btn btn-outline btn-sm" href="<?= e(u('account/profile.php')) ?>">✏️ Edit profile</a>
          </div>
          <?php if ($profile): ?>
            <div class="grid grid-2" style="margin-top: 10px;">
              <p><strong>Blood type:</strong>
                <?= $profile['blood_type'] ? e($profile['blood_type']) : '<span class="muted">Not set</span>' ?></p>
              <p><strong>Allergies:</strong>
                <?= $profile['allergies'] ? e($profile['allergies']) : '<span class="muted">Not set</span>' ?></p>
              <p><strong>Chronic conditions:</strong>
                <?= $profile['chronic_conditions'] ? e($profile['chronic_conditions']) : '<span class="muted">Not set</span>' ?></p>
              <p><strong>Emergency contact:</strong>
                <?php if ($profile['emergency_contact_name']): ?>
                  <?= e($profile['emergency_contact_name']) ?>
                  <span class="muted"><?= $profile['emergency_contact_phone'] ? ' · ' . e($profile['emergency_contact_phone']) : '' ?></span>
                <?php else: ?>
                  <span class="muted">Not set</span>
                <?php endif; ?>
              </p>
            </div>
          <?php else: ?>
            <p class="muted" style="margin: 12px 0 0;">You haven't filled in your health profile yet. Add your blood type, allergies and emergency contact so health professionals have what they need in an emergency. <a href="<?= e(u('account/profile.php')) ?>">Complete your profile →</a></p>
          <?php endif; ?>
        </div>
      </div>

      <!-- Recent uploads -->
      <div style="margin-top: 24px;">
        <h2 class="section-title" style="font-size: 1.25rem;">📤 Recent uploads</h2>
        <p class="muted" style="margin-bottom: 12px;">Your five most recent documents across prescriptions and medical records.</p>
        <?php if (!$recent): ?>
          <div class="empty-state card">
            <p style="font-size: 2.4rem; margin-bottom: 6px;">🗂️</p>
            <h3>No uploads yet</h3>
            <p>Upload a prescription from your doctor or lab results, scans and reports to keep your health file complete.</p>
            <a class="btn btn-primary" href="<?= e(u('my_health/upload.php')) ?>">📤 Upload your first document</a>
          </div>
        <?php else: ?>
          <div class="table-wrap">
            <table class="table">
              <thead>
                <tr><th>File</th><th>Type</th><th>Status</th><th>Uploaded</th><th></th></tr>
              </thead>
              <tbody>
                <?php foreach ($recent as $row): ?>
                  <?php if ($row['kind'] === 'prescription'): $icon = '💊'; $typeName = 'Prescription'; else:
                    $typeName = $recordTypeLabels[$row['status']] ?? 'Other';
                    $icon = $recordTypeIcons[$row['status']] ?? '📄'; endif; ?>
                  <?php $viewUrl = u('download.php') . '?file=' . rawurlencode(basename((string)$row['file_path'])); ?>
                  <tr>
                    <td><strong><?= $icon ?> <?= e($row['original_filename']) ?></strong></td>
                    <td>
                      <?= e($typeName) ?>
                      <?php if ($row['kind'] === 'prescription' && $row['label']): ?>
                        <span class="muted">· Dr. <?= e($row['label']) ?></span>
                      <?php elseif ($row['kind'] !== 'prescription' && $row['label']): ?>
                        <span class="muted">· <?= e($row['label']) ?></span>
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if ($row['kind'] === 'prescription'): ?>
                        <?php $st = $row['status'] ?? 'pending'; ?>
                        <span class="<?= $statusBadges[$st] ?? 'badge badge-info' ?>"><?= e($statusLabels[$st] ?? ucfirst((string) $st)) ?></span>
                      <?php else: ?>
                        <span class="badge badge-info">Medical record</span>
                      <?php endif; ?>
                    </td>
                    <td><span class="muted"><?= e(date('d M Y, H:i', strtotime((string) $row['uploaded_at']))) ?></span></td>
                    <td style="text-align: right;"><a class="btn btn-outline btn-sm" href="<?= e($viewUrl) ?>">👁 View</a></td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </div>

      <!-- Quick actions -->
      <div style="margin: 28px 0 10px;">
        <h2 class="section-title" style="font-size: 1.25rem;">⚡ Quick actions</h2>
        <div class="grid grid-4">
          <a class="card feature-card" href="<?= e(u('my_health/upload.php')) ?>"><div class="card-body">
            <p class="feature-icon">📤</p>
            <strong>Upload documents</strong>
            <p class="muted" style="font-size: .87rem;">Add prescriptions or records to your health file</p>
          </div></a>
          <a class="card feature-card" href="<?= e(u('my_health/medication.php')) ?>"><div class="card-body">
            <p class="feature-icon">💊</p>
            <strong>Add medication</strong>
            <p class="muted" style="font-size: .87rem;">Track what you take and set reminders</p>
          </div></a>
          <a class="card feature-card" href="<?= e(u('my_health/skincare_tracker.php')) ?>"><div class="card-body">
            <p class="feature-icon">🧴</p>
            <strong>Track skincare</strong>
            <p class="muted" style="font-size: .87rem;">Build routines and keep your streak going</p>
          </div></a>
          <a class="card feature-card" href="<?= e(u('healthcare/doctor_consultation.php')) ?>"><div class="card-body">
            <p class="feature-icon">🩺</p>
            <strong>Book doctor</strong>
            <p class="muted" style="font-size: .87rem;">Find and consult a registered doctor</p>
          </div></a>
        </div>
      </div>

    </div>
  </div>
</div>
<?php require_once $ROOT . '/includes/footer.php'; ?>
