<?php
/**
 * MEDIRUSH — Secure private-document download (binary streaming, NO HTML).
 * Usage: download.php?file=<basename of an uploaded file>
 * The request must map to a medical_records or prescriptions row belonging
 * to the logged-in user (admins may fetch any).
 */
$ROOT = '.';
require_once $ROOT . '/includes/auth.php';
require_login();

$me    = current_user();
$meId  = (int)$me['id'];
$isAdmin = $me['role'] === 'admin';

/* 1. Only ever trust the basename — kills traversal like ../ and C:\ paths */
$requested = (string)($_GET['file'] ?? '');
$file = basename($requested);
if ($file === '' || $file === '.' || $file === '..' || $file !== $requested || str_contains($file, '..')) {
    http_response_code(404);
    exit;
}

/* 2. Real-path containment check inside assets/uploads */
$uploadsDir = realpath(__DIR__ . '/assets/uploads');
$fullPath   = realpath(__DIR__ . '/assets/uploads/' . $file);
if ($uploadsDir === false || $fullPath === false || strpos($fullPath, $uploadsDir . DIRECTORY_SEPARATOR) !== 0) {
    http_response_code(404);
    exit;
}

/* 3. Ownership check: the file must exist in a private table row for this user */
$relativePath = 'assets/uploads/' . $file;
$row = fetch_one(
    'SELECT original_filename, file_path FROM medical_records WHERE file_path = ? AND user_id = ?',
    'si', [$relativePath, $meId]
);
if (!$row) {
    $row = fetch_one(
        'SELECT original_filename, file_path FROM prescriptions WHERE file_path = ? AND user_id = ?',
        'si', [$relativePath, $meId]
    );
}
if (!$row) {
    /* Admins may verify any uploaded prescription file */
    if ($isAdmin) {
        $row = fetch_one('SELECT original_filename, file_path FROM prescriptions WHERE file_path = ?', 's', [$relativePath]);
    }
}
if (!$row) {
    http_response_code(404);
    exit;
}

/* Extra paranoia: DB path must match what we resolved on disk */
if (basename((string)$row['file_path']) !== $file) {
    http_response_code(404);
    exit;
}

/* 4. Stream — make sure absolutely nothing was echoed before the headers */
while (ob_get_level() > 0) {
    ob_end_clean();
}

$openFile   = @fopen($fullPath, 'rb');
if ($openFile === false) {
    http_response_code(404);
    exit;
}
$fileSize   = (int)@filesize($fullPath);
$finfo      = new finfo(FILEINFO_MIME_TYPE);
$mimeInfo   = $finfo->file($fullPath);
$mime       = is_string($mimeInfo) ? $mimeInfo : 'application/octet-stream';
if (!preg_match('#^(application/[a-z0-9.+-]+|image/(jpeg|png|webp)|text/plain)$#i', $mime)) {
    $mime = 'application/octet-stream'; // never trust a spoofed file to sniff as HTML
}

$downloadName = basename(trim((string)$row['original_filename']) !== '' ? $row['original_filename'] : $file);
$downloadName = str_replace(['"', "\r", "\n"], '', $downloadName);

header('Content-Type: ' . $mime);
header('Content-Length: ' . $fileSize);
header('Content-Disposition: attachment; filename="' . $downloadName . '"');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-store');

fpassthru($openFile);
fclose($openFile);
exit;
