<?php
/**
 * MEDIRUSH — Medicine details (public).
 */
$ROOT = '..';
$PAGE_TITLE = 'Medicine Details — MEDIRUSH';
$ACTIVE = 'pharmacy';
$SHOW_SIDEBAR = false;
require_once $ROOT . '/includes/auth.php';

/* ----------------------------- Add to cart (POST) -------------------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'add_cart') {
    if (!is_logged_in()) {
        flash('info', 'Please log in to add items to your cart.');
        redirect('login.php?next=pharmacy/medicine_details.php?id=' . (int)($_POST['product_id'] ?? 0));
    }
    verify_csrf();
    $user = current_user();
    $productId = (int)($_POST['product_id'] ?? 0);
    $quantity  = (int)($_POST['quantity'] ?? 0);
    $back      = $_POST['back'] ?? 'pharmacy/medicine_details.php?id=' . $productId;
    if (!str_starts_with($back, 'pharmacy/medicine_details.php')) {
        $back = 'pharmacy/medicine_details.php?id=' . $productId;
    }

    $product = $productId > 0
        ? fetch_one('SELECT id, stock FROM pharmacy_products WHERE id = ? LIMIT 1', 'i', [$productId])
        : null;

    if (!$product || (int)$product['stock'] <= 0) {
        flash('error', 'That product is unavailable.');
        redirect($back);
    }
    $maxQty = min(10, (int)$product['stock']);
    if ($quantity < 1 || $quantity > $maxQty) {
        flash('error', "Quantity must be between 1 and {$maxQty}.");
        redirect($back);
    }

    $cartId = get_or_create_cart((int)$user['id']);
    $existing = fetch_one(
        'SELECT id, quantity FROM cart_items WHERE cart_id = ? AND product_type = ? AND product_id = ? LIMIT 1',
        'isi',
        [$cartId, 'pharmacy', $productId]
    );
    if ($existing) {
        $newQty = min((int)$existing['quantity'] + $quantity, (int)$product['stock']);
        $stmt = db()->prepare('UPDATE cart_items SET quantity = ? WHERE id = ?');
        $stmt->bind_param('ii', $newQty, $existing['id']);
        $stmt->execute();
        $stmt->close();
    } else {
        $stmt = db()->prepare('INSERT INTO cart_items (cart_id, product_type, product_id, quantity) VALUES (?, ?, ?, ?)');
        $stmt->bind_param('isii', $cartId, $type, $productId, $quantity);
        $type = 'pharmacy';
        $stmt->execute();
        $stmt->close();
    }
    flash('success', 'Added to cart 🛒');
    redirect($back);
}

/* ---------------------------- Fetch the product ---------------------------- */
$id = (int)($_GET['id'] ?? 0);
$product = $id > 0
    ? fetch_one('SELECT id, name, category, description, price, stock, image, requires_prescription FROM pharmacy_products WHERE id = ? LIMIT 1', 'i', [$id])
    : null;

$CATEGORIES = [
    'pain_relief'  => 'Pain Relief',
    'antibiotics'  => 'Antibiotics',
    'vitamins'     => 'Vitamins',
    'first_aid'    => 'First Aid',
    'chronic_care' => 'Chronic Care',
    'other'        => 'Other',
];

$related = $product
    ? fetch_all(
        'SELECT id, name, price, image FROM pharmacy_products WHERE category = ? AND id <> ? ORDER BY RAND() LIMIT 3',
        'si',
        [$product['category'], (int)$product['id']]
      )
    : [];

/* Prescription verification gate */
$RxStripVisible = false;
if ($product && (int)$product['requires_prescription'] === 1 && (int)$product['stock'] > 0) {
    $user = current_user();
    $hasApproved = false;
    if ($user) {
        $hasApproved = (bool)fetch_one(
            "SELECT id FROM prescriptions WHERE user_id = ? AND status = 'approved' LIMIT 1",
            'i',
            [(int)$user['id']]
        );
    }
    $RxStripVisible = !$hasApproved;
}

require_once $ROOT . '/includes/header.php';
?>

<section class="section">
  <div class="container">
    <?php if (!$product): ?>
      <div class="empty-state">
        <div class="empty-icon">💊</div>
        <h3>Medicine not found</h3>
        <p>The product you are looking for does not exist or is no longer listed.</p>
        <a class="btn btn-primary" href="<?= u('pharmacy/pharmacy.php') ?>">← Back to pharmacy</a>
      </div>
    <?php else: ?>
      <?php $stock = (int)$product['stock']; ?>
      <p><a href="<?= u('pharmacy/pharmacy.php') ?>">← Back to pharmacy</a></p>

      <?php if ($RxStripVisible): ?>
        <div class="badge badge-warning rx-strip">⚠️ A verified prescription is required before dispensing. Upload yours in <a href="<?= u('my_health/upload.php') ?>">My Health → Uploads</a>.</div>
      <?php endif; ?>

      <div class="grid grid-2">
        <div class="card">
          <div class="card-body detail-visual">
            <div class="detail-emoji"><?= e(icon($product['image'], '💊')) ?></div>
            <span class="badge badge-info"><?= e($CATEGORIES[$product['category']] ?? 'Other') ?></span>
            <?php if ((int)$product['requires_prescription'] === 1): ?>
              <p><small class="badge badge-warning">Rx required — prescription medicine</small></p>
            <?php endif; ?>
          </div>
        </div>

        <div class="card">
          <div class="card-body">
            <h1 class="product-name"><?= e($product['name']) ?></h1>
            <p class="product-price"><?= money($product['price']) ?></p>
            <?php if ($stock > 0): ?>
              <span class="badge <?= $stock < 8 ? 'badge-warning' : 'badge-success' ?>"><?= $stock < 8 ? 'Low stock — order soon' : 'In stock' ?></span>
            <?php else: ?>
              <span class="badge badge-danger">Out of stock</span>
            <?php endif; ?>

            <p class="product-desc"><?= e($product['description'] ?: 'No description available for this product.') ?></p>

            <?php if ($stock > 0): ?>
              <?php if (is_logged_in()): ?>
                <form method="post" action="<?= u('pharmacy/medicine_details.php') ?>" class="add-form">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="add_cart">
                  <input type="hidden" name="product_id" value="<?= (int)$product['id'] ?>">
                  <input type="hidden" name="back" value="pharmacy/medicine_details.php?id=<?= (int)$product['id'] ?>">
                  <label class="form-label" for="qty">Quantity</label>
                  <input type="number" id="qty" name="quantity" class="form-input qty-input" value="1" min="1" max="<?= min(10, $stock) ?>">
                  <button type="submit" class="btn btn-primary btn-block">Add to cart 🛒</button>
                </form>
              <?php else: ?>
                <a class="btn btn-primary btn-block" href="<?= u('login.php?next=pharmacy/medicine_details.php?id=' . (int)$product['id']) ?>">Log in to order</a>
              <?php endif; ?>
            <?php endif; ?>

            <div class="notice">
              ℹ️ This information is educational — confirm dosage with a pharmacist or doctor.
            </div>
          </div>
        </div>
      </div>

      <?php if ($related): ?>
        <h2 class="section-title">Related products</h2>
        <div class="grid grid-3">
          <?php foreach ($related as $r): ?>
            <div class="product-card">
              <div class="product-image"><?= e(icon($r['image'], '💊')) ?></div>
              <div class="card-body">
                <h3 class="product-name"><?= e($r['name']) ?></h3>
                <p class="product-price"><?= money($r['price']) ?></p>
                <a class="btn btn-outline btn-sm" href="<?= u('pharmacy/medicine_details.php?id=' . (int)$r['id']) ?>">View details</a>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    <?php endif; ?>
  </div>
</section>

<?php require_once $ROOT . '/includes/footer.php'; ?>
