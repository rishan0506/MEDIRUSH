<?php
/**
 * MEDIRUSH — beauty/skincare_assistant.php
 * Public demo AI skin assistant with admin handover/escalation option.
 */
declare(strict_types=1);

$ROOT = '..';
$PAGE_TITLE = 'AI Skin Assistant — MEDIRUSH';
$ACTIVE = 'beauty';

require_once $ROOT . '/includes/auth.php';
require_once $ROOT . '/includes/header.php';

// Handle Admin Support Handover submission
$handoverSuccess = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'submit_ai_handover') {
    verify_csrf();
    if (!is_logged_in()) {
        flash('info', 'Please log in to contact the admin team.');
        redirect('login.php?next=beauty/skincare_assistant.php');
    }
    $msg = trim((string)($_POST['support_message'] ?? ''));
    $hotline = trim((string)($_POST['customer_hotline'] ?? ''));
    
    if ($msg !== '' && $hotline !== '') {
        $userId = (int)current_user()['id'];
        $stmt = db()->prepare("INSERT INTO admin_support_requests (user_id, message, hotline) VALUES (?, ?, ?)");
        $stmt->bind_param('iss', $userId, $msg, $hotline);
        $stmt->execute();
        $stmt->close();
        
        add_notification($userId, 'support', 'Admin support requested', 'Your message and hotline have been sent to our admin team.');
        $handoverSuccess = true;
    } else {
        flash('error', 'Please fill in both your message and contact hotline number.');
    }
}

// Product catalogue for the demo assistant's product-matching buttons.
$rows = fetch_all(
    'SELECT id, name, skin_type, category, price, image FROM skincare_products ORDER BY id ASC'
);
$productsJson = json_encode($rows, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG);
?>

<section class="section">
  <h1 class="section-title">🤖 AI Skin Assistant</h1>
  <p class="section-subtitle">Instant, rule-based skincare guidance and product matching — right in your browser.</p>

  <div class="notice mb-3">
    🤖 DEMO AI assistant — rule-based. Add SKINCARE_AI_API_KEY in includes/config.php to enable a live model.
  </div>

  <?php if ($handoverSuccess): ?>
    <div class="alert alert-success">✅ Your message and hotline number have been successfully sent to the admin team! An administrator will contact you soon.</div>
  <?php endif; ?>

  <div class="card card-body mb-4">
    <div class="chat-box" id="assistantChat">
      <div class="chat-msg bot">
        <p>
          Hi! I'm the MEDIRUSH skin assistant 🤖 (demo). I can suggest routines and matching products.
          <strong>First — what's your skin type?</strong> Say <strong>oily</strong>, <strong>dry</strong>,
          <strong>combination</strong> or <strong>sensitive</strong>.
        </p>
      </div>
    </div>

    <form id="assistantForm" class="chat-input-row mt-3">
      <input type="text" id="assistantInput" class="form-input" autocomplete="off"
             placeholder="e.g. “I have oily skin and breakouts”…">
      <button class="btn btn-primary" type="submit">Send ➤</button>
    </form>
    <p class="form-help">Demo assistant — general tips only, not medical advice.</p>
  </div>

  <!-- Number 3 Feature: Not satisfied with AI -> Contact Admin -->
  <div class="card border-warning">
    <div class="card-body">
      <h3 class="section-title" style="font-size: 1.15rem;">💬 Not satisfied with the AI assistant?</h3>
      <p class="muted">If the AI response didn't help you, you can escalate your query directly to our human admin team. Leave a message and your hotline/phone number below, and an administrator will reach out to you.</p>

      <?php if (!is_logged_in()): ?>
        <p><a href="<?= u('login.php?next=beauty/skincare_assistant.php') ?>" class="btn btn-outline btn-sm">Log in to contact admin</a></p>
      <?php else: ?>
        <form method="post" action="<?= u('beauty/skincare_assistant.php') ?>">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="submit_ai_handover">
          <div class="form-group">
            <label class="form-label" for="support_message">Describe what you were looking for or why you're unsatisfied:</label>
            <textarea id="support_message" name="support_message" class="form-textarea" rows="3" required placeholder="E.g., The AI recommended products that didn't match my sensitive skin condition..."></textarea>
          </div>
          <div class="form-group">
            <label class="form-label" for="customer_hotline">Your Phone / Hotline Number:</label>
            <input type="text" id="customer_hotline" name="customer_hotline" class="form-input" required placeholder="E.g., 0825551234">
          </div>
          <button type="submit" class="btn btn-warning btn-sm">Submit to Human Admin</button>
        </form>
      <?php endif; ?>
    </div>
  </div>
</section>

<script>window.SKIN_PRODUCTS = <?= $productsJson ?>;</script>
<script>
(function () {
  'use strict';
  var box    = document.getElementById('assistantChat');
  var form   = document.getElementById('assistantForm');
  var input  = document.getElementById('assistantInput');
  var products = window.SKIN_PRODUCTS || [];
  var skinType = null;

  function scroll() { box.scrollTop = box.scrollHeight; }

  function addMsg(text, who) {
    var div = document.createElement('div');
    div.className = 'chat-msg ' + who;
    var p = document.createElement('p');
    p.textContent = text;
    div.appendChild(p);
    box.appendChild(div);
    scroll();
    return div;
  }

  function shopButtons(list) {
    var wrap = document.createElement('div');
    list.forEach(function (p) {
      var a = document.createElement('a');
      a.className = 'btn btn-outline btn-sm';
      a.href = '../beauty/beauty_details.php?id=' + parseInt(p.id, 10);
      a.textContent = '🛒 Shop: ' + p.name;
      wrap.appendChild(a);
    });
    box.appendChild(wrap);
    scroll();
  }

  function matchesFor(type) {
    return products.filter(function (p) {
      return p.skin_type === type || p.skin_type === 'all';
    }).slice(0, 2);
  }

  function detectSkin(t) {
    if (/oily|greas|shiny|shine/.test(t)) return 'oily';
    if (/combinat|t-zone|t zone/.test(t)) return 'combination';
    if (/sensitiv|reactive|react/.test(t)) return 'sensitive';
    if (/dry|dehydr/.test(t)) return 'dry';
    return null;
  }

  function detectTopic(t) {
    if (/acne|pimple|breakout/.test(t)) return 'acne';
    if (/dry|dehydr/.test(t)) return 'dry';
    if (/pigment|dark spot|dark spots/.test(t)) return 'pigment';
    if (/sun|spf|uv/.test(t)) return 'sun';
    if (/sensitive|red|irritat/.test(t)) return 'sensitive';
    return null;
  }

  function adviceFor(topic) {
    switch (topic) {
      case 'acne': return 'For breakouts: use a salicylic-acid (BHA) cleanser 2× a day, add a BHA toner 2–3 evenings a week, and keep every product non-comedogenic.';
      case 'dry': return 'For dry skin: a hyaluronic-acid serum on damp skin, then a ceramide moisturizer to seal it in.';
      case 'pigment': return 'For dark spots: vitamin C serum in the morning plus strict daily SPF 50.';
      case 'sun': return 'Daily broad-spectrum SPF 50 is non-negotiable — reapply every 2 hours outdoors.';
      case 'sensitive': return 'For sensitive skin: fragrance-free products only, centella (cica) cream to calm redness.';
      default: return 'Tell me a bit more — I cover acne, dryness, dark spots, sunscreen and redness.';
    }
  }

  function botRespond(text, matches) {
    var typing = document.createElement('div');
    typing.className = 'chat-msg bot';
    typing.textContent = '…';
    box.appendChild(typing);
    scroll();
    setTimeout(function () {
      typing.remove();
      addMsg(text, 'bot');
      if (matches && matches.length) shopButtons(matches);
    }, 400);
  }

  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var userText = input.value.trim();
      if (userText === '') return;
      input.value = '';
      addMsg(userText, 'user');

      if (skinType === null) {
        var skin = detectSkin(userText.toLowerCase());
        if (skin) {
          skinType = skin;
          var topic = detectTopic(userText.toLowerCase());
          botRespond('Got it — ' + skin + ' skin. ' + (topic ? adviceFor(topic) : 'What would you like help with?'), matchesFor(skin));
        } else {
          botRespond('First, what’s your skin type — oily, dry, combination or sensitive?', null);
        }
        return;
      }
      var t = detectTopic(userText.toLowerCase());
      botRespond(adviceFor(t) + ' Here are two picks that suit ' + skinType + ' skin:', matchesFor(skinType));
    });
  }
})();
</script>

<?php require_once $ROOT . '/includes/footer.php'; ?>