<?php
/**
 * MEDIRUSH — logout.php — destroys session and redirects home.
 */
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';
logout_current_user();
session_start();
flash('success', 'You have been logged out. See you soon! 👋');
redirect('index.php');
