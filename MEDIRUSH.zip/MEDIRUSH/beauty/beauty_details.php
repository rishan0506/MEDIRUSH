<?php
/**
 * MEDIRUSH — beauty/beauty_details.php
 * Public skincare product details with add-to-cart and related products.
 */
declare(strict_types=1);

$ROOT = '..';
$PAGE_TITLE = 'Product details — MEDIRUSH';
$ACTIVE = 'beauty';

// Page POSTs private data (add to cart), so auth + session load FIRST.
require_once $ROOT . '/includes/auth.php';

$pid = (int)($_GET['id'] ?? 0);

/* ------------------------- Add-to-cart POST handler ------------------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'add_to_cart') {
    verify_csrf();
    require_login('beauty/beauty_details.php?id=' . $pid);

    $back = 'beauty/beauty_details.php?id=' . $pid;

    if ($pid < 1) {
        flash('error', 'Invalid product.');
        redirect('beauty/beauty.php');
    }
    $qty = (int)($_POST['quantity'] ?? 1);
    if ($qty < 1 || $qty > 99) {
        flash('error', 'Quantity must be between 1 and 99.');
        redirect($back);
    }

    $product = fetch_one(
        'SELECT id, name, stock FROM skincare_products WHERE id = ? LIMIT 1',
        'i', [$pid]
    );
    if (!$product) {
        flash('error', 'That product could not be found.');
        redirect('beauty/beauty.php');
    }
    if ((int)$product['stock'] < 1) {
        flash('error', '“' . $product['name'] . '” is out of stock right now.');
        redirect($back);
    }
    if ($qty > (int)$product['stock']) {
        flash('error', 'Only ' . (int)$product['stock'] . ' unit(s) of “' . $product['name'] . '” left in stock.');
        redirect($back);
    }

    $cartId = get_or_create_cart((int)$_SESSION['user_id']);
    $ptype = 'skincare';

    $existing = fetch_one(
        'SELECT id, quantity FROM cart_items WHERE cart_id = ? AND product_type = ? AND product_id = ? LIMIT 1',
        'isi', [$cartId, $ptype, $pid]
    );
    if ($existing) {
        $newQty = (int)$existing['quantity'] + $qty;
        if ($newQty > (int)$product['stock']) $newQty = (int)$product['stock'];
        $stmt = db()->prepare('UPDATE cart_items SET quantity = ? WHERE id = ?');
        $stmt->bind_param('ii', $newQty, $existing['id']);
        $stmt->execute();
        $stmt->close();
    } else {
        $stmt = db()->prepare('INSERT INTO cart_items (cart_id, product_type, product_id, quantity) VALUES (?, ?, ?, ?)');
        $stmt->bind_param('isii', $cartId, $ptype, $pid, $qty);
        $stmt->execute();
        $stmt->close();
    }

    flash('success', '“' . $product['name'] . '” added to your cart. 🛒');
    redirect($back);
}

/* ------------------------------- Fetch product ------------------------------ */
$skinLabels = ['all' => 'All skin types', 'oily' => 'Oily', 'dry' => 'Dry', 'combination' => 'Combination', 'sensitive' => 'Sensitive'];
$catLabels  = ['cleanser' => 'Cleanser', 'moisturizer' => 'Moisturizer', 'serum' => 'Serum', 'sunscreen' => 'Sunscreen', 'toner' => 'Toner', 'mask' => 'Mask', 'other' => 'Other'];

$product = $pid > 0
    ? fetch_one('SELECT id, name, category, skin_type, description, price, stock, image FROM skincare_products WHERE id = ? LIMIT 1', 'i', [$pid])
    : null;

$related = $product
    ? fetch_all(
        'SELECT id, name, price, stock, image FROM skincare_products WHERE category = ? AND id <> ? ORDER BY id LIMIT 3',
        'si', [$product['category'], $pid]
      )
    : [];

if ($product) {
    $PAGE_TITLE = $product['name'] . ' — MEDIRUSH';
}

require_once $ROOT . '/includes/header.php';
?>

<section class="section">
  <?php if (!$product): ?>
    <div class="empty-state">
      <div class="empty-icon">🔍</div>
      <h3>Product not found</h3>
      <p>This product may have been removed or the link is incorrect.</p>
      <a class="btn btn-primary" href="<?= u('beauty/beauty.php') ?>">Back to the marketplace</a>
    </div>
  <?php else: ?>
    <div class="grid grid-2">
      <div class="card card-body">
        <div class="product-image"><?= e(icon($product['image'], '🧴')) ?></div>
        <p>
          <span class="badge"><?= e($catLabels[$product['category']] ?? ucfirst((string)$product['category'])) ?></span>
          <span class="badge badge-info"><?= e($skinLabels[$product['skin_type']] ?? ucfirst((string)$product['skin_type'])) ?></span>
        </p>
      </div>

      <div class="card card-body">
        <h1><?= e($product['name']) ?></h1>
        <p class="product-price"><?= money($product['price']) ?></p>
        <p>
          <?php if ((int)$product['stock'] > 0): ?>
            <span class="badge badge-success">In stock (<?= (int)$product['stock'] ?>)</span>
          <?php else: ?>
            <span class="badge badge-danger">Out of stock</span>
          <?php endif; ?>
        </p>
        <p><?= nl2br(e((string)$product['description'])) ?></p>

        <?php if ((int)$product['stock'] > 0): ?>
          <?php $maxQty = min((int)$product['stock'], 10); ?>
          <form method="post" action="<?= u('beauty/beauty_details.php?id=' . (int)$product['id']) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="add_to_cart">
            <div class="form-group">
              <label class="form-label" for="qty">Quantity</label>
              <input class="form-input" type="number" id="qty" name="quantity" value="1" min="1" max="<?= $maxQty ?>">
            </div>
            <button class="btn btn-primary btn-block" type="submit">🛒 Add to cart</button>
          </form>
        <?php else: ?>
          <button class="btn btn-outline btn-block" disabled>Out of stock</button>
        <?php endif; ?>

        <div class="notice">
          ⚠️ Patch test new products — apply a small amount on your inner arm for 24 hours, and stop use if irritation occurs. Not medical advice.
        </div>
      </div>
    </div>

    <?php if ($related): ?>
      <h2 class="section-title">More <?= e(mb_strtolower($catLabels[$product['category']] ?? (string)$product['category'])) ?> picks</h2>
      <div class="grid grid-3">
        <?php foreach ($related as $r): ?>
          <div class="product-card">
            <a class="product-image" href="<?= u('beauty/beauty_details.php?id=' . (int)$r['id']) ?>"><?= e(icon($r['image'], '🧴')) ?></a>
            <div class="card-body">
              <h3 class="product-name"><a href="<?= u('beauty/beauty_details.php?id=' . (int)$r['id']) ?>"><?= e($r['name']) ?></a></h3>
              <p class="product-price"><?= money($r['price']) ?></p>
              <?php if ((int)$r['stock'] > 0): ?><span class="badge badge-success">In stock</span>
              <?php else: ?><span class="badge badge-danger">Out of stock</span><?php endif; ?>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  <?php endif; ?>
</section>

<?php require_once $ROOT . '/includes/footer.php'; ?>
