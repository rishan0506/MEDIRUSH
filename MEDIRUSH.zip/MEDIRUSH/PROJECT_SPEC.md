# MEDIRUSH — Shared Development Specification (READ THIS FIRST)

This document defines the conventions every page of the MEDIRUSH website MUST follow
so that all files work together. Follow it exactly. Do not invent alternative helpers,
class names, or database column names.

## 1. Standard page template (EVERY page)

Every PHP page uses this exact preamble, immediately after the opening `<?php`:

```php
<?php
$ROOT = '..';                 // '.' for pages in the MEDIRUSH root folder, '..' for pages in subfolders
$PAGE_TITLE = 'Page Title';   // browser tab title
$ACTIVE = 'pharmacy';         // nav section key: home|healthcare|pharmacy|beauty|my_health|dashboard|account|admin
$SHOW_SIDEBAR = false;        // true only on dashboard/authenticated management pages (optional)
require_once $ROOT . '/includes/auth.php'; // ONLY on authenticated pages (dashboard, cart, checkout, my_health, account, upload, admin). Public pages (index, healthcare, pharmacy, beauty, medicine/beauty details, anatomy, emergency_locator, login, register) do NOT require auth unless they POST private data — cart/checkout DO require auth.
require_once $ROOT . '/includes/header.php';
?>
<!-- page HTML -->
<?php require_once $ROOT . '/includes/footer.php'; ?>
```

`auth.php` automatically includes `db_connect.php` and `includes/functions.php`.
`header.php` automatically includes `css/style.css`, `css/responsive.css`, `js/theme.js`, `js/script.js`
(so individual pages must NOT add their own <link>/<script> tags for those; add extra
page-specific CSS inline is NOT allowed, keep everything in style.css).

## 2. Available helpers (defined in includes/functions.php)

- `e($value)` — htmlspecialchars escape. Use for ALL output of data.
- `u($path)` — returns `$ROOT . '/' . $path`; use for EVERY internal link/asset/form action, e.g. `u('pharmacy/pharmacy.php')`, `u('assets/uploads/1_rx_abc.jpg')`.
- `money($amount)` — formats as `R 1 250.00`.
- `csrf_token()`, `csrf_field()` (echoes a hidden input), `verify_csrf()` (call first in every POST handler; dies with error if invalid).
- `is_logged_in()`, `current_user()` (returns assoc array of the logged-in user row, or null).
- `require_role('admin')` — for admin-only pages.
- `flash($type, $message)` / `display_flash()` — one-shot success/error banners. `display_flash()` is already called inside `header.php` right after `<main>` opens — pages must NOT call it themselves.
- `redirect($path)` — `header('Location: ' . u($path)); exit;`
- `db()` — returns the shared `mysqli` connection. All queries use it with prepared statements.
- `notifications_count($userId)` — unread count for the header bell (only call when logged in).
- `add_notification($userId, $type, $title, $message)` — insert a notification.
- `record_exists($table, $whereSql, $params, $types)` — helper.
- `url_for_page($productType)` — returns correct details page: `pharmacy/medicine_details.php` or `beauty/beauty_details.php`.

## 3. Design system / CSS class conventions (css/style.css)

- Colors: CSS variables on `:root` (light) and `[data-theme="dark"]` overrides handled by js/theme.js — do NOT hardcode colors, use `var(--primary)`, `var(--bg)`, `var(--card-bg)`, `var(--text)`, `var(--muted)`, `var(--danger)`, `var(--success)`, `var(--warning)`.
- Layout: `.container` (max-width 1100px centered), `.container-wide` (1300px).
- Cards: `.card`, `.card-body`. Grids: `.grid` + `.grid-2 / .grid-3 / .grid-4`.
- Buttons: `.btn`, `.btn-primary`, `.btn-outline`, `.btn-danger`, `.btn-sm`, `.btn-block`.
- Forms: `.form-group`, `.form-label`, `.form-input`, `.form-select`, `.form-textarea`, `.form-help`.
- Hero: `.hero`, `.hero-content`. Sections: `.section`, `.section-title`, `.section-subtitle`.
- Badges/status: `.badge`, `.badge-success`, `.badge-warning`, `.badge-danger`, `.badge-info`.
- Tables: `.table-wrap` > `table.table` with `thead`, `tbody`, `tr`, `td`, `th`.
- Alerts (flash): `.alert`, `.alert-success`, `.alert-error`, `.alert-info` (rendered by display_flash()).
- Product tiles: `.product-card`, .product-image (emoji), .product name/price/badge) — grid listing cards with an emoji rendered large in a soft box + name, price, "Add to Cart" button and "View Details" link.
- Product cards: `.product-card`, `.product-image` (emoji large inside tinted box), `.product-name`, `.product-price`, `.product-desc`.
- Stat tiles: `.stat-card`, `.stat-icon`, `.stat-value`, `.stat-label`.
- Sidebar layout: `.dash-layout` (flex, sidebar + main), `.sidebar` with `.side-link` + `.side-link.active`.
- Timeline/list rows for reminders & trackers: `.list-row`.
- Chat (assistant/consultation): `.chat-box`, `.chat-msg`, `.chat-msg.user`, `.chat-msg.bot`.
- Tabs: `.tabs` with `.tab-btn.active`.
- Empty states: `.empty-state` (icon + text + optional action btn).
- Auth pages: `.auth-wrap`, `.auth-card` centered card.
- Nav is built by header.php with classes: `.header`, `.nav`, `.nav-links`, `.nav-link`, `.nav-cta`, `.theme-toggle`, `.btn-bell` with `.bell-badge`.

## 4. Database (db_connect.php / database.sql) — EXACT table & column names

Connection: localhost / user root / empty password / database **medirush** (mysqli, utf8mb4, throws exceptions).

- `users` (id, full_name, email UNIQUE, password_hash, phone, role ENUM('user','admin') 'user', created_at)
- `user_profiles` (id, user_id UNIQUE FK, address, date_of_birth, gender ENUM('male','female','other') 'other', blood_type, allergies, chronic_conditions, emergency_contact_name, emergency_contact_phone, profile_image, created_at)
- `medical_records` (id, user_id FK, title, record_type ENUM('lab_result','report','scan','other'), file_path, original_filename, notes, uploaded_at)
- `prescriptions` (id, user_id FK, doctor_name, file_path, original_filename, status ENUM('pending','approved','rejected') 'pending', admin_note, uploaded_at, verified_at NULL)
- `pharmacy_products` (id, name, category ENUM('pain_relief','antibiotics','vitamins','first_aid','chronic_care','other'), description, price DECIMAL(10,2), stock INT, image VARCHAR(50) STORES AN EMOJI e.g '💊', requires_prescription TINYINT(1))
- `skincare_products` (id, name, category ENUM('cleanser','moisturizer','serum','sunscreen','toner','mask','other'), skin_type VARCHAR(20) e.g 'all|oily|dry|combination|sensitive', description, price, stock, image emoji, created_at)
- `carts` (id, user_id UNIQUE FK, created_at)
- `cart_items` (id, cart_id FK, product_type ENUM('pharmacy','skincare'), product_id, quantity) — the user's cart = the row in `carts` for that user.
- `orders` (id, user_id, order_number UNIQUE e.g 'MD-Y-m-d-RAND', total DECIMAL(10,2), status ENUM('pending','processing','shipped','delivered','cancelled') 'pending', payment_method ENUM('demo_card','demo_ewallet','cash_on_delivery') 'cash_on_delivery', delivery_address, created_at)
- `order_items` (id, order_id FK, product_type ENUM('pharmacy','skincare'), product_id, product_name, quantity, unit_price DECIMAL(10,2))
- `doctors` (id, name, specialization, bio, consultation_fee DECIMAL(10,2), image emoji e.g '🩺', contact_email, contact_phone, available_days VARCHAR(60) e.g 'Mon, Wed, Fri', available_from TIME, available_to TIME, video_enabled TINYINT(1))
- `appointments` (id, user_id FK, doctor_id FK, appointment_date DATE, appointment_time TIME, mode ENUM('in_person','video','phone'), status ENUM('scheduled','completed','cancelled') 'scheduled', notes, created_at)
- `medications` (id, user_id FK, medicine_name, dosage, frequency, start_date DATE, end_date DATE NULL, instructions, is_active TINYINT(1) DEFAULT 1, created_at)
- `medication_reminders` (id, medication_id FK, user_id FK, reminder_time TIME, is_active TINYINT(1) DEFAULT 1)
- `skincare_routines` (id, user_id FK, name, skin_type VARCHAR(20), morning_routine TEXT, evening_routine TEXT, notes, created_at)
- `skincare_logs` (id, user_id FK, routine_id FK, log_date DATE, completed TINYINT(1), notes, UNIQUE KEY (routine_id, log_date))
- `healthcare_facilities` (id, name, type ENUM('hospital','clinic','pharmacy','laboratory'), address, city, phone, latitude, longitude, is_emergency TINYINT(1)) — used by emergency_locator page as demonstration data; Google Maps API key is optional config (see §6).
- `notifications` (id, user_id FK, type, title, message, is_read TINYINT(1) DEFAULT 0, created_at)
- `messages` (id, user_id FK, doctor_id NULL, sender ENUM('user','pro') 'user', body, created_at) — used by skincare_consultation / doctor chat demo threads.

Always: JOIN with FK columns; PRAGMATIC chosen: `ON DELETE CASCADE` for dependent rows, and NEVER query another user's rows (every query on private tables includes `user_id = ?`).

## 5. Security rules (mandatory)

1. Every POST handler: `verify_csrf()` FIRST, then server-side validation of every field (`trim`, length, type, enum whitelists, FILTER_VALIDATE_EMAIL, is_numeric).
2. Prepared statements ONLY, even for "trusted" values.
3. Passwords: `password_hash($pw, PASSWORD_DEFAULT)` on register, `password_verify()` + `password_needs_rehash` behaviour handled in auth flow.
4. Auth-gated pages: dashboard.php, cart, checkout, everything in `my_health/`, everything in `account/` (orders, appointments, profile, settings), medication, uploads, admin. Public (no login): index, healthcare, anatomy, doctor_consultation (viewing doctors), pharmacy, medicine/beauty details, beauty, emergency_locator. cart/checkout/uplód/my_health/account pages call `require_login()` which redirects to login.
5. Ownership: any SELECT/UPDATE/DELETE on private data MUST include `AND user_id = ?` with the session user; 404 (empty-state / redirect) if nothing comes back rather than leaking existence.
6. Uploads (upload_process.php): allow only pdf/jpg/jpeg/png/webp; verify extension whitelist AND finfo MIME whitelist; cap size at 5MB (UPLOAD_MAX_BYTES = 5242880); rename to `{$userId}_{$type}_' . bin2hex(random_bytes(8)) . '.' . $ext;` store under `assets/uploads/` protected by `.htaccess` ("Deny from all") and served ONLY through `download.php?file=...` which checks the DB row belongs to the logged-in user. Never trust the original filename for the stored name; keep it in `original_filename`.
7. Admin pages/actions: guard with `require_role('admin')`.
8. Never echo db errors verbatim to users; flash a generic error and log with `error_log`.

## 6. External APIs — structure only, clearly labelled

`includes/config.php` defines:
```php
define('GOOGLE_MAPS_API_KEY', '');          // paste key to enable live maps on emergency_locator
define('SKINCARE_AI_API_KEY', '');          // pasted key enables live AI on skincare_assistant
define('PAYMENT_GATEWAY_API_KEY', '');      // placeholder: checkout uses DEMO payment modes unless configured
define('VIDEO_CONSULT_API_KEY', '');        // placeholder for doctor video rooms
```
- `header.php` already prints `<script>window.MEDIRUSH_CONFIG = { googleMapsKey: '...', skincareAiKey: '...' };</script>` (server-side injection — NEVER hardcode keys in .js files; reference `window.MEDIRUSH_CONFIG` only).
- Pages must check the key and fall back to a clearly-labelled DEMO mode ("🔑 Demo mode — add API key in includes/config.php") when keys are empty. NEVER fake a working external call.
- Payments: checkout has clearly-labelled demo payment options (demo card / demo wallet / cash on delivery). No real gateway calls.
- AI skincare assistant: rule-based demo that matches skin type & symptoms keywords; if `SKINCARE_AI_API_KEY` set AND `curl` available, structure a clearly-commented live-API call block that is skipped in demo mode.

## 7. Navigation (header.php, already built)

Top nav links (all via u()): Home index.php | Healthcare healthcare/healthcare.php | Pharmacy pharmacy/pharmacy.php | Beauty beauty/beauty.php | My Health my_health/my_health.php (login required) | Dashboard dashboard.php (login) | theme toggle 🌙/☀️ | notifications bell (login) | user chip dropdown (My Profile account/profile.php, Orders account/orders.php, Appointments account/appointments.php, Settings account/settings.php, Profile) or Login/Register buttons for guests.
Blog section not required — do NOT invent it.

## 8. Sidebar pages

Pages that set `$SHOW_SIDEBAR = true`: dashboard.php, my_health/my_health.php, my_health/medication.php, my_health/skincare_tracker.php, my_health/upload.php, account/* . Sidebar links: Dashboard (dashboard.php), My Health (my_health/my_health.php), Medications (my_health/medication.php), Uploads (my_health/upload.php), Skincare Tracker (my_health/skincare_tracker.php), Appointments (account/appointments.php), Orders (account/orders.php), Profile (account/profile.php), Settings (account/settings.php). All via u().

## 9. About MEDIRUSH (for consistent copy)

MEDIRUSH is an all-in-one healthcare platform: a medical hub (interactive anatomy, doctor directory & consultations, emergency facility finder), an online pharmacy (prescription-aware ordering), a skincare & beauty marketplace (products, consultant chat, AI skin assistant demo), and personal health management (medical record uploads with owner-only access, medication reminders, skincare routine tracker). Tagline: "Your health. Your beauty. One platform." Currency: Rand (ZAR). Tone: modern, friendly, professional.

## 10. File map (who owns which file!)

- ROOT: index.php, login.php, register.php, dashboard.php, logout.php, admin.php, db_connect.php, check_db.php
- includes/: db_connect.php, auth.php, functions.php, config.php, header.php, footer.php, sidebar.php
- css/: style.css, responsive.css
- js/: script.js, theme.js, upload.js
- healthcare/: healthcare.php, anatomy.php, doctor_consultation.php, emergency_locator.php
- pharmacy/: pharmacy.php, medicine_details.php, cart.php, checkout.php
- beauty/: beauty.php, beauty_details.php, skincare_consultation.php, skincare_assistant.php
- my_health/: my_health.php, upload.php, upload_process.php, medication.php, skincare_tracker.php
- account/: profile.php, settings.php, orders.php, appointments.php
- assets/uploads/: .htaccess (Deny), gitkeep
- README.txt, database.sql
