<?php
/**
 * MEDIRUSH — Pharmacy store (public).
 */
$ROOT = '..';
$PAGE_TITLE = 'Pharmacy — MEDIRUSH';
$ACTIVE = 'pharmacy';
$SHOW_SIDEBAR = false;
require_once $ROOT . '/includes/auth.php';

/* -------------------------------- Categories ------------------------------- */
$CATEGORIES = [
    'pain_relief'  => 'Pain Relief',
    'antibiotics'  => 'Antibiotics',
    'vitamins'     => 'Vitamins',
    'first_aid'    => 'First Aid',
    'chronic_care' => 'Chronic Care',
    'other'        => 'Other',
];

/* ----------------------------- Add to cart (POST) -------------------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'add_cart') {
    // Guests: log in first, then come straight back here.
    if (!is_logged_in()) {
        flash('info', 'Please log in to add items to your cart.');
        redirect('login.php?next=pharmacy/pharmacy.php');
    }
    verify_csrf();
    $user = current_user();
    $productId = (int)($_POST['product_id'] ?? 0);
    $quantity  = (int)($_POST['quantity'] ?? 0);
    $back      = $_POST['back'] ?? 'pharmacy/pharmacy.php';
    $back      = str_starts_with($back, 'pharmacy/pharmacy.php') ? $back : 'pharmacy/pharmacy.php';

    $product = $productId > 0
        ? fetch_one('SELECT id, stock FROM pharmacy_products WHERE id = ? LIMIT 1', 'i', [$productId])
        : null;

    if (!$product || (int)$product['stock'] <= 0) {
        flash('error', 'That product is unavailable.');
        redirect($back);
    }
    $maxQty = min(10, (int)$product['stock']);
    if ($quantity < 1 || $quantity > $maxQty) {
        flash('error', "Quantity must be between 1 and {$maxQty}.");
        redirect($back);
    }

    $cartId = get_or_create_cart((int)$user['id']);
    $existing = fetch_one(
        'SELECT id, quantity FROM cart_items WHERE cart_id = ? AND product_type = ? AND product_id = ? LIMIT 1',
        'isi',
        [$cartId, 'pharmacy', $productId]
    );
    if ($existing) {
        $newQty = min((int)$existing['quantity'] + $quantity, (int)$product['stock']);
        $stmt = db()->prepare('UPDATE cart_items SET quantity = ? WHERE id = ?');
        $stmt->bind_param('ii', $newQty, $existing['id']);
        $stmt->execute();
        $stmt->close();
    } else {
        $stmt = db()->prepare('INSERT INTO cart_items (cart_id, product_type, product_id, quantity) VALUES (?, ?, ?, ?)');
        $stmt->bind_param('isii', $cartId, $type, $productId, $quantity);
        $type = 'pharmacy';
        $stmt->execute();
        $stmt->close();
    }
    flash('success', 'Added to cart 🛒');
    redirect($back);
}

/* --------------------------------- Filters --------------------------------- */
$q = trim((string)($_GET['q'] ?? ''));
$category = trim((string)($_GET['category'] ?? ''));
if ($category !== '' && !array_key_exists($category, $CATEGORIES)) {
    $category = ''; // whitelist: unknown values are ignored
}

$where = [];
$types = '';
$params = [];
if ($q !== '') {
    $where[] = 'name LIKE ?';
    $types .= 's';
    $params[] = '%' . $q . '%';
}
if ($category !== '') {
    $where[] = 'category = ?';
    $types .= 's';
    $params[] = $category;
}
$sql = 'SELECT id, name, category, description, price, stock, image, requires_prescription FROM pharmacy_products';
if ($where) $sql .= ' WHERE ' . implode(' AND ', $where);
$sql .= ' ORDER BY name ASC';
$products = fetch_all($sql, $types, $params);

require_once $ROOT . '/includes/header.php';
?>

<section class="section">
  <div class="container">
       <h1 class="section-title">💊 Online Pharmacy</h1>
    <p class="section-subtitle">Medicines, vitamins and first-aid essentials — delivered to your door.</p>

    <?php
    /* Delivery location from registration (can be changed in Settings) */
    $country = '';
    $partner = null;
    if (is_logged_in()) {
        $country = (string)($_SESSION['country'] ?? '');
        if ($country === '') {
            $pr = fetch_one('SELECT country FROM user_profiles WHERE user_id = ? LIMIT 1', 'i', [(int)current_user()['id']]);
            $country = (string)($pr['country'] ?? '');
            $_SESSION['country'] = $country;
        }
        $cityByCountry = [
            'Philippines' => 'Manila',
            'Thailand'    => 'Bangkok',
            'Indonesia'   => 'Jakarta',
            'Malaysia'    => 'Kuala Lumpur',
            'Vietnam'     => 'Hanoi',
        ];
        $city = $cityByCountry[$country] ?? '';
        if ($city !== '') {
            $partner = fetch_one(
                'SELECT name, address, phone FROM healthcare_facilities WHERE type = ? AND city = ? LIMIT 1',
                'ss',
                ['pharmacy', $city]
            );
        }
    }
    $flags = medirush_flags();
    ?>
    <div class="location-banner">
      <span aria-hidden="true">📍</span>
      <div>
        <?php if ($country !== ''): ?>
          <?php if ($partner): ?>
            <strong><?= e(t('loc_delivering')) ?>:</strong>
            <?= e($partner['name']) ?> — <?= e($partner['address']) ?>
            (<?= e($partner['phone']) ?>)
            · <span class="muted"><?= e(($flags[$country] ?? '') . ' ' . $country) ?></span>
          <?php else: ?>
            <strong><?= e(t('loc_delivering')) ?>:</strong>
            <?= e(($flags[$country] ?? '') . ' ' . $country) ?>
          <?php endif; ?>
          · <a href="<?= u('account/settings.php') ?>"><?= e(t('loc_change')) ?></a>
        <?php else: ?>
          <strong><?= e(t('loc_none')) ?></strong>
        <?php endif; ?>
      </div>
    </div>

    <div class="filter-bar">
      <form method="get" action="<?= u('pharmacy/pharmacy.php') ?>" class="filter-fields">
        <input type="text" name="q" class="form-input" placeholder="Search medicines…" value="<?= e($q) ?>" aria-label="Search medicines">
        <select name="category" class="form-select" aria-label="Filter by category">
          <option value="">All categories</option>
          <?php foreach ($CATEGORIES as $key => $label): ?>
            <option value="<?= e($key) ?>"<?= $category === $key ? ' selected' : '' ?>><?= e($label) ?></option>
          <?php endforeach; ?>
        </select>
        <button type="submit" class="btn btn-primary">🔍 Search</button>
        <a class="btn btn-outline" href="<?= u('pharmacy/pharmacy.php') ?>">Clear</a>
      </form>
    </div>

    <div class="notice">
      📄 Prescription needed? Upload it in <a href="<?= u('my_health/upload.php') ?>">My Health → Uploads</a> and our pharmacists will verify it.
    </div>
  </div>
</section>

<section class="section">
  <div class="container">
    <?php if ($products): ?>
      <div class="grid grid-3">
        <?php foreach ($products as $p): $stock = (int)$p['stock']; ?>
          <div class="product-card">
            <div class="product-image"><?= e(icon($p['image'], '💊')) ?></div>
            <div class="card-body">
              <h3 class="product-name"><?= e($p['name']) ?></h3>
              <span class="badge badge-info"><?= e($CATEGORIES[$p['category']] ?? 'Other') ?></span>
              <?php if ((int)$p['requires_prescription'] === 1): ?>
                <small class="badge badge-warning">Rx required</small>
              <?php endif; ?>
              <p class="product-price"><?= money($p['price']) ?></p>
              <?php if ($stock > 0): ?>
                <span class="badge <?= $stock < 8 ? 'badge-warning' : 'badge-success' ?>"><?= $stock < 8 ? 'Low stock' : 'In stock' ?></span>
              <?php else: ?>
                <span class="badge badge-danger">Out of stock</span>
              <?php endif; ?>
              <p class="product-desc"><?= e(mb_strimwidth((string)$p['description'], 0, 90, '…')) ?></p>
              <a class="btn btn-outline btn-sm" href="<?= u('pharmacy/medicine_details.php?id=' . (int)$p['id']) ?>">View details</a>
              <?php if ($stock > 0): ?>
                <form method="post" action="<?= u('pharmacy/pharmacy.php') ?>" class="inline-form">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="add_cart">
                  <input type="hidden" name="product_id" value="<?= (int)$p['id'] ?>">
                  <input type="hidden" name="back" value="pharmacy/pharmacy.php<?= $q !== '' || $category !== '' ? '?' . http_build_query(array_filter(['q' => $q, 'category' => $category])) : '' ?>">
                  <input type="number" name="quantity" class="form-input qty-input" value="1" min="1" max="<?= min(10, $stock) ?>" aria-label="Quantity">
                  <button type="submit" class="btn btn-small btn-outline">Add 🛒</button>
                </form>
              <?php endif; ?>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <div class="empty-state">
        <div class="empty-icon">🔍</div>
        <h3>No medicines found</h3>
        <p>Try a different search term or category.</p>
        <a class="btn btn-primary" href="<?= u('pharmacy/pharmacy.php') ?>">Browse everything</a>
      </div>
    <?php endif; ?>
  </div>
</section>

<?php require_once $ROOT . '/includes/footer.php'; ?>
