<?php
/**
 * MEDIRUSH — Session, authentication guard and helpers.
 * Every session-protected page: require_once $ROOT . '/includes/auth.php';
 */
declare(strict_types=1);

require_once __DIR__ . '/lang.php';
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db_connect.php';
require_once __DIR__ . '/functions.php';

/** Is a user logged in? */
function is_logged_in(): bool {
    return isset($_SESSION['user_id']) && is_int($_SESSION['user_id']) && $_SESSION['user_id'] > 0;
}

/** Row of the logged-in user (fresh from DB), or null. */
function current_user(): ?array {
    if (!is_logged_in()) return null;
    static $user = null;
    if ($user === null) {
        $stmt = db()->prepare('SELECT id, full_name, email, phone, role, created_at FROM users WHERE id = ? LIMIT 1');
        $stmt->bind_param('i', $_SESSION['user_id']);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc() ?: null;
        $stmt->close();
        if ($user === null) { // stale session
            logout_current_user();
        }
    }
    return $user;
}

/** Start an authenticated session for the given users-table row. */
function login_current_user(array $user): void {
    session_regenerate_id(true);
    $_SESSION['user_id'] = (int)$user['id'];
    $_SESSION['role']    = $user['role'];
    $_SESSION['full_name'] = $user['full_name'];
    $_SESSION['login_time'] = time();
}

/** Destroy the current session. */
function logout_current_user(): void {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}

/** Redirect to login if not authenticated (used by private pages). */
function require_login(string $redirectBack = ''): void {
    if (is_logged_in()) return;
    $target = 'login.php';
    if ($redirectBack !== '') $target .= '?next=' . urlencode($redirectBack);
    flash('info', 'Please log in to continue.');
    redirect($target);
}

/** Redirect to dashboard unless logged in (used by login/register). */
function require_guest(): void {
    if (is_logged_in()) redirect('dashboard.php');
}

/** Admin-only guard. */
function require_role(string $role): void {
    require_login();
    $user = current_user();
    if (!$user || $user['role'] !== $role) {
        http_response_code(403);
        flash('error', 'You do not have permission to view that page.');
        redirect('dashboard.php');
    }
}
