/* ============================================================
   MEDIRUSH — js/upload.js
   Prescription / medical record upload interactions.
   XHR (not fetch) because we want a real upload progress bar.
   ============================================================ */
(function () {
  'use strict';

  var MAX_BYTES = 5 * 1024 * 1024;             // must match upload_process.php
  var ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'];

  document.addEventListener('DOMContentLoaded', function () {
    var dropzone = document.getElementById('uploadDropzone');
    if (!dropzone) return;

    var input = document.getElementById('uploadFile');
    var listEl = document.getElementById('uploadList');
    var previewWrap = document.getElementById('uploadPreview');
    var previewImg = document.getElementById('previewImage');
    var previewIcon = document.getElementById('previewIcon');
    var fileNameEl = document.getElementById('previewFileName');
    var fileSizeEl = document.getElementById('previewFileSize');
    var progressWrap = document.getElementById('uploadProgress');
    var progressBar = document.getElementById('uploadProgressBar');
    var progressLabel = document.getElementById('uploadProgressLabel');
    var errorEl = document.getElementById('uploadError');
    var submitBtn = document.getElementById('uploadSubmit');
    var form = document.getElementById('uploadForm');
    var chosenFile = null;

    function fmtBytes(bytes) {
      if (bytes < 1024) return bytes + ' B';
      if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
      return (bytes / 1048576).toFixed(1) + ' MB';
    }

    function showError(msg) {
      if (errorEl) { errorEl.hidden = false; errorEl.textContent = '⚠️ ' + msg; }
      clearFile();
    }

    function clearError() {
      if (errorEl) { errorEl.hidden = true; errorEl.textContent = ''; }
    }

    function clearFile() {
      chosenFile = null;
      if (previewWrap) previewWrap.hidden = true;
      if (input) input.value = '';
      if (listEl) listEl.textContent = '';
      if (submitBtn) submitBtn.disabled = true;
    }

    function accept(file) {
      clearError();
      if (!file) return;
      var ext = (file.name.split('.').pop() || '').toLowerCase();
      if (ALLOWED_TYPES.indexOf(file.type) === -1) {
        showError('Only JPG, PNG, WEBP or PDF files are allowed (detected type: ' + (file.type || 'unknown') + ').');
        return;
      }
      if (file.size > MAX_BYTES) {
        showError('File is too large (' + fmtBytes(file.size) + '). Maximum size is 5 MB.');
        return;
      }
      chosenFile = file;
      if (previewWrap) {
        previewWrap.hidden = false;
        if (fileNameEl) fileNameEl.textContent = file.name;
        if (fileSizeEl) fileSizeEl.textContent = fmtBytes(file.size);
        if (file.type === 'application/pdf') {
          if (previewImg) { previewImg.hidden = true; }
          if (previewIcon) { previewIcon.hidden = false; }
        } else {
          if (previewIcon) { previewIcon.hidden = true; }
          if (previewImg) { previewImg.hidden = false; previewImg.src = URL.createObjectURL(file); }
        }
      }
      if (submitBtn) submitBtn.disabled = false;
    }

    if (input) {
      input.addEventListener('change', function () { accept(input.files && input.files[0]); });
    }

    ['dragover', 'dragenter'].forEach(function (evt) {
      dropzone.addEventListener(evt, function (e) { e.preventDefault(); dropzone.classList.add('dragging'); });
    });
    ['dragleave', 'drop'].forEach(function (evt) {
      dropzone.addEventListener(evt, function (e) { e.preventDefault(); dropzone.classList.remove('dragging'); });
    });
    dropzone.addEventListener('drop', function (e) {
      var file = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
      if (input) {
        try {
          var dt = new DataTransfer();
          if (file) dt.items.add(file);
          input.files = dt.files;
        } catch (err) { /* Safari fallback */ }
      }
      accept(file);
    });

    var clearBtn = document.getElementById('uploadClear');
    if (clearBtn) clearBtn.addEventListener('click', function (e) { e.preventDefault(); clearFile(); clearError(); });

    if (!form) return;

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!chosenFile) { showError('Please choose a file first.'); return; }
      if (typeof form.checkValidity === 'function' && !form.checkValidity()) {
        form.reportValidity();
        return;
      }

      var xhr = new XMLHttpRequest();
      var data = new FormData(form);
      if (data.has('document_file')) data.set('document_file', chosenFile, chosenFile.name);

      if (progressWrap) progressWrap.hidden = false;
      if (progressBar) progressBar.style.width = '0%';
      if (progressLabel) progressLabel.textContent = 'Uploading… 0%';
      if (submitBtn) { submitBtn.disabled = true; }

      xhr.upload.addEventListener('progress', function (ev) {
        if (!ev.lengthComputable) return;
        var pct = Math.round((ev.loaded / ev.total) * 100);
        if (progressBar) progressBar.style.width = pct + '%';
        if (progressLabel) progressLabel.textContent = 'Uploading… ' + pct + '%';
      });

      xhr.addEventListener('load', function () {
        if (progressWrap) progressWrap.hidden = true;
        if (submitBtn) submitBtn.disabled = false;
        var res = null;
        try { res = JSON.parse(xhr.responseText); } catch (err) { /* non-JSON = server error page */ }
        if (xhr.status >= 200 && xhr.status < 300 && res && res.ok) {
          if (progressLabel) progressLabel.textContent = 'Done!';
          // Server sets a flash message and redirects itself when not AJAX-friendly;
          // we navigate so the success banner shows on the destination page.
          window.location.assign(res.redirect || window.location.href);
          return;
        }
        showError((res && res.message) ? res.message : 'Upload failed (HTTP ' + xhr.status + '). Please try again.');
      });

      xhr.addEventListener('error', function () {
        if (progressWrap) progressWrap.hidden = true;
        if (submitBtn) submitBtn.disabled = false;
        showError('Network error — upload could not be sent. Check that Apache and MySQL are running.');
      });

      xhr.open('POST', form.getAttribute('action'));
      xhr.send(data);
    });
  });
})();
