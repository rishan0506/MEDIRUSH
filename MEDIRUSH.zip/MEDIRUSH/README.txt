═══════════════════════════════════════════════════════════════════
 MEDIRUSH — Your health. Your beauty. One platform.
 Complete PHP + MySQL website project (XAMPP / VS Code ready)
═══════════════════════════════════════════════════════════════════

1. REQUIRED SOFTWARE
--------------------
  • XAMPP (Apache + MySQL + PHP 8.1+ + phpMyAdmin)   → https://www.apachefriends.org
  • Visual Studio Code (or any code editor)
  • A modern browser (Chrome / Edge / Firefox)

2. HOW TO INSTALL AND CONFIGURE
-------------------------------
  a) Install XAMPP with Apache, MySQL and PHPMyAdmin modules selected.
  b) Copy the MEDIRUSH folder (see step 4) into your XAMPP web root.
  c) No Composer, npm or build step is required — the site is plain PHP.

3. HOW TO IMPORT database.sql USING phpMyAdmin
----------------------------------------------
  a) Open the XAMPP Control Panel and START both Apache and MySQL.
  b) In your browser open:  http://localhost/phpmyadmin
  c) Click “Import” in the top menu.
  d) Choose the file “database.sql” from inside the MEDIRUSH folder and click
     “Go” (leave all defaults — format: SQL).
  e) You should now see a database named “medirush” containing 16 tables
     (users, user_profiles, medical_records, prescriptions, pharmacy_products,
     skincare_products, carts, cart_items, orders, order_items, doctors,
     appointments, medications, medication_reminders, skincare_routines,
     skincare_logs, healthcare_facilities, notifications, messages).

     DEMO ACCOUNTS (password for BOTH is:  password)
       Admin:  admin@medirush.local   → admin.php console (prescription approval)
       User:   demo@medirush.local    → normal user account

4. WHERE TO PLACE THE MEDIRUSH FOLDER IN XAMPP
----------------------------------------------
  Windows default XAMPP install:
      C:\xampp\htdocs\
      └── MEDIRUSH\            ← put the whole project folder here
          (this file, index.php, database.sql, css/, js/, includes/, ...)

  So the final path is:  C:\xampp\htdocs\MEDIRUSH\index.php
  If you renamed the folder or use a different drive, keep the folder
  name “MEDIRUSH” or simply browse to the folder name you chose.

5. HOW TO START APACHE AND MYSQL
--------------------------------
  • Open the “XAMPP Control Panel”.
  • Click “Start” next to Apache  (turns green).
  • Click “Start” next to MySQL    (turns green).
  • If MySQL fails to start, another service may be using port 3306 —
    stop the conflicting service (e.g. a standalone MySQL/VMware) or
    change the port in XAMPP’s config.

6. HOW TO OPEN THE WEBSITE THROUGH LOCALHOST
--------------------------------------------
  Main site:        http://localhost/MEDIRUSH/index.php
  Login:            http://localhost/MEDIRUSH/login.php
  Admin console:    http://localhost/MEDIRUSH/admin.php   (must be logged in as admin)

  Suggested demo walkthrough:
    1. Log in as demo@medirush.local
    2. My Health → Uploads → upload a JPG/PDF “prescription” (it appears as PENDING)
    3. Log out, log in as admin@medirush.local → admin.php → Approve the prescription
    4. Log back in as demo → the prescription now shows APPROVED
    5. Pharmacy → add products to cart → Checkout (demo payment) → Orders
    6. Healthcare → Doctor consultation → book an appointment → Appointments
    7. Beauty → Skincare assistant (demo AI) / Skincare tracker

7. API KEYS AND ADDITIONAL CONFIGURATION
----------------------------------------
  All external service keys live in ONE file:  includes/config.php

      GOOGLE_MAPS_API_KEY      → enables the live Google Map on
                                 healthcare/emergency_locator.php.
                                 Optional: without it the page shows a clearly
                                 labelled DEMO facility list (no map calls made).
      SKINCARE_AI_API_KEY      → enables the live AI model on
                                 beauty/skincare_assistant.php.
                                 Optional: without it a built-in rule-based
                                 demo assistant is used.
      PAYMENT_GATEWAY_API_KEY  → placeholder; checkout always runs in DEMO
                                 mode (no real charges) until you integrate
                                 a gateway.
      VIDEO_CONSULT_API_KEY    → placeholder for live video consultation rooms.

  Keys are injected server-side via window.MEDIRUSH_CONFIG — they are never
  hard-coded into front-end JavaScript files.
  Never commit real keys to a public repository.

  Database credentials (change if your MySQL root has a password) live in:
      includes/db_connect.php
      → DB_HOST 'localhost', DB_NAME 'medirush', DB_USER 'root', DB_PASS ''

8. PROJECT STRUCTURE
--------------------
  MEDIRUSH/
  ├── index.php · login.php · register.php · dashboard.php · logout.php
  ├── admin.php (prescription verification) · download.php (secure file serving)
  ├── database.sql · README.txt
  ├── includes/   → db_connect, auth, functions, config, header, footer, sidebar
  ├── css/        → style.css, responsive.css
  ├── js/         → script.js, theme.js, upload.js
  ├── healthcare/ → healthcare.php, anatomy.php, doctor_consultation.php,
  │                emergency_locator.php
  ├── pharmacy/   → pharmacy.php, medicine_details.php, cart.php, checkout.php
  ├── beauty/     → beauty.php, beauty_details.php, skincare_consultation.php,
  │                skincare_assistant.php
  ├── my_health/  → my_health.php, upload.php, upload_process.php, medication.php,
  │                skincare_tracker.php
  ├── account/    → profile.php, settings.php, orders.php, appointments.php
  └── assets/
      ├── images/
      └── uploads/  (.htaccess denies direct web access; files are served only
                    through download.php after an ownership check)

9. SECURITY NOTES (already implemented)
---------------------------------------
  • Passwords: bcrypt password_hash() / password_verify()
  • All SQL: prepared statements (no string-built queries)
  • Sessions: PHP sessions + session_regenerate_id() on login
  • CSRF: token on every form (verify_csrf())
  • Uploads: extension + real MIME (finfo) checks, 5 MB cap, random safe
    filenames, stored in assets/uploads/ which is DENIED for direct web access
    and served only through download.php after a per-user ownership check
  • Private data: every private query is scoped to the logged-in user's id
  • Admin area: require_role('admin')

10. TROUBLESHOOTING
-------------------
  • “Database not ready” screen → make sure MySQL is running and database.sql
    was imported (see steps 3 & 5).
  • Blank page → enable error display temporarily: in php.ini set
    display_errors = On, or check C:\xampp\apache\logs\error.log.
  • Uploads fail → confirm the folder MEDIRUSH/assets/uploads is writable
    (right-click → Properties → Security: allow “Modify” for your user).
  • Dark mode resets → it is intentionally stored per-browser (localStorage).

Enjoy MEDIRUSH! 🩺🧴
