<?php
/**
 * MEDIRUSH — Admin console (admins only).
 * Tabbed interface for easy viewing of Prescriptions, Appointments, Customer Details, and AI Support.
 */
$ROOT = '.';
$PAGE_TITLE = 'Admin Console';
$ACTIVE = 'admin';
$SHOW_SIDEBAR = false;
require_once $ROOT . '/includes/auth.php';
require_role('admin');

/* ------------------------------------------------------------------ */
/* POST: verify a prescription (approve / reject)                      */
/* ------------------------------------------------------------------ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'verify_prescription') {
    verify_csrf();

    $rxId   = (int)($_POST['prescription_id'] ?? 0);
    $action = (string)($_POST['decision'] ?? '');
    $note   = trim((string)($_POST['admin_note'] ?? ''));

    if (in_array($action, ['approve', 'reject'], true) && $rxId > 0) {
        $rx = fetch_one('SELECT id, user_id, status FROM prescriptions WHERE id = ?', 'i', [$rxId]);
        if ($rx && $rx['status'] === 'pending') {
            $status = $action === 'approve' ? 'approved' : 'rejected';
            $stmt = db()->prepare("UPDATE prescriptions SET status = ?, admin_note = ?, verified_at = NOW() WHERE id = ?");
            $stmt->bind_param('ssi', $status, $note, $rxId);
            $stmt->execute();
            $stmt->close();

            add_notification((int)$rx['user_id'], 'prescription', 'Prescription ' . $status,
                'Your prescription was ' . $status . ($note !== '' ? '. Note: ' . $note : ''));
            flash('success', 'Prescription #' . $rxId . ' ' . $status . '.');
        }
    }
    redirect('admin.php?tab=prescriptions');
}

/* ------------------------------------------------------------------ */
/* POST: update support request status                                */
/* ------------------------------------------------------------------ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'update_support') {
    verify_csrf();
    $supId  = (int)($_POST['support_id'] ?? 0);
    $status = $_POST['status'] ?? 'pending';
    if ($supId > 0 && in_array($status, ['pending', 'contacted', 'resolved'], true)) {
        $stmt = db()->prepare("UPDATE admin_support_requests SET status = ? WHERE id = ?");
        $stmt->bind_param('si', $status, $supId);
        $stmt->execute();
        $stmt->close();
        flash('success', 'Support request status updated.');
    }
    redirect('admin.php?tab=support');
}

$tab = $_GET['tab'] ?? 'prescriptions';

/* ------------------------------------------------------------------ */
/* Data Queries                                                        */
/* ------------------------------------------------------------------ */
$prescriptions = fetch_all(
    'SELECT p.id, p.doctor_name, p.file_path, p.original_filename, p.status, p.admin_note, p.verified_at, p.uploaded_at,
            u.id AS owner_id, u.full_name AS owner_name, u.email AS owner_email
     FROM prescriptions p JOIN users u ON u.id = p.user_id
     ORDER BY p.uploaded_at DESC, p.id DESC'
);

$appointments = fetch_all(
    'SELECT a.id, a.appointment_date, a.appointment_time, a.mode, a.status, a.notes,
            u.full_name AS customer_name, u.email AS customer_email, u.phone AS customer_phone,
            d.name AS doctor_name, d.specialization
     FROM appointments a
     JOIN users u ON u.id = a.user_id
     JOIN doctors d ON d.id = a.doctor_id
     ORDER BY a.appointment_date DESC, a.appointment_time DESC'
);

$customers = fetch_all(
    'SELECT u.id, u.full_name, u.email, u.phone, u.created_at,
            p.address, p.blood_type, p.allergies, p.chronic_conditions, p.emergency_contact_name, p.emergency_contact_phone
     FROM users u
     LEFT JOIN user_profiles p ON p.user_id = u.id
     WHERE u.role = \'user\'
     ORDER BY u.created_at DESC'
);

$supportRequests = fetch_all(
    'SELECT s.id, s.message, s.hotline, s.status, s.created_at,
            u.full_name, u.email, u.phone
     FROM admin_support_requests s
     JOIN users u ON u.id = s.user_id
     ORDER BY s.created_at DESC'
);

$pendingSupportCount = count(array_filter($supportRequests, fn($r) => $r['status'] === 'pending'));
$pendingRxCount = count(array_filter($prescriptions, fn($r) => $r['status'] === 'pending'));

$rxBadge = ['pending' => 'badge-warning', 'approved' => 'badge-success', 'rejected' => 'badge-danger'];

require_once $ROOT . '/includes/header.php';
?>
<div class="container-wide py-4">
  <div class="container">
    <div class="flex-between mb-3">
      <div>
        <h1 class="section-title">🛡️ Admin Control Panel</h1>
        <p class="section-subtitle">Logged in as <strong><?= e(current_user()['full_name']) ?></strong>. Easily manage prescriptions, appointments, customer profiles, and AI handover requests.</p>
      </div>
    </div>

    <!-- Clean Tab Navigation Bar -->
    <div class="tabs mb-4" style="display: flex; gap: 8px; border-bottom: 2px solid var(--border); padding-bottom: 12px; flex-wrap: wrap;">
      <a class="btn btn-sm <?= $tab === 'prescriptions' ? 'btn-primary' : 'btn-outline' ?>" href="admin.php?tab=prescriptions">
        💊 Prescriptions <?php if ($pendingRxCount > 0): ?><span class="badge badge-danger"><?= $pendingRxCount ?></span><?php endif; ?>
      </a>
      <a class="btn btn-sm <?= $tab === 'appointments' ? 'btn-primary' : 'btn-outline' ?>" href="admin.php?tab=appointments">
        📅 Appointments (<?= count($appointments) ?>)
      </a>
      <a class="btn btn-sm <?= $tab === 'customers' ? 'btn-primary' : 'btn-outline' ?>" href="admin.php?tab=customers">
        👤 Customer Details (<?= count($customers) ?>)
      </a>
      <a class="btn btn-sm <?= $tab === 'support' ? 'btn-primary' : 'btn-outline' ?>" href="admin.php?tab=support">
        📞 AI Handover Requests <?php if ($pendingSupportCount > 0): ?><span class="badge badge-danger"><?= $pendingSupportCount ?></span><?php endif; ?>
      </a>
    </div>

    <!-- TAB 1: PRESCRIPTIONS -->
    <?php if ($tab === 'prescriptions'): ?>
      <section class="section">
        <h2 class="section-title">Prescription Verification</h2>
        <p class="section-subtitle">Review files uploaded by patients, check doctor notes, and approve or reject.</p>
        <?php if ($prescriptions): ?>
          <div class="table-wrap card">
            <table class="table">
              <thead>
                <tr><th>#ID</th><th>Patient</th><th>Doctor & File</th><th>Status</th><th>Uploaded At</th><th>Action / Decision</th></tr>
              </thead>
              <tbody>
                <?php foreach ($prescriptions as $p): ?>
                  <tr>
                    <td><strong>#<?= (int)$p['id'] ?></strong></td>
                    <td><strong><?= e($p['owner_name']) ?></strong><br><span class="muted"><?= e($p['owner_email']) ?></span></td>
                    <td>
                      <small class="muted">Dr. <?= e($p['doctor_name'] ?: 'Not specified') ?></small><br>
                      <a href="<?= u('download.php') ?>?file=<?= e(rawurlencode(basename($p['file_path']))) ?>" target="_blank" class="btn btn-outline btn-sm mt-1">👁 View File</a>
                    </td>
                    <td>
                      <span class="badge <?= e($rxBadge[$p['status']] ?? '') ?>"><?= e(ucfirst($p['status'])) ?></span>
                      <?php if (trim((string)$p['admin_note']) !== ''): ?><br><small class="muted">Note: <?= e($p['admin_note']) ?></small><?php endif; ?>
                    </td>
                    <td><?= e(date('d M Y, H:i', strtotime($p['uploaded_at']))) ?></td>
                    <td>
                      <?php if ($p['status'] === 'pending'): ?>
                        <form action="<?= u('admin.php?tab=prescriptions') ?>" method="post">
                          <?= csrf_field() ?>
                          <input type="hidden" name="action" value="verify_prescription">
                          <input type="hidden" name="prescription_id" value="<?= (int)$p['id'] ?>">
                          <input class="form-input mb-1 form-input-sm" type="text" name="admin_note" placeholder="Optional admin note">
                          <div style="display: flex; gap: 4px;">
                            <button type="submit" name="decision" value="approve" class="btn btn-primary btn-sm">✓ Approve</button>
                            <button type="submit" name="decision" value="reject" class="btn btn-danger btn-sm">✕ Reject</button>
                          </div>
                        </form>
                      <?php else: ?>
                        <span class="muted font-italic">Handled</span>
                      <?php endif; ?>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php else: ?>
          <div class="card empty-state"><div class="empty-icon">📝</div><h3>No prescriptions found</h3><p>Uploaded prescriptions will appear here.</p></div>
        <?php endif; ?>
      </section>

    <!-- TAB 2: CUSTOMER APPOINTMENTS -->
    <?php elseif ($tab === 'appointments'): ?>
      <section class="section">
        <h2 class="section-title">Customer Appointments (Simplified View)</h2>
        <p class="section-subtitle">Quickly review scheduled patient consultations, doctors, times, and modes.</p>
        <?php if ($appointments): ?>
          <div class="table-wrap card">
            <table class="table">
              <thead>
                <tr><th>Patient</th><th>Doctor & Specialization</th><th>Date & Time</th><th>Mode</th><th>Status</th><th>Notes</th></tr>
              </thead>
              <tbody>
                <?php foreach ($appointments as $a): ?>
                  <tr>
                    <td><strong><?= e($a['customer_name']) ?></strong><br><span class="muted"><?= e($a['customer_phone'] ?: $a['customer_email']) ?></span></td>
                    <td><strong><?= e($a['doctor_name']) ?></strong><br><span class="muted"><?= e($a['specialization']) ?></span></td>
                    <td><strong><?= e(date('D, d M Y', strtotime($a['appointment_date']))) ?></strong><br><span class="muted"><?= e(substr($a['appointment_time'], 0, 5)) ?></span></td>
                    <td><span class="badge badge-info"><?= e(ucfirst(str_replace('_', ' ', $a['mode']))) ?></span></td>
                    <td><span class="badge"><?= e(ucfirst($a['status'])) ?></span></td>
                    <td><small><?= e($a['notes'] ?: 'None') ?></small></td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php else: ?>
          <div class="card empty-state"><div class="empty-icon">📅</div><h3>No customer appointments booked yet</h3></div>
        <?php endif; ?>
      </section>

    <!-- TAB 3: CUSTOMER DETAILS -->
    <?php elseif ($tab === 'customers'): ?>
      <section class="section">
        <h2 class="section-title">Customer Details (Simplified View)</h2>
        <p class="section-subtitle">Registered user profiles, medical background, allergies, and emergency contacts.</p>
        <?php if ($customers): ?>
          <div class="table-wrap card">
            <table class="table">
              <thead>
                <tr><th>Customer Name</th><th>Blood Type</th><th>Allergies & Conditions</th><th>Emergency Contact</th><th>Delivery Address</th></tr>
              </thead>
              <tbody>
                <?php foreach ($customers as $c): ?>
                  <tr>
                    <td><strong><?= e($c['full_name']) ?></strong><br><span class="muted"><?= e($c['email']) ?></span><br><span class="muted"><?= e($c['phone'] ?: 'No phone') ?></span></td>
                    <td><span class="badge badge-info"><?= e($c['blood_type'] ?: 'N/A') ?></span></td>
                    <td><small><strong>Allergies:</strong> <?= e($c['allergies'] ?: 'None') ?><br><strong>Conditions:</strong> <?= e($c['chronic_conditions'] ?: 'None') ?></small></td>
                    <td><small><strong><?= e($c['emergency_contact_name'] ?: 'None') ?></strong><br><span class="muted"><?= e($c['emergency_contact_phone']) ?></span></small></td>
                    <td><small><?= e($c['address'] ?: 'Not provided') ?></small></td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php else: ?>
          <div class="card empty-state"><div class="empty-icon">👤</div><h3>No registered customers found</h3></div>
        <?php endif; ?>
      </section>

    <!-- TAB 4: AI SUPPORT HANDOVER -->
    <?php elseif ($tab === 'support'): ?>
      <section class="section">
        <h2 class="section-title">AI Support Handover & Callback Requests</h2>
        <p class="section-subtitle">Messages from customers unsatisfied with the AI assistant who requested a phone callback.</p>
        <?php if ($supportRequests): ?>
          <div class="table-wrap card">
            <table class="table">
              <thead>
                <tr><th>Customer</th><th>Customer Message</th><th>Hotline / Phone</th><th>Submitted</th><th>Status</th></tr>
              </thead>
              <tbody>
                <?php foreach ($supportRequests as $req): ?>
                  <tr>
                    <td><strong><?= e($req['full_name']) ?></strong><br><span class="muted"><?= e($req['email']) ?></span></td>
                    <td><?= nl2br(e($req['message'])) ?></td>
                    <td><a href="tel:<?= e($req['hotline']) ?>" class="btn btn-outline btn-sm">📞 <?= e($req['hotline']) ?></a></td>
                    <td><?= e(date('d M Y, H:i', strtotime($req['created_at']))) ?></td>
                    <td>
                      <form method="post" action="<?= u('admin.php?tab=support') ?>">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="update_support">
                        <input type="hidden" name="support_id" value="<?= (int)$req['id'] ?>">
                        <select name="status" class="form-select form-select-sm" onchange="this.form.submit()">
                          <option value="pending" <?= $req['status'] === 'pending' ? 'selected' : '' ?>>Pending</option>
                          <option value="contacted" <?= $req['status'] === 'contacted' ? 'selected' : '' ?>>Contacted</option>
                          <option value="resolved" <?= $req['status'] === 'resolved' ? 'selected' : '' ?>>Resolved</option>
                        </select>
                      </form>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php else: ?>
          <div class="card empty-state"><div class="empty-icon">📞</div><h3>No AI support handover requests</h3><p>When customers click "Submit to Human Admin" in the AI assistant, their requests will show up here.</p></div>
        <?php endif; ?>
      </section>
    <?php endif; ?>

  </div>
</div>
<?php require_once $ROOT . '/includes/footer.php'; ?>