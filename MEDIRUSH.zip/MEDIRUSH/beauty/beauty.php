<?php
/**
 * MEDIRUSH — beauty/beauty.php
 * Public skincare marketplace: filters, product grid, add-to-cart, service promos.
 */
declare(strict_types=1);

$ROOT = '..';
$PAGE_TITLE = 'Beauty & Skincare — MEDIRUSH';
$ACTIVE = 'beauty';

// Page POSTs private data (add to cart), so auth + session load FIRST.
require_once $ROOT . '/includes/auth.php';

/* ------------------------- Add-to-cart POST handler ------------------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'add_to_cart') {
    verify_csrf();
    require_login('beauty/beauty.php');

    $pid = (int)($_POST['product_id'] ?? 0);
    $qty = (int)($_POST['quantity'] ?? 1);
    $back = 'beauty/beauty.php';

    if ($pid < 1 || $qty < 1 || $qty > 99) {
        flash('error', 'Invalid product or quantity.');
        redirect($back);
    }

    $product = fetch_one(
        'SELECT id, name, stock FROM skincare_products WHERE id = ? LIMIT 1',
        'i', [$pid]
    );
    if (!$product) {
        flash('error', 'That product could not be found.');
        redirect($back);
    }
    if ((int)$product['stock'] < 1) {
        flash('error', '“' . $product['name'] . '” is out of stock right now.');
        redirect($back);
    }
    if ($qty > (int)$product['stock']) {
        flash('error', 'Only ' . (int)$product['stock'] . ' unit(s) of “' . $product['name'] . '” left in stock.');
        redirect($back);
    }

    $cartId = get_or_create_cart((int)$_SESSION['user_id']);
    $ptype = 'skincare';

    $existing = fetch_one(
        'SELECT id, quantity FROM cart_items WHERE cart_id = ? AND product_type = ? AND product_id = ? LIMIT 1',
        'isi', [$cartId, $ptype, $pid]
    );
    if ($existing) {
        $newQty = (int)$existing['quantity'] + $qty;
        if ($newQty > (int)$product['stock']) $newQty = (int)$product['stock'];
        $stmt = db()->prepare('UPDATE cart_items SET quantity = ? WHERE id = ?');
        $stmt->bind_param('ii', $newQty, $existing['id']);
        $stmt->execute();
        $stmt->close();
    } else {
        $stmt = db()->prepare('INSERT INTO cart_items (cart_id, product_type, product_id, quantity) VALUES (?, ?, ?, ?)');
        $stmt->bind_param('isii', $cartId, $ptype, $pid, $qty);
        $stmt->execute();
        $stmt->close();
    }

    flash('success', '“' . $product['name'] . '” added to your cart. 🛒');
    redirect($back);
}

/* ------------------------------ GET filters -------------------------------- */
$allowedSkins = ['all', 'oily', 'dry', 'combination', 'sensitive'];
$allowedCats  = ['all', 'cleanser', 'moisturizer', 'serum', 'sunscreen', 'toner', 'mask', 'other'];

$q    = trim((string)($_GET['q'] ?? ''));
$skin = (string)($_GET['skin_type'] ?? 'all');
$cat  = (string)($_GET['category'] ?? 'all');
if (!in_array($skin, $allowedSkins, true)) $skin = 'all';
if (!in_array($cat, $allowedCats, true)) $cat = 'all';

$skinLabels = ['all' => 'All skin types', 'oily' => 'Oily', 'dry' => 'Dry', 'combination' => 'Combination', 'sensitive' => 'Sensitive'];
$catLabels  = ['all' => 'All categories', 'cleanser' => 'Cleanser', 'moisturizer' => 'Moisturizer', 'serum' => 'Serum', 'sunscreen' => 'Sunscreen', 'toner' => 'Toner', 'mask' => 'Mask', 'other' => 'Other'];

$sql = 'SELECT id, name, category, skin_type, description, price, stock, image FROM skincare_products';
$types = ''; $params = []; $where = [];
if ($q !== '') {
    $where[] = 'name LIKE ?';
    $types .= 's';
    $params[] = '%' . $q . '%';
}
if ($skin !== 'all') {
    $where[] = "(skin_type = 'all' OR skin_type = ?)";
    $types .= 's';
    $params[] = $skin;
}
if ($cat !== 'all') {
    $where[] = 'category = ?';
    $types .= 's';
    $params[] = $cat;
}
if ($where) $sql .= ' WHERE ' . implode(' AND ', $where);
$sql .= ' ORDER BY name ASC';

$products = fetch_all($sql, $types, $params);

require_once $ROOT . '/includes/header.php';
?>

<section class="section">
  <h1 class="section-title">Skin that glows ✨</h1>
  <p class="section-subtitle">
    Everything your routine needs, in one place — cleansers, serums, moisturizers and SPF,
    matched to your skin type. Filter below, or get guidance from a professional.
  </p>

  <!-- Filters -->
  <div class="card card-body">
    <form method="get" action="<?= u('beauty/beauty.php') ?>" class="js-trim">
      <div class="grid grid-4">
        <div class="form-group">
          <label class="form-label" for="fQ">Search</label>
          <input class="form-input" type="text" id="fQ" name="q" value="<?= e($q) ?>" placeholder="Try “serum” or “SPF”">
        </div>
        <div class="form-group">
          <label class="form-label" for="fSkin">Skin type</label>
          <select class="form-select" id="fSkin" name="skin_type">
            <?php foreach ($skinLabels as $val => $label): ?>
              <option value="<?= e($val) ?>"<?= $val === $skin ? ' selected' : '' ?>><?= e($label) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label" for="fCat">Category</label>
          <select class="form-select" id="fCat" name="category">
            <?php foreach ($catLabels as $val => $label): ?>
              <option value="<?= e($val) ?>"<?= $val === $cat ? ' selected' : '' ?>><?= e($label) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">&nbsp;</label>
          <button class="btn btn-primary btn-block" type="submit">Filter</button>
        </div>
      </div>
      <p class="form-help">
        <?= count($products) ?> product<?= count($products) === 1 ? '' : 's' ?> found.
        <?php if ($q !== '' || $skin !== 'all' || $cat !== 'all'): ?>
          <a href="<?= u('beauty/beauty.php') ?>">Clear filters</a>
        <?php endif; ?>
      </p>
    </form>
  </div>

  <!-- Product grid -->
  <div class="grid grid-3">
    <?php foreach ($products as $p): $inStock = (int)$p['stock'] > 0; ?>
      <div class="product-card">
        <a class="product-image" href="<?= u('beauty/beauty_details.php?id=' . (int)$p['id']) ?>" title="View details">
          <?= e(icon($p['image'], '🧴')) ?>
        </a>
        <div class="card-body">
          <h3 class="product-name"><a href="<?= u('beauty/beauty_details.php?id=' . (int)$p['id']) ?>"><?= e($p['name']) ?></a></h3>
          <?php $desc = (string)$p['description']; if (mb_strlen($desc) > 60) $desc = mb_substr($desc, 0, 60) . '…'; ?>
          <p class="product-desc"><?= e($desc) ?></p>
          <p class="product-price"><?= money($p['price']) ?></p>
          <p>
            <span class="badge"><?= e($catLabels[$p['category']] ?? ucfirst((string)$p['category'])) ?></span>
            <span class="badge badge-info"><?= e($skinLabels[$p['skin_type']] ?? ucfirst((string)$p['skin_type'])) ?></span>
            <?php if ($inStock): ?><span class="badge badge-success">In stock (<?= (int)$p['stock'] ?>)</span>
            <?php else: ?><span class="badge badge-danger">Out of stock</span><?php endif; ?>
          </p>
          <?php if ($inStock): ?>
            <form method="post" action="<?= u('beauty/beauty.php') ?>">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="add_to_cart">
              <input type="hidden" name="product_id" value="<?= (int)$p['id'] ?>">
              <input type="hidden" name="quantity" value="1">
              <button class="btn btn-primary btn-sm btn-block" type="submit">🛒 Add to cart</button>
            </form>
          <?php else: ?>
            <button class="btn btn-outline btn-sm btn-block" disabled>Out of stock</button>
          <?php endif; ?>
        </div>
      </div>
    <?php endforeach; ?>
  </div>

  <?php if (!$products): ?>
    <div class="empty-state">
      <div class="empty-icon">🔍</div>
      <h3>No products match those filters</h3>
      <p>Try a different search term, skin type or category.</p>
      <a class="btn btn-primary" href="<?= u('beauty/beauty.php') ?>">Clear filters</a>
    </div>
  <?php endif; ?>

  <!-- Service promos -->
  <div class="grid grid-2">
    <div class="card card-body">
      <h3>👩‍⚕️ Talk to a skin professional</h3>
      <p>Chat about breakouts, pigmentation or building a routine — with a skin professional.</p>
      <a class="btn btn-primary btn-sm" href="<?= u('beauty/skincare_consultation.php') ?>">Start a consultation</a>
    </div>
    <div class="card card-body">
      <h3>🤖 Try the AI Skin Assistant</h3>
      <p>An instant demo assistant that recommends products for your skin type.</p>
      <a class="btn btn-outline btn-sm" href="<?= u('beauty/skincare_assistant.php') ?>">Open assistant</a>
    </div>
  </div>

  <!-- Daily skincare basics -->
  <h2 class="section-title">Daily skincare basics</h2>
  <div class="card card-body">
    <div class="accordion-item open">
      <button type="button" class="accordion-header">🧼 1. Cleanse — gently, twice a day</button>
      <div class="accordion-body">
        <p>Use a mild, pH-balanced cleanser morning and night. Avoid scrubbing or hot water; both strip the skin barrier and trigger more oil.</p>
      </div>
    </div>
    <div class="accordion-item">
      <button type="button" class="accordion-header">💧 2. Treat — one active at a time</button>
      <div class="accordion-body">
        <p>Apply serums after cleansing. Start acids (BHA/AHA) or vitamin C slowly — 2–3 evenings a week — and never layer multiple strong actives at once.</p>
      </div>
    </div>
    <div class="accordion-item">
      <button type="button" class="accordion-header">🧴 3. Moisturize — even for oily skin</button>
      <div class="accordion-body">
        <p>Choose a lightweight, non-comedogenic cream for oily skin and a richer ceramide cream for dry skin. Moisturizing keeps the barrier healthy.</p>
      </div>
    </div>
    <div class="accordion-item">
      <button type="button" class="accordion-header">☀️ 4. Protect — SPF every single morning</button>
      <div class="accordion-body">
        <p>Apply broad-spectrum SPF 30–50 daily, even indoors near windows or on cloudy days. Sunscreen is the best anti-ageing and anti-pigment product there is.</p>
      </div>
    </div>
  </div>
</section>

<?php require_once $ROOT . '/includes/footer.php'; ?>
