/* ============================================================
   MEDIRUSH — js/script.js
   Main frontend interactions (no external frameworks needed).
   ============================================================ */
(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {

    /* ---------------- Mobile navigation burger ---------------- */
    var burger = document.getElementById('navBurger');
    var nav = document.getElementById('mainNav');
    if (burger && nav) {
      burger.addEventListener('click', function () {
        var open = nav.classList.toggle('nav-open');
        burger.setAttribute('aria-expanded', open ? 'true' : 'false');
        burger.textContent = open ? '✕' : '☰';
      });
    }

    /* ---------------- User dropdown chip ---------------- */
    var chipBtn = document.getElementById('userChipBtn');
    var dropdown = document.getElementById('userDropdown');
    if (chipBtn && dropdown) {
      chipBtn.addEventListener('click', function (e) {
        e.stopPropagation();
        dropdown.classList.toggle('open');
      });
      document.addEventListener('click', function (e) {
        if (!dropdown.contains(e.target) && e.target !== chipBtn) dropdown.classList.remove('open');
      });
    }

    /* ---------------- Auto-dismiss flash messages ---------------- */
    document.querySelectorAll('.alert').forEach(function (el) {
      setTimeout(function () {
        el.style.transition = 'opacity .5s';
        el.style.opacity = '0';
        setTimeout(function () { el.remove(); }, 500);
      }, 6000);
    });

    /* ---------------- Confirmation prompts ---------------- */
    document.querySelectorAll('[data-confirm]').forEach(function (el) {
      el.addEventListener('click', function (e) {
        if (!window.confirm(el.getAttribute('data-confirm'))) e.preventDefault();
      });
    });

    /* ---------------- Tabs (profile, tracker, etc.) ---------------- */
    document.querySelectorAll('.tabs').forEach(function (tabs) {
      tabs.querySelectorAll('.tab-btn').forEach(function (btn) {
        btn.addEventListener('click', function () {
          tabs.querySelectorAll('.tab-btn').forEach(function (b) { b.classList.remove('active'); });
          btn.classList.add('active');
          var target = btn.getAttribute('data-tab');
          var scope = document;
          if (tabs.getAttribute('data-scope')) scope = document.querySelector(tabs.getAttribute('data-scope')) || document;
          scope.querySelectorAll('.tab-panel').forEach(function (p) {
            p.hidden = p.id !== target;
          });
        });
      });
    });

    /* ---------------- Quantity steppers in cart/product forms ---------------- */
    document.querySelectorAll('.qty-stepper').forEach(function (wrap) {
      wrap.addEventListener('click', function (e) {
        var btn = e.target.closest('button');
        if (!btn) return;
        var input = wrap.querySelector('input[type="number"]');
        if (!input) return;
        var val = parseInt(input.value || '1', 10);
        if (btn.getAttribute('data-step') === 'down') val = Math.max(1, val - 1);
        else val = val + 1;
        var max = parseInt(input.max || '99', 10);
        input.value = Math.min(val, max);
        input.dispatchEvent(new Event('change'));
      });
    });

    /* ---------------- FAQ / accordion ---------------- */
    document.querySelectorAll('.accordion-header').forEach(function (head) {
      head.addEventListener('click', function () {
        var item = head.parentElement;
        item.classList.toggle('open');
      });
    });

    /* ---------------- Anatomy: organ info panel ---------------- */
    document.querySelectorAll('.organ-btn').forEach(function (btn) {
      btn.addEventListener('click', function () {
        document.querySelectorAll('.organ-btn').forEach(function (b) { b.classList.remove('active'); });
        btn.classList.add('active');
        var panel = document.getElementById('organPanel');
        if (panel) {
          panel.querySelector('.organ-name').textContent = btn.getAttribute('data-name') || '';
          panel.querySelector('.organ-desc').textContent = btn.getAttribute('data-desc') || '';
          panel.querySelector('.organ-tips').textContent = btn.getAttribute('data-tips') || '';
          panel.classList.add('visible');
        }
      });
    });

    /* ---------------- Emergency locator map ---------------- */
    var mapEl = document.getElementById('facilitiesMap');
    if (mapEl) {
      var key = (window.MEDIRUSH_CONFIG && window.MEDIRUSH_CONFIG.googleMapsKey) || '';
      var listEl = document.getElementById('facilityList');
      var renderList = function () {
        if (!listEl) return;
        listEl.querySelectorAll('.facility-card').forEach(function (card) {
          card.style.display = 'block';
        });
      };
      if (!key) {
        // DEMO MODE: no API key configured — show the list with a clear notice.
        var notice = document.getElementById('mapDemoNotice');
        if (notice) notice.hidden = false;
        if (mapEl) mapEl.innerHTML = '<div class="empty-state"><div class="empty-icon">🗺️</div><p><strong>Demo mode</strong> — live map disabled.</p><p class="muted">Add your Google Maps key in <code>includes/config.php</code> to enable the interactive map.</p></div>';
        renderList();
      } else {
        var script = document.createElement('script');
        script.src = 'https://maps.googleapis.com/maps/api/js?key=' + encodeURIComponent(key) + '&libraries=places&callback=medirushInitMap';
        script.async = true;
        window.medirushInitMap = function () {
          renderList();
          var fit = function (map, items) {
            if (!items.length) return;
            var bounds = new google.maps.LatLngBounds();
            items.forEach(function (it) { bounds.extend(it.position); });
            map.fitBounds(bounds);
          };
          var cards = listEl ? listEl.querySelectorAll('.facility-card[data-lat][data-lng]') : [];
          var items = [];
          var infoWindow = new google.maps.InfoWindow();
          cards.forEach(function (card) {
            var pos = { lat: parseFloat(card.dataset.lat), lng: parseFloat(card.dataset.lng) };
            var marker = new google.maps.Marker({ position: pos, map: map, title: card.dataset.name || 'Facility' });
            items.push({ position: pos });
            marker.addListener('click', function () {
              infoWindow.setContent('<strong>' + (card.dataset.name || '') + '</strong><br>' + (card.dataset.address || ''));
              infoWindow.open(map, marker);
            });
            card.addEventListener('mouseenter', function () { infoWindow.open(map, marker); });
          });
          var map = new google.maps.Map(mapEl, { zoom: 12, center: items.length ? items[0].position : { lat: -26.19, lng: 28.03 } });
          fit(map, items);
          map.setOptions({ mapTypeControl: false });
        };
      }
    }

    /* ---------------- Simple form helper: disable empty selects ---------------- */
    document.querySelectorAll('form.js-trim').forEach(function (form) {
      form.addEventListener('submit', function () {
        form.querySelectorAll('select, input[type="text"], input[type="email"], input[type="password"], textarea').forEach(function (f) {
          if (typeof f.value === 'string') f.value = f.value.replace(/^\\s+|\\s+$/g, '');
        });
      });
    });
  });
})();
