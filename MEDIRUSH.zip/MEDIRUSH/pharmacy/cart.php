<?php
/**
 * MEDIRUSH — Shopping cart (protected).
 */
$ROOT = '..';
$PAGE_TITLE = 'My Cart — MEDIRUSH';
$ACTIVE = 'pharmacy';
$SHOW_SIDEBAR = false;
require_once $ROOT . '/includes/auth.php';

if (!is_logged_in()) {
    require_login('pharmacy/cart.php');
}
$user = current_user();
$cartId = get_or_create_cart((int)$user['id']);

/* ------------------------------ POST handlers ------------------------------ */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = (string)($_POST['action'] ?? '');

    /* --- Update quantity --- */
    if ($action === 'update_item') {
        $itemId  = (int)($_POST['item_id'] ?? 0);
        $quantity = (int)($_POST['quantity'] ?? 0);
        // Item must belong to THIS user's cart.
        $item = fetch_one(
            "SELECT ci.id, ci.product_type, ci.product_id FROM cart_items ci
             JOIN carts c ON c.id = ci.cart_id AND c.user_id = ?
             WHERE ci.id = ? LIMIT 1",
            'ii',
            [(int)$user['id'], $itemId]
        );
        if ($item) {
            $row = $item['product_type'] === 'skincare'
                ? fetch_one('SELECT stock FROM skincare_products WHERE id = ? LIMIT 1', 'i', [(int)$item['product_id']])
                : fetch_one('SELECT stock FROM pharmacy_products WHERE id = ? LIMIT 1', 'i', [(int)$item['product_id']]);
            $stock = $row ? (int)$row['stock'] : 0;
            if ($stock <= 0) {
                $del = db()->prepare('DELETE FROM cart_items WHERE id = ?');
                $del->bind_param('i', $itemId);
                $del->execute();
                $del->close();
                flash('info', 'That product is no longer available and was removed from your cart.');
            } elseif ($quantity >= 1 && $quantity <= $stock) {
                $stmt = db()->prepare('UPDATE cart_items SET quantity = ? WHERE id = ?');
                $stmt->bind_param('ii', $quantity, $itemId);
                $stmt->execute();
                $stmt->close();
                flash('success', 'Cart updated ✅');
            } else {
                flash('error', "Quantity must be between 1 and {$stock}.");
            }
        } else {
            flash('error', 'Cart item not found.');
        }
        redirect('pharmacy/cart.php');
    }

    /* --- Remove item --- */
    if ($action === 'remove_item') {
        $itemId = (int)($_POST['item_id'] ?? 0);
        $userOwnerId = (int)$user['id'];
        $stmt = db()->prepare(
            'DELETE ci FROM cart_items ci
             JOIN carts c ON c.id = ci.cart_id AND c.user_id = ?
             WHERE ci.id = ?'
        );
        $stmt->bind_param('ii', $userOwnerId, $itemId);
        $stmt->execute();
        $stmt->close();
        flash('success', 'Item removed from cart 🗑️');
        redirect('pharmacy/cart.php');
    }
}

/* ------------------------------- Load items -------------------------------- */
$pharmacyItems = fetch_all(
    "SELECT ci.id, ci.product_id, ci.quantity, p.name, p.price, p.image, p.stock, p.requires_prescription
     FROM cart_items ci
     JOIN carts c ON c.id = ci.cart_id AND c.user_id = ?
     LEFT JOIN pharmacy_products p ON p.id = ci.product_id
     WHERE ci.product_type = 'pharmacy'
     ORDER BY ci.id ASC",
    'i',
    [(int)$user['id']]
);
$skincareItems = fetch_all(
    "SELECT ci.id, ci.product_id, ci.quantity, s.name, s.price, s.image, s.stock
     FROM cart_items ci
     JOIN carts c ON c.id = ci.cart_id AND c.user_id = ?
     LEFT JOIN skincare_products s ON s.id = ci.product_id
     WHERE ci.product_type = 'skincare'
     ORDER BY ci.id ASC",
    'i',
    [(int)$user['id']]
);

$pharmacySubtotal = 0.00;
$skincareSubtotal = 0.00;
foreach ($pharmacyItems as $it) {
    if ($it['name'] !== null) $pharmacySubtotal += (float)$it['price'] * (int)$it['quantity'];
}
foreach ($skincareItems as $it) {
    if ($it['name'] !== null) $skincareSubtotal += (float)$it['price'] * (int)$it['quantity'];
}
$grandTotal = $pharmacySubtotal + $skincareSubtotal;
$isEmpty = !$pharmacyItems && !$skincareItems;

require_once $ROOT . '/includes/header.php';
?>

<section class="section">
  <div class="container">
    <h1 class="section-title">🛒 My Cart</h1>
    <p class="section-subtitle">Review your items before checkout.</p>

    <?php if ($isEmpty): ?>
      <div class="empty-state">
        <div class="empty-icon">🛒</div>
        <h3>Your cart is empty</h3>
        <p>Add medicines or skincare products to get started.</p>
        <p>
          <a class="btn btn-primary" href="<?= u('pharmacy/pharmacy.php') ?>">💊 Shop the pharmacy</a>
          <a class="btn btn-outline" href="<?= u('beauty/beauty.php') ?>">✨ Shop beauty</a>
        </p>
      </div>
    <?php else: ?>
      <?php foreach (['pharmacy' => [$pharmacyItems, 'Pharmacy 💊'], 'skincare' => [$skincareItems, 'Skincare ✨']] as $groupKey => [$items, $groupLabel]): ?>
        <?php if ($items): ?>
          <h2 class="section-subtitle"><?= e($groupLabel) ?></h2>
          <div class="table-wrap card">
            <table class="table">
              <thead>
                <tr><th>Product</th><th>Unit price</th><th>Quantity</th><th>Total</th><th></th></tr>
              </thead>
              <tbody>
                <?php foreach ($items as $it): ?>
                  <?php if ($it['name'] === null) continue; // product deleted ?>
                  <?php $lineTotal = (float)$it['price'] * (int)$it['quantity']; ?>
                  <tr>
                    <td>
                      <a class="cart-item-link" href="<?= details_url($groupKey) ?>?id=<?= (int)$it['product_id'] ?>">
                        <span class="cart-item-emoji"><?= e(icon($it['image'], '📦')) ?></span> <?= e($it['name']) ?>
                      </a>
                    </td>
                    <td><?= money($it['price']) ?></td>
                    <td>
                      <form method="post" action="<?= u('pharmacy/cart.php') ?>" class="inline-form">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="update_item">
                        <input type="hidden" name="item_id" value="<?= (int)$it['id'] ?>">
                        <input type="number" name="quantity" class="form-input qty-input" value="<?= (int)$it['quantity'] ?>" min="1" max="<?= (int)$it['stock'] ?>" aria-label="Quantity">
                        <button type="submit" class="btn btn-small btn-outline">Update</button>
                      </form>
                    </td>
                    <td><strong><?= money($lineTotal) ?></strong></td>
                    <td>
                      <form method="post" action="<?= u('pharmacy/cart.php') ?>" class="inline-form">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="remove_item">
                        <input type="hidden" name="item_id" value="<?= (int)$it['id'] ?>">
                        <button type="submit" class="btn btn-small btn-danger">Remove ✕</button>
                      </form>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>

          <?php if ($groupKey === 'pharmacy'): ?>
            <div class="order-summary-line"><span>Pharmacy subtotal</span><span><?= money($pharmacySubtotal) ?></span></div>
          <?php else: ?>
            <div class="order-summary-line"><span>Skincare subtotal</span><span><?= money($skincareSubtotal) ?></span></div>
          <?php endif; ?>
        <?php endif; ?>
      <?php endforeach; ?>

      <div class="order-summary-line total">
        <span><strong>Grand total</strong></span>
        <span><strong><?= money($grandTotal) ?></strong></span>
      </div>

      <div class="cart-bottom-bar">
        <a class="btn btn-outline" href="<?= u('pharmacy/pharmacy.php') ?>">← Continue shopping</a>
        <a class="btn btn-primary" href="<?= u('pharmacy/checkout.php') ?>">Proceed to Checkout →</a>
      </div>
    <?php endif; ?>
  </div>
</section>

<?php require_once $ROOT . '/includes/footer.php'; ?>
