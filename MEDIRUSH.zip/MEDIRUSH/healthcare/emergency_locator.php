<?php
/**
 * MEDIRUSH — Emergency & facility locator (public page).
 * #facilitiesMap / #mapDemoNotice / #facilityList are wired by js/script.js — no map JS here.
 */
$ROOT = '..';
$PAGE_TITLE = 'Emergency & Facility Locator — MEDIRUSH';
$ACTIVE = 'healthcare';
require_once $ROOT . '/includes/header.php';

/* ------------------------------- GET filters ------------------------------- */
$allowedTypes = ['hospital', 'clinic', 'pharmacy', 'laboratory'];
$typeIcons = ['hospital' => '🏥', 'clinic' => '🩺', 'pharmacy' => '💊', 'laboratory' => '🔬'];
$typeLabels = ['hospital' => 'Hospital', 'clinic' => 'Clinic', 'pharmacy' => 'Pharmacy', 'laboratory' => 'Laboratory'];

$q    = trim($_GET['q'] ?? '');
$city = trim($_GET['city'] ?? '');
$type = trim($_GET['type'] ?? '');

$where = [];
$params = [];
$paramTypes = '';

if ($q !== '') {
    $where[] = 'name LIKE ?';
    $params[] = '%' . $q . '%';
    $paramTypes .= 's';
}
if ($city !== '') {
    $where[] = 'city = ?';
    $params[] = $city;
    $paramTypes .= 's';
}
if ($type !== '' && in_array($type, $allowedTypes, true)) {
    $where[] = 'type = ?';
    $params[] = $type;
    $paramTypes .= 's';
}

$sql = 'SELECT id, name, type, address, city, phone, latitude, longitude, is_emergency FROM healthcare_facilities'
     . ($where ? ' WHERE ' . implode(' AND ', $where) : '')
     . ' ORDER BY name ASC';
$facilities = fetch_all($sql, $paramTypes, $params);

$cities = fetch_all('SELECT DISTINCT city FROM healthcare_facilities ORDER BY city ASC');
?>

<section class="section">
  <h1 class="section-title">🚑 Emergency &amp; facility locator</h1>
  <p class="section-subtitle">
    Find hospitals, clinics, pharmacies and laboratories near you. Hover a card to highlight
    it on the map.
  </p>

  <!-- Red emergency strip -->
  <div class="alert alert-error mb-3">
    🚨 <strong>In a life-threatening emergency call <span>10177</span> (ambulance) or
    <span>112</span> from a mobile phone immediately.</strong>
    Vehicle accidents, chest pain, severe bleeding, difficulty breathing or suspected stroke —
    do not wait; call first, then head to your nearest emergency unit.
  </div>

  <!-- Filter bar -->
  <form method="get" action="<?= u('healthcare/emergency_locator.php') ?>" class="filter-bar js-trim mb-4">
    <input type="text" class="form-input" name="q" value="<?= e($q) ?>" placeholder="🔍 Search facility name…" aria-label="Search facility name">
    <select class="form-select" name="city" aria-label="Filter by city">
      <option value="">All cities</option>
      <?php foreach ($cities as $c): ?>
        <option value="<?= e($c['city']) ?>"<?= $city === $c['city'] ? ' selected' : '' ?>><?= e($c['city']) ?></option>
      <?php endforeach; ?>
    </select>
    <select class="form-select" name="type" aria-label="Filter by facility type">
      <option value="">All types</option>
      <?php foreach ($allowedTypes as $t): ?>
        <option value="<?= e($t) ?>"<?= $type === $t ? ' selected' : '' ?>><?= $typeIcons[$t] ?> <?= e($typeLabels[$t]) ?></option>
      <?php endforeach; ?>
    </select>
    <button type="submit" class="btn btn-primary btn-sm">Filter</button>
    <a class="btn btn-outline btn-sm" href="<?= u('healthcare/emergency_locator.php') ?>">Reset</a>
  </form>

  <!-- Live map (or demo notice when no Google Maps key is configured) -->
  <div id="facilitiesMap" class="mb-4"></div>
  <div id="mapDemoNotice" class="notice mb-3" hidden>
    🗺️ <strong>Demo mode</strong> — no Google Maps key is configured. Add your key as
    <code>GOOGLE_MAPS_API_KEY</code> in <code>includes/config.php</code> to enable the live
    interactive map. The facility list below still works fully.
  </div>

  <!-- Facility cards -->
  <div id="facilityList" class="grid grid-3">
    <?php if (!$facilities): ?>
      <div class="empty-state" style="grid-column: 1 / -1;">
        <div class="empty-icon">🔍</div>
        <h3>No facilities match your filters</h3>
        <p>Try a different name, city or facility type — or reset the filters below.</p>
        <a class="btn btn-outline btn-sm mt-2" href="<?= u('healthcare/emergency_locator.php') ?>">Reset filters</a>
      </div>
    <?php else: ?>
      <?php foreach ($facilities as $f): ?>
        <div class="facility-card"
             data-lat="<?= e($f['latitude']) ?>"
             data-lng="<?= e($f['longitude']) ?>"
             data-name="<?= e($f['name']) ?>"
             data-address="<?= e($f['address'] . ', ' . $f['city']) ?>">
          <div class="facility-head">
            <div class="facility-icon"><?= $typeIcons[$f['type']] ?? '🏥' ?></div>
            <div>
              <h3><?= e($f['name']) ?></h3>
              <div class="mt-1">
                <span class="badge"><?= e($typeLabels[$f['type']] ?? ucfirst($f['type'])) ?></span>
                <?php if ((int)$f['is_emergency'] === 1): ?>
                  <span class="badge badge-danger">24hr Emergency</span>
                <?php endif; ?>
              </div>
            </div>
          </div>
          <p class="product-desc">📍 <?= e($f['address']) ?></p>
          <p class="muted mb-1">🏘️ <?= e($f['city']) ?></p>
          <p class="muted">📞 <?= e($f['phone']) ?></p>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
</section>

<?php require_once $ROOT . '/includes/footer.php'; ?>
