<?php
/**
 * MEDIRUSH — check_db.php — quick local diagnostics.
 * (Local development helper — safe to delete before going live.)
 */
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';

$conn = null;
try {
    $conn = db();   // prints the friendly setup page and dies if DB is broken
} catch (Throwable $e) { /* unreachable: db() dies first */ }

$tables = [
    'users', 'user_profiles', 'medical_records', 'prescriptions',
    'pharmacy_products', 'skincare_products', 'carts', 'cart_items',
    'orders', 'order_items', 'doctors', 'appointments', 'medications',
    'medication_reminders', 'skincare_routines', 'skincare_logs',
    'healthcare_facilities', 'notifications', 'messages',
];
$missing = [];
$rows = [];
foreach ($tables as $t) {
    $r = $conn->query('SELECT COUNT(*) AS c FROM `' . str_replace('`', '', $t) . '`');
    if ($r) {
        $rows[$t] = (int)($r->fetch_assoc()['c'] ?? 0);
    } else {
        $rows[$t] = null;
        $missing[] = $t;
    }
}
$uploadsDir = __DIR__ . '/assets/uploads';
$uploadsOk = is_dir($uploadsDir) && is_writable($uploadsDir);
$phpOk = version_compare(PHP_VERSION, '8.1.0', '>=');
$extNeeded = ['mysqli', 'mbstring', 'fileinfo', 'gd'];
$extMissing = array_filter($extNeeded, fn ($x) => !extension_loaded($x));
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><title>MEDIRUSH — Environment check</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="<?= e(u('css/style.css')) ?>">
<link rel="stylesheet" href="<?= e(u('css/responsive.css')) ?>">
</head>
<body>
<main class="container" style="padding:40px 20px">
  <h1>🩺 MEDIRUSH — Environment check</h1>
  <p class="muted">Everything below should be green before you start using the site.</p>

  <div class="card mt-3">
    <h3>PHP</h3>
    <p><?= $phpOk ? '✅' : '⚠️' ?> Version: <?= e(PHP_VERSION) ?> (8.1+ recommended, XAMPP default OK)</p>
    <p><?= $extMissing ? '⚠️ Missing extensions: ' . e(implode(', ', $extMissing)) : '✅ Extensions: mysqli, mbstring, fileinfo, gd all loaded' ?></p>
  </div>

  <div class="card mt-2">
    <h3>MySQL ↔ PHP connection</h3>
    <p>✅ Connected to <code><?= e(DB_NAME) ?></code> on <code><?= e(DB_HOST) ?></code> as <code><?= e(DB_USER) ?></code></p>
  </div>

  <div class="card mt-2">
    <h3>Database tables (<?= count($tables) - count($missing) ?>/<?= count($tables) ?> present)</h3>
    <div class="table-wrap">
      <table class="table">
        <thead><tr><th>Table</th><th>Rows</th><th>Status</th></tr></thead>
        <tbody>
        <?php foreach ($rows as $t => $c): ?>
          <tr>
            <td><code><?= e($t) ?></code></td>
            <td><?= $c === null ? '—' : number_format($c) ?></td>
            <td><?= $c === null ? '<span class="badge badge-danger">Missing</span>' : '<span class="badge badge-success">OK</span>' ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php if ($missing): ?>
      <div class="alert alert-error mt-2">⚠️ Tables are missing. Import <code>database.sql</code> via phpMyAdmin (Import tab) and reload this page.</div>
    <?php endif; ?>
  </div>

  <div class="card mt-2">
    <h3>Uploads folder</h3>
    <p><?= $uploadsOk ? '✅' : '⚠️' ?> <code>assets/uploads/</code> is <?= $uploadsOk ? 'present and writable — uploads will work' : 'missing or not writable — uploads fail until you allow Modify permissions on it' ?></p>
  </div>

  <div class="mt-3">
    <a class="btn btn-primary" href="<?= e(u('index.php')) ?>">🏠 Go to the homepage</a>
    <a class="btn btn-outline" href="<?= e(u('login.php')) ?>">Login</a>
  </div>
</main>
</body>
</html>