<?php
/**
 * MEDIRUSH — Reusable header + navigation.
 * Expects (optional) page variables: $ROOT, $PAGE_TITLE, $ACTIVE, $SHOW_SIDEBAR.
 * When $SHOW_SIDEBAR is true, <body> gets the with-side-rail class so
 * css/ui.css can place the sidebar and main content in two Grid columns
 * (the <aside> is printed before <main>, so nesting is not possible).
 */
declare(strict_types=1);

$ROOT    = $ROOT ?? '.';
$PAGE_TITLE = $PAGE_TITLE ?? 'MEDIRUSH — Your health, your beauty, one platform';
$ACTIVE  = $ACTIVE ?? '';
$SHOW_SIDEBAR = $SHOW_SIDEBAR ?? false;

require_once $ROOT . '/includes/auth.php';

$user = current_user();
$unread = $user ? notifications_count((int)$user['id']) : 0;

$navItems = [
    'home'       => [t('nav_home'), 'index.php'],
    'healthcare' => [t('nav_healthcare'), 'healthcare/healthcare.php'],
    'pharmacy'   => [t('nav_pharmacy'), 'pharmacy/pharmacy.php'],
    'beauty'     => [t('nav_beauty'), 'beauty/beauty.php'],
    'my_health'  => [t('nav_my_health'), 'my_health/my_health.php'],
    'dashboard'  => [t('nav_dashboard'), 'dashboard.php'],
];
?>
<!DOCTYPE html>
<html lang="<?= e(medirush_lang()) ?>" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($PAGE_TITLE) ?></title>
<meta name="description" content="MEDIRUSH — healthcare, pharmacy, skincare and personal health management in one platform.">
<link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🩺</text></svg>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<link rel="stylesheet" href="<?= u('css/style.css') ?>">
<link rel="stylesheet" href="<?= u('css/responsive.css') ?>">
<link rel="stylesheet" href="<?= u('css/effects.css') ?>">
<link rel="stylesheet" href="<?= u('css/ui.css') ?>">
<script src="<?= u('js/theme.js') ?>"></script>
<script>window.MEDIRUSH_CONFIG = { googleMapsKey: '<?= defined('GOOGLE_MAPS_API_KEY') ? addslashes(GOOGLE_MAPS_API_KEY) : '' ?>', skincareAiKey: '<?= defined('SKINCARE_AI_API_KEY') ? addslashes(SKINCARE_AI_API_KEY) : '' ?>' };</script>
</head>
<body<?= $SHOW_SIDEBAR ? ' class="with-side-rail"' : '' ?>>
<a class="skip-link" href="#main-content">Skip to main content</a>

<header class="header">
  <div class="container nav-row">
    <a href="<?= u('index.php') ?>" class="brand" aria-label="MEDIRUSH home">
      <span class="brand-icon">🩺</span> <span class="brand-name">MEDI<b>RUSH</b></span>
    </a>

    <button class="nav-burger" id="navBurger" aria-label="Open menu" aria-expanded="false">☰</button>

    <nav class="nav" id="mainNav" aria-label="Main navigation">
      <ul class="nav-links">
        <?php foreach ($navItems as $key => [$label, $href]): ?>
          <li><a class="nav-link<?= $ACTIVE === $key ? ' active' : '' ?>" href="<?= u($href) ?>"><?= e($label) ?></a></li>
        <?php endforeach; ?>
      </ul>
      <div class="nav-actions">
        <button class="theme-toggle" id="themeToggle" title="Toggle light/dark mode" aria-label="Toggle theme">🌙</button>
        <?php if ($user): ?>
          <a href="<?= u('dashboard.php') ?>" class="icon-btn btn-bell" title="Notifications" aria-label="Notifications">🔔<?php if ($unread > 0): ?><span class="bell-badge"><?= (int)$unread ?></span><?php endif; ?></a>
          <div class="user-chip">
            <button class="user-chip-btn" id="userChipBtn">
              <span class="avatar"><?= e(strtoupper(mb_substr($user['full_name'], 0, 1))) ?></span>
              <span class="chip-name"><?= e($user['full_name']) ?></span> ▾
            </button>
            <ul class="user-dropdown" id="userDropdown">
              <li><a href="<?= u('account/profile.php') ?>">👤 My Profile</a></li>
              <li><a href="<?= u('account/orders.php') ?>">🧾 My Orders</a></li>
              <li><a href="<?= u('account/appointments.php') ?>">📅 Appointments</a></li>
              <li><a href="<?= u('pharmacy/cart.php') ?>">🛒 Cart</a></li>
              <li><a href="<?= u('account/settings.php') ?>">⚙️ Settings</a></li>
              <?php if ($user['role'] === 'admin'): ?><li><a href="<?= u('admin.php') ?>">🛡️ Admin</a></li><?php endif; ?>
              <li class="dd-divider"></li>
              <li><a href="<?= u('logout.php') ?>">🚪 Log out</a></li>
            </ul>
          </div>
        <?php else: ?>
          <a href="<?= u('login.php') ?>" class="nav-link">Login</a>
          <a class="btn btn-primary nav-cta" href="<?= u('register.php') ?>">Sign Up</a>
        <?php endif; ?>
      </div>
    </nav>
  </div>
</header>

<?php if ($SHOW_SIDEBAR) { require $ROOT . '/includes/sidebar.php'; } ?>

<main id="main-content" class="site-main<?= $SHOW_SIDEBAR ? ' with-sidebar' : '' ?>">
  <div class="container">
    <?php display_flash(); ?>
  </div>