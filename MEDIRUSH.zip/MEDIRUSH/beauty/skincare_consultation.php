<?php
/**
 * MEDIRUSH — beauty/skincare_consultation.php
 * PROTECTED demo chat with a skin professional (messages table).
 */
declare(strict_types=1);

$ROOT = '..';
$PAGE_TITLE = 'Skincare Consultation — MEDIRUSH';
$ACTIVE = 'beauty';
$SHOW_SIDEBAR = false;

require_once $ROOT . '/includes/auth.php';
require_login('beauty/skincare_consultation.php');
$userId = (int)$_SESSION['user_id'];

/** Rule-based demo reply from the "skin professional" (workflow demo only). */
function demo_skin_reply(string $body): string {
    $t = mb_strtolower($body);
    if (preg_match('/acne|pimple|breakout|blackhead|whitehead/', $t)) {
        return 'For acne-prone skin, keep it simple: a gentle salicylic-acid (BHA) cleansing 2× a day, '
             . 'a BHA toner 2–3 evenings a week, a lightweight non-comedogenic moisturizer, and SPF 50 every morning. '
             . 'Avoid picking spots and change pillowcases weekly. This is a demo reply.';
    }
    if (preg_match('/pigment|dark spot|melasma|uneven|scar/', $t)) {
        return 'For pigmentation and dark spots: a vitamin C serum in the morning, niacinamide in the evening, '
             . 'and strict daily broad-spectrum SPF 50 — without sunscreen, nothing else will work. '
             . 'Results take 8–12 weeks; be consistent. This is a demo reply.';
    }
    if (preg_match('/sun|spf|uv|sunscreen|suntan/', $t)) {
        return 'Choose a broad-spectrum SPF 50 that you enjoy wearing — gel formulas suit oily skin, '
             . 'cream formulas suit dry skin. Apply a full teaspoon for the face and neck, and reapply every 2 hours outdoors. '
             . 'This is a demo reply.';
    }
    if (preg_match('/dry|dehydr|flak|tight|eczema/', $t)) {
        return 'For dry or dehydrated skin: swap to a cream cleanser, layer a hyaluronic acid serum on damp skin, '
             . 'then seal with a ceramide moisturizer within 60 seconds. Humidifiers and lukewarm water help too. '
             . 'This is a demo reply.';
    }
    return 'Thank you for sharing! A skin professional will review your message during office hours. '
         . 'In the meantime: gently cleanse twice a day, moisturize, and wear SPF 50 daily. '
         . 'This is a demo reply.';
}

/* ---------------------------- Send message POST ----------------------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'send_message') {
    verify_csrf();

    $body = trim((string)($_POST['body'] ?? ''));
    if ($body === '' || mb_strlen($body) > 1000) {
        flash('error', 'Your message must be between 1 and 1000 characters.');
        redirect('beauty/skincare_consultation.php');
    }

    // Save the user's message (ownership: this user only).
    $stmt = db()->prepare('INSERT INTO messages (user_id, sender, body) VALUES (?, ?, ?)');
    $sender = 'user';
    $stmt->bind_param('iss', $userId, $sender, $body);
    $stmt->execute();
    $stmt->close();

    // DEMO auto-reply from the skin professional.
    $reply = demo_skin_reply($body);
    $stmt = db()->prepare('INSERT INTO messages (user_id, sender, body) VALUES (?, ?, ?)');
    $sender = 'pro';
    $stmt->bind_param('iss', $userId, $sender, $reply);
    $stmt->execute();
    $stmt->close();

    redirect('beauty/skincare_consultation.php');
}

/* ------------------------------- Chat history ------------------------------- */
$messages = fetch_all(
    'SELECT id, sender, body, created_at FROM messages WHERE user_id = ? ORDER BY created_at ASC, id ASC',
    'i', [$userId]
);

require_once $ROOT . '/includes/header.php';
?>

<section class="section">
  <h1 class="section-title">👩‍⚕️ Skincare Consultation</h1>
  <p class="section-subtitle">Chat with a skin professional about your routine, breakouts or pigmentation.</p>

  <div class="notice">
    👩‍⚕️ Demo consultation — a real consultant replies during office hours once a live service is connected (see PROJECT_SPEC notes).
  </div>

  <div class="card card-body">
    <div class="chat-box" id="chatBox">
      <?php if (!$messages): ?>
        <div class="empty-state">
          <div class="empty-icon">💬</div>
          <h3>No messages yet</h3>
          <p>Describe your skin concern to start the conversation. For example:</p>
          <p>
            “I get pimples around my jawline — help!”<br>
            “My skin feels tight even after moisturizing.”<br>
            “Which SPF works under makeup?”
          </p>
        </div>
      <?php else: ?>
        <?php foreach ($messages as $m): ?>
          <div class="chat-msg <?= $m['sender'] === 'user' ? 'user' : 'bot' ?>">
            <p><?= nl2br(e((string)$m['body'])) ?></p>
            <small class="muted"><?= e(date('H:i, d M', strtotime((string)$m['created_at']))) ?></small>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>

    <form method="post" action="<?= u('beauty/skincare_consultation.php') ?>" class="chat-input-row">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="send_message">
      <input type="text" class="form-input" name="body" maxlength="1000" required autocomplete="off"
             placeholder="Describe your skin concern (max 1000 characters)…">
      <button class="btn btn-primary" type="submit">Send ➤</button>
    </form>
    <p class="form-help">Do not share ID numbers or medical aid details in chat.</p>
  </div>
</section>

<?php require_once $ROOT . '/includes/footer.php'; ?>
