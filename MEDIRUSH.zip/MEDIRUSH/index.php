<?php
/**
 * MEDIRUSH — Public homepage.
 * The "Visit the pharmacy" CTA shows the user's registered country
 * (pharmacy page then centres the delivery location on that country).
 * Texts follow the user's language (via includes/lang.php).
 */
$ROOT = '.';
$PAGE_TITLE = 'MEDIRUSH — Your health. Your beauty. One platform.';
$ACTIVE = 'home';
require_once $ROOT . '/includes/header.php';

$conn = db();

/* Latest pharmacy products */
$pharmacyPickups = fetch_all(
    'SELECT id, name, category, description, price, image, requires_prescription
     FROM pharmacy_products ORDER BY id DESC LIMIT 4'
);

/* Latest skincare products */
$skincarePickups = fetch_all(
    'SELECT id, name, category, skin_type, description, price, image
     FROM skincare_products ORDER BY id DESC LIMIT 4'
);

/* Doctors */
$topDoctors = fetch_all(
    'SELECT id, name, specialization, bio, consultation_fee, image, available_days, video_enabled
     FROM doctors ORDER BY id ASC LIMIT 3'
);

/* Registered country → makes the pharmacy CTA location-aware */
$myCountry = is_logged_in() ? (string)($_SESSION['country'] ?? '') : '';
if ($myCountry === '' && is_logged_in()) {
    $pr = fetch_one('SELECT country FROM user_profiles WHERE user_id = ? LIMIT 1', 'i', [(int)current_user()['id']]);
    $myCountry = (string)($pr['country'] ?? '');
    $_SESSION['country'] = $myCountry;
}
$flags  = medirush_flags();
$pharmaLabel = t('cta_pharmacy');
if ($myCountry !== '' && isset($flags[$myCountry])) {
    $pharmaLabel .= ' — ' . $flags[$myCountry] . ' ' . $myCountry;
}

$featureCards = [
    ['Healthcare', 'Doctors, anatomy explorer and the emergency facility finder.', 'healthcare/healthcare.php', '🏥', '🩺 Find a doctor'],
    ['Pharmacy', 'Over-the-counter and prescription-aware medicine ordering.', 'pharmacy/pharmacy.php', '💊', '🛒 Shop the pharmacy'],
    ['Beauty', 'Skincare products, consultant chat and a skin assistant demo.', 'beauty/beauty.php', '✨', '💆 Explore beauty'],
    ['My Health', 'Records, prescriptions, medication reminders and trackers.', 'my_health/my_health.php', '❤️', '📋 Manage your health'],
];

$howItWorks = [
    ['1', 'Create your account', 'Sign up free, then complete your profile so your records stay with the right person.'],
    ['2', 'Browse & consult', 'Shop the pharmacy and beauty store, or pick a doctor for an in-person, video or phone visit.'],
    ['3', 'Get care & track it', 'Upload records and prescriptions, set medication reminders and follow your skincare routine.'],
];

$faq = [
    ['Is MEDIRUSH free to use?', 'Yes. Creating an account, browsing the pharmacy and beauty store and managing your health records is free. You only pay for products, doctor consultations and delivery.'],
    ['How do prescriptions work?', 'Upload a photo or PDF of your prescription under My Health. Our AI assistant verifies it, and once approved you can order the medicine from the pharmacy.'],
    ['Are my documents private?', 'Yes. Medical records and prescriptions you upload can only be downloaded by you (site admins excluded) through a secure, access-checked download link.'],
];
?>
<section class="hero" id="top">
  <!-- Hero background: optional hero.mp4, static SVG fallback otherwise -->
  <div class="hero-bg" aria-hidden="true">
    <img class="hero-poster" src="<?= u('assets/images/hero-water.svg') ?>" alt="" loading="eager"
         onerror="this.remove()">
    <video class="hero-video" data-src="<?= u('assets/videos/hero.mp4') ?>" muted loop playsinline preload="none" tabindex="-1"></video>
    <div class="hero-overlay"></div>
  </div>
  <div class="hero-inner">
    <div class="hero-content">
      <h1><?= e(t('hero_title')) ?> <span><?= e(t('hero_badge')) ?></span></h1>
      <p><?= e(t('hero_sub')) ?></p>
      <div class="hero-actions">
        <a class="btn btn-hero" href="<?= u('pharmacy/pharmacy.php') ?>"><?= e($pharmaLabel) ?></a>
        <a class="btn btn-ghost" href="<?= u('register.php') ?>"><?= e(t('cta_register')) ?></a>
      </div>
    </div>
    <div class="hero-art" aria-hidden="true">🩺</div>
  </div>
</section>

<section class="section">
  <div class="container">
    <h2 class="section-title">Everything you need, all in one place</h2>
    <p class="section-subtitle">Pick a section to get started — you can switch between them any time.</p>
    <div class="grid grid-4">
      <?php foreach ($featureCards as [$title, $desc, $href, $emoji, $cta]): ?>
        <a class="card feature-card" href="<?= u($href) ?>">
          <div class="feature-icon" aria-hidden="true"><?= $emoji ?></div>
          <h3><?= e($title) ?></h3>
          <p><?= e($desc) ?></p>
          <p><strong><?= e($cta) ?> →</strong></p>
        </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="section" id="pharmacy-picks">
  <div class="container">
    <h2 class="section-title">Popular in the pharmacy</h2>
    <p class="section-subtitle">A quick look at the newest additions to our shelves.</p>
    <?php if ($pharmacyPickups): ?>
      <div class="grid grid-4">
        <?php foreach ($pharmacyPickups as $p): ?>
          <div class="product-card">
            <div class="product-image" aria-hidden="true"><?= e(icon($p['image'])) ?></div>
            <div class="product-body">
              <div class="product-name"><?= e($p['name']) ?></div>
              <div class="product-desc"><?= e($p['description']) ?></div>
              <?php if ($p['requires_prescription']): ?><span class="badge badge-warning">ℹ️ Prescription required</span><?php endif; ?>
              <div class="product-meta">
                <span class="product-price"><?= e(money($p['price'])) ?></span>
                <a class="btn btn-outline btn-sm" href="<?= details_url('pharmacy') ?>?id=<?= (int)$p['id'] ?>">View details</a>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
      <p><a class="btn btn-primary" href="<?= u('pharmacy/pharmacy.php') ?>">🛒 Browse all medicines</a></p>
    <?php else: ?>
      <div class="card empty-state">
        <div class="empty-icon" aria-hidden="true">💊</div>
        <h3>The pharmacy is being stocked</h3>
        <p>Products will appear here shortly — check back soon.</p>
        <a class="btn btn-outline" href="<?= u('pharmacy/pharmacy.php') ?>">Go to the pharmacy</a>
      </div>
    <?php endif; ?>
  </div>
</section>

<section class="section" id="skincare-picks">
  <div class="container">
    <h2 class="section-title">Skincare picks</h2>
    <p class="section-subtitle">Fresh from the beauty counter — cleansers, serums and more.</p>
    <?php if ($skincarePickups): ?>
      <div class="grid grid-4">
        <?php foreach ($skincarePickups as $p): ?>
          <div class="product-card">
            <div class="product-image" aria-hidden="true"><?= e(icon($p['image'], '🧴')) ?></div>
            <div class="product-body">
              <div class="product-name"><?= e($p['name']) ?></div>
              <div class="product-desc"><?= e($p['description']) ?></div>
              <span class="badge badge-info">Best for: <?= e($p['skin_type']) ?></span>
              <div class="product-meta">
                <span class="product-price"><?= e(money($p['price'])) ?></span>
                <a class="btn btn-outline btn-sm" href="<?= details_url('skincare') ?>?id=<?= (int)$p['id'] ?>">View details</a>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
      <p><a class="btn btn-primary" href="<?= u('beauty/beauty.php') ?>">✨ Browse all skincare</a></p>
    <?php else: ?>
      <div class="card empty-state">
        <div class="empty-icon" aria-hidden="true">🧴</div>
        <h3>No skincare picks yet</h3>
        <p>Our beauty team is updating the shelf — check back soon.</p>
        <a class="btn btn-outline" href="<?= u('beauty/beauty.php') ?>">Go to Beauty</a>
      </div>
    <?php endif; ?>
  </div>
</section>

<section class="section" id="doctors">
  <div class="container">
    <h2 class="section-title">Meet our doctors</h2>
    <p class="section-subtitle">Qualified professionals ready for in-person, video or phone consultations.</p>
    <?php if ($topDoctors): ?>
      <div class="grid grid-3">
        <?php foreach ($topDoctors as $d): ?>
          <div class="card">
            <div class="feature-icon" aria-hidden="true"><?= e(icon($d['image'], '🩺')) ?></div>
            <h3><?= e($d['name']) ?></h3>
            <p class="badge badge-info"><?= e($d['specialization']) ?></p>
            <p class="muted"><?= e($d['bio']) ?></p>
            <p class="product-meta">
              <span class="badge"><?= e($d['available_days']) ?></span>
              <?php if ($d['video_enabled']): ?><span class="badge badge-success">🎥 Video available</span><?php endif; ?>
            </p>
            <p><strong>Consultation fee:</strong> <?= e(money($d['consultation_fee'])) ?></p>
            <a class="btn btn-outline btn-sm" href="<?= u('healthcare/doctor_consultation.php') ?>">Book / chat with a doctor</a>
          </div>
        <?php endforeach; ?>
      </div>
      <p><a class="btn btn-primary" href="<?= u('healthcare/healthcare.php') ?>">🏥 See all doctors &amp; facilities</a></p>
    <?php else: ?>
      <div class="card empty-state">
        <div class="empty-icon" aria-hidden="true">🩺</div>
        <h3>Our doctor directory is on its way</h3>
        <p>Doctors will be listed here shortly.</p>
        <a class="btn btn-outline" href="<?= u('healthcare/healthcare.php') ?>">Go to Healthcare</a>
      </div>
    <?php endif; ?>
  </div>
</section>

<section class="section" id="how-it-works">
  <div class="container">
    <h2 class="section-title">How MEDIRUSH works</h2>
    <p class="section-subtitle">Three simple steps between you and better-managed health.</p>
    <div class="grid grid-3">
      <?php foreach ($howItWorks as [$step, $title, $desc]): ?>
        <div class="card">
          <div class="feature-icon" aria-hidden="true"><?php echo e($step); ?></div>
          <h3><?= e($title) ?></h3>
          <p class="muted"><?= e($desc) ?></p>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="section" id="faq">
  <div class="container">
    <h2 class="section-title">Frequently asked questions</h2>
    <p class="section-subtitle">Still unsure about something? The answers to the questions we hear most.</p>
    <?php foreach ($faq as [$question, $answer]): ?>
      <div class="accordion-item">
        <button class="accordion-header" type="button"><?= e($question) ?></button>
        <div class="accordion-body"><p><?= e($answer) ?></p></div>
      </div>
    <?php endforeach; ?>
  </div>
</section>

<section class="section cta-aqua" id="get-started">
  <div class="container">
    <div class="card cta-aqua-inner">
      <h2 class="section-title">Ready when you are 🩺</h2>
      <p class="muted">Create a free MEDIRUSH account to manage prescriptions, records, appointments and your skincare routine — all in one dashboard.</p>
      <div class="hero-actions">
        <a class="btn btn-primary" href="<?= u('register.php') ?>">Get started — it's free</a>
        <a class="btn btn-outline" href="<?= u('login.php') ?>">I already have an account</a>
      </div>
    </div>
  </div>
</section>
<?php require_once $ROOT . '/includes/footer.php'; ?>